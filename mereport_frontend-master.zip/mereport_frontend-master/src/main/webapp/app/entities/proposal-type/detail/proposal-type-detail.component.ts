import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IProposalType } from '../proposal-type.model';

@Component({
  selector: 'jhi-proposal-type-detail',
  templateUrl: './proposal-type-detail.component.html',
})
export class ProposalTypeDetailComponent implements OnInit {
  proposalType: IProposalType | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ proposalType }) => {
      this.proposalType = proposalType;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
