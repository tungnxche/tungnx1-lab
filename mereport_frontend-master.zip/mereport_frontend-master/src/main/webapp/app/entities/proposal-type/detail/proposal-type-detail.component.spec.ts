import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { ProposalTypeDetailComponent } from './proposal-type-detail.component';

describe('ProposalType Management Detail Component', () => {
  let comp: ProposalTypeDetailComponent;
  let fixture: ComponentFixture<ProposalTypeDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProposalTypeDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ proposalType: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(ProposalTypeDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(ProposalTypeDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load proposalType on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.proposalType).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
