import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { ProposalTypeComponent } from './list/proposal-type.component';
import { ProposalTypeDetailComponent } from './detail/proposal-type-detail.component';
import { ProposalTypeUpdateComponent } from './update/proposal-type-update.component';
import { ProposalTypeDeleteDialogComponent } from './delete/proposal-type-delete-dialog.component';
import { ProposalTypeRoutingModule } from './route/proposal-type-routing.module';

@NgModule({
  imports: [SharedModule, ProposalTypeRoutingModule],
  declarations: [ProposalTypeComponent, ProposalTypeDetailComponent, ProposalTypeUpdateComponent, ProposalTypeDeleteDialogComponent],
})
export class ProposalTypeModule {}
