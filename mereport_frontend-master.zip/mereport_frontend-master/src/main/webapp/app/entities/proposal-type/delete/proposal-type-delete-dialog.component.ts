import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IProposalType } from '../proposal-type.model';
import { ProposalTypeService } from '../service/proposal-type.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './proposal-type-delete-dialog.component.html',
})
export class ProposalTypeDeleteDialogComponent {
  proposalType?: IProposalType;

  constructor(protected proposalTypeService: ProposalTypeService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.proposalTypeService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
