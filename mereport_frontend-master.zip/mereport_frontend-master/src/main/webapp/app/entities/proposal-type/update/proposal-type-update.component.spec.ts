import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { ProposalTypeFormService } from './proposal-type-form.service';
import { ProposalTypeService } from '../service/proposal-type.service';
import { IProposalType } from '../proposal-type.model';

import { ProposalTypeUpdateComponent } from './proposal-type-update.component';

describe('ProposalType Management Update Component', () => {
  let comp: ProposalTypeUpdateComponent;
  let fixture: ComponentFixture<ProposalTypeUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let proposalTypeFormService: ProposalTypeFormService;
  let proposalTypeService: ProposalTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [ProposalTypeUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(ProposalTypeUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(ProposalTypeUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    proposalTypeFormService = TestBed.inject(ProposalTypeFormService);
    proposalTypeService = TestBed.inject(ProposalTypeService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should update editForm', () => {
      const proposalType: IProposalType = { id: 456 };

      activatedRoute.data = of({ proposalType });
      comp.ngOnInit();

      expect(comp.proposalType).toEqual(proposalType);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IProposalType>>();
      const proposalType = { id: 123 };
      jest.spyOn(proposalTypeFormService, 'getProposalType').mockReturnValue(proposalType);
      jest.spyOn(proposalTypeService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ proposalType });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: proposalType }));
      saveSubject.complete();

      // THEN
      expect(proposalTypeFormService.getProposalType).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(proposalTypeService.update).toHaveBeenCalledWith(expect.objectContaining(proposalType));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IProposalType>>();
      const proposalType = { id: 123 };
      jest.spyOn(proposalTypeFormService, 'getProposalType').mockReturnValue({ id: null });
      jest.spyOn(proposalTypeService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ proposalType: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: proposalType }));
      saveSubject.complete();

      // THEN
      expect(proposalTypeFormService.getProposalType).toHaveBeenCalled();
      expect(proposalTypeService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IProposalType>>();
      const proposalType = { id: 123 };
      jest.spyOn(proposalTypeService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ proposalType });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(proposalTypeService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });
});
