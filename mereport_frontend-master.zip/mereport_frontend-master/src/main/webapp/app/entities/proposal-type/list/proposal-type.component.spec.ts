import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';

import { ProposalTypeService } from '../service/proposal-type.service';

import { ProposalTypeComponent } from './proposal-type.component';

describe('ProposalType Management Component', () => {
  let comp: ProposalTypeComponent;
  let fixture: ComponentFixture<ProposalTypeComponent>;
  let service: ProposalTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([{ path: 'proposal-type', component: ProposalTypeComponent }]), HttpClientTestingModule],
      declarations: [ProposalTypeComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({
              defaultSort: 'id,asc',
            }),
            queryParamMap: of(
              jest.requireActual('@angular/router').convertToParamMap({
                page: '1',
                size: '1',
                sort: 'id,desc',
              })
            ),
            snapshot: { queryParams: {} },
          },
        },
      ],
    })
      .overrideTemplate(ProposalTypeComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(ProposalTypeComponent);
    comp = fixture.componentInstance;
    service = TestBed.inject(ProposalTypeService);

    const headers = new HttpHeaders();
    jest.spyOn(service, 'query').mockReturnValue(
      of(
        new HttpResponse({
          body: [{ id: 123 }],
          headers,
        })
      )
    );
  });

  it('Should call load all on init', () => {
    // WHEN
    comp.ngOnInit();

    // THEN
    expect(service.query).toHaveBeenCalled();
    expect(comp.proposalTypes?.[0]).toEqual(expect.objectContaining({ id: 123 }));
  });

  describe('trackId', () => {
    it('Should forward to proposalTypeService', () => {
      const entity = { id: 123 };
      jest.spyOn(service, 'getProposalTypeIdentifier');
      const id = comp.trackId(0, entity);
      expect(service.getProposalTypeIdentifier).toHaveBeenCalledWith(entity);
      expect(id).toBe(entity.id);
    });
  });
});
