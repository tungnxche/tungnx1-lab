import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IProposalType, NewProposalType } from '../proposal-type.model';

export type PartialUpdateProposalType = Partial<IProposalType> & Pick<IProposalType, 'id'>;

export type EntityResponseType = HttpResponse<IProposalType>;
export type EntityArrayResponseType = HttpResponse<IProposalType[]>;

@Injectable({ providedIn: 'root' })
export class ProposalTypeService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/proposal-types');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(proposalType: NewProposalType): Observable<EntityResponseType> {
    return this.http.post<IProposalType>(this.resourceUrl, proposalType, { observe: 'response' });
  }

  update(proposalType: IProposalType): Observable<EntityResponseType> {
    return this.http.put<IProposalType>(`${this.resourceUrl}/${this.getProposalTypeIdentifier(proposalType)}`, proposalType, {
      observe: 'response',
    });
  }

  partialUpdate(proposalType: PartialUpdateProposalType): Observable<EntityResponseType> {
    return this.http.patch<IProposalType>(`${this.resourceUrl}/${this.getProposalTypeIdentifier(proposalType)}`, proposalType, {
      observe: 'response',
    });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IProposalType>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IProposalType[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getProposalTypeIdentifier(proposalType: Pick<IProposalType, 'id'>): number {
    return proposalType.id;
  }

  compareProposalType(o1: Pick<IProposalType, 'id'> | null, o2: Pick<IProposalType, 'id'> | null): boolean {
    return o1 && o2 ? this.getProposalTypeIdentifier(o1) === this.getProposalTypeIdentifier(o2) : o1 === o2;
  }

  addProposalTypeToCollectionIfMissing<Type extends Pick<IProposalType, 'id'>>(
    proposalTypeCollection: Type[],
    ...proposalTypesToCheck: (Type | null | undefined)[]
  ): Type[] {
    const proposalTypes: Type[] = proposalTypesToCheck.filter(isPresent);
    if (proposalTypes.length > 0) {
      const proposalTypeCollectionIdentifiers = proposalTypeCollection.map(
        proposalTypeItem => this.getProposalTypeIdentifier(proposalTypeItem)!
      );
      const proposalTypesToAdd = proposalTypes.filter(proposalTypeItem => {
        const proposalTypeIdentifier = this.getProposalTypeIdentifier(proposalTypeItem);
        if (proposalTypeCollectionIdentifiers.includes(proposalTypeIdentifier)) {
          return false;
        }
        proposalTypeCollectionIdentifiers.push(proposalTypeIdentifier);
        return true;
      });
      return [...proposalTypesToAdd, ...proposalTypeCollection];
    }
    return proposalTypeCollection;
  }
}
