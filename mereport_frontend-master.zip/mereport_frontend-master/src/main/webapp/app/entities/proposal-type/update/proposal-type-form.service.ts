import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { IProposalType, NewProposalType } from '../proposal-type.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IProposalType for edit and NewProposalTypeFormGroupInput for create.
 */
type ProposalTypeFormGroupInput = IProposalType | PartialWithRequiredKeyOf<NewProposalType>;

type ProposalTypeFormDefaults = Pick<NewProposalType, 'id'>;

type ProposalTypeFormGroupContent = {
  id: FormControl<IProposalType['id'] | NewProposalType['id']>;
  name: FormControl<IProposalType['name']>;
};

export type ProposalTypeFormGroup = FormGroup<ProposalTypeFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class ProposalTypeFormService {
  createProposalTypeFormGroup(proposalType: ProposalTypeFormGroupInput = { id: null }): ProposalTypeFormGroup {
    const proposalTypeRawValue = {
      ...this.getFormDefaults(),
      ...proposalType,
    };
    return new FormGroup<ProposalTypeFormGroupContent>({
      id: new FormControl(
        { value: proposalTypeRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(proposalTypeRawValue.name, {
        validators: [Validators.required],
      }),
    });
  }

  getProposalType(form: ProposalTypeFormGroup): IProposalType | NewProposalType {
    return form.getRawValue() as IProposalType | NewProposalType;
  }

  resetForm(form: ProposalTypeFormGroup, proposalType: ProposalTypeFormGroupInput): void {
    const proposalTypeRawValue = { ...this.getFormDefaults(), ...proposalType };
    form.reset(
      {
        ...proposalTypeRawValue,
        id: { value: proposalTypeRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): ProposalTypeFormDefaults {
    return {
      id: null,
    };
  }
}
