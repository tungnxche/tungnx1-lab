import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { ProposalTypeFormService, ProposalTypeFormGroup } from './proposal-type-form.service';
import { IProposalType } from '../proposal-type.model';
import { ProposalTypeService } from '../service/proposal-type.service';

@Component({
  selector: 'jhi-proposal-type-update',
  templateUrl: './proposal-type-update.component.html',
})
export class ProposalTypeUpdateComponent implements OnInit {
  isSaving = false;
  proposalType: IProposalType | null = null;

  editForm: ProposalTypeFormGroup = this.proposalTypeFormService.createProposalTypeFormGroup();

  constructor(
    protected proposalTypeService: ProposalTypeService,
    protected proposalTypeFormService: ProposalTypeFormService,
    protected activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ proposalType }) => {
      this.proposalType = proposalType;
      if (proposalType) {
        this.updateForm(proposalType);
      }
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const proposalType = this.proposalTypeFormService.getProposalType(this.editForm);
    if (proposalType.id !== null) {
      this.subscribeToSaveResponse(this.proposalTypeService.update(proposalType));
    } else {
      this.subscribeToSaveResponse(this.proposalTypeService.create(proposalType));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProposalType>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(proposalType: IProposalType): void {
    this.proposalType = proposalType;
    this.proposalTypeFormService.resetForm(this.editForm, proposalType);
  }
}
