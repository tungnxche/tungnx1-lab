import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../proposal-type.test-samples';

import { ProposalTypeFormService } from './proposal-type-form.service';

describe('ProposalType Form Service', () => {
  let service: ProposalTypeFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProposalTypeFormService);
  });

  describe('Service methods', () => {
    describe('createProposalTypeFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createProposalTypeFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });

      it('passing IProposalType should create a new form with FormGroup', () => {
        const formGroup = service.createProposalTypeFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });
    });

    describe('getProposalType', () => {
      it('should return NewProposalType for default ProposalType initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createProposalTypeFormGroup(sampleWithNewData);

        const proposalType = service.getProposalType(formGroup) as any;

        expect(proposalType).toMatchObject(sampleWithNewData);
      });

      it('should return NewProposalType for empty ProposalType initial value', () => {
        const formGroup = service.createProposalTypeFormGroup();

        const proposalType = service.getProposalType(formGroup) as any;

        expect(proposalType).toMatchObject({});
      });

      it('should return IProposalType', () => {
        const formGroup = service.createProposalTypeFormGroup(sampleWithRequiredData);

        const proposalType = service.getProposalType(formGroup) as any;

        expect(proposalType).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IProposalType should not enable id FormControl', () => {
        const formGroup = service.createProposalTypeFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewProposalType should disable id FormControl', () => {
        const formGroup = service.createProposalTypeFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
