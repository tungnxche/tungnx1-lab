export interface IProposalType {
  id: number;
  name?: string | null;
}

export type NewProposalType = Omit<IProposalType, 'id'> & { id: null };
