import { IProposalType, NewProposalType } from './proposal-type.model';

export const sampleWithRequiredData: IProposalType = {
  id: 82337,
  name: 'Steel',
};

export const sampleWithPartialData: IProposalType = {
  id: 50161,
  name: 'withdrawal Granite convergence',
};

export const sampleWithFullData: IProposalType = {
  id: 81470,
  name: 'services EXE',
};

export const sampleWithNewData: NewProposalType = {
  name: 'wireless moderator',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
