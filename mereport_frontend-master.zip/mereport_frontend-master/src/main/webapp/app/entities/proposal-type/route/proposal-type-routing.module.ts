import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ProposalTypeComponent } from '../list/proposal-type.component';
import { ProposalTypeDetailComponent } from '../detail/proposal-type-detail.component';
import { ProposalTypeUpdateComponent } from '../update/proposal-type-update.component';
import { ProposalTypeRoutingResolveService } from './proposal-type-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const proposalTypeRoute: Routes = [
  {
    path: '',
    component: ProposalTypeComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: ProposalTypeDetailComponent,
    resolve: {
      proposalType: ProposalTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: ProposalTypeUpdateComponent,
    resolve: {
      proposalType: ProposalTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: ProposalTypeUpdateComponent,
    resolve: {
      proposalType: ProposalTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(proposalTypeRoute)],
  exports: [RouterModule],
})
export class ProposalTypeRoutingModule {}
