import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../bidding-pck.test-samples';

import { BiddingPckFormService } from './bidding-pck-form.service';

describe('BiddingPck Form Service', () => {
  let service: BiddingPckFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiddingPckFormService);
  });

  describe('Service methods', () => {
    describe('createBiddingPckFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createBiddingPckFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            description: expect.any(Object),
            publishedDate: expect.any(Object),
            submissionEndDate: expect.any(Object),
            evalReportBy: expect.any(Object),
            evalReportDate: expect.any(Object),
            evalReportFile: expect.any(Object),
            winProposal: expect.any(Object),
            totalValue: expect.any(Object),
            avgValue: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            biddingPckType: expect.any(Object),
            project: expect.any(Object),
          })
        );
      });

      it('passing IBiddingPck should create a new form with FormGroup', () => {
        const formGroup = service.createBiddingPckFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            description: expect.any(Object),
            publishedDate: expect.any(Object),
            submissionEndDate: expect.any(Object),
            evalReportBy: expect.any(Object),
            evalReportDate: expect.any(Object),
            evalReportFile: expect.any(Object),
            winProposal: expect.any(Object),
            totalValue: expect.any(Object),
            avgValue: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            biddingPckType: expect.any(Object),
            project: expect.any(Object),
          })
        );
      });
    });

    describe('getBiddingPck', () => {
      it('should return NewBiddingPck for default BiddingPck initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createBiddingPckFormGroup(sampleWithNewData);

        const biddingPck = service.getBiddingPck(formGroup) as any;

        expect(biddingPck).toMatchObject(sampleWithNewData);
      });

      it('should return NewBiddingPck for empty BiddingPck initial value', () => {
        const formGroup = service.createBiddingPckFormGroup();

        const biddingPck = service.getBiddingPck(formGroup) as any;

        expect(biddingPck).toMatchObject({});
      });

      it('should return IBiddingPck', () => {
        const formGroup = service.createBiddingPckFormGroup(sampleWithRequiredData);

        const biddingPck = service.getBiddingPck(formGroup) as any;

        expect(biddingPck).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IBiddingPck should not enable id FormControl', () => {
        const formGroup = service.createBiddingPckFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewBiddingPck should disable id FormControl', () => {
        const formGroup = service.createBiddingPckFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
