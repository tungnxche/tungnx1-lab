import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { BiddingPckDetailComponent } from './bidding-pck-detail.component';

describe('BiddingPck Management Detail Component', () => {
  let comp: BiddingPckDetailComponent;
  let fixture: ComponentFixture<BiddingPckDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BiddingPckDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ biddingPck: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(BiddingPckDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(BiddingPckDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load biddingPck on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.biddingPck).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
