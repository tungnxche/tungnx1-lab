import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { BiddingPckFormService } from './bidding-pck-form.service';
import { BiddingPckService } from '../service/bidding-pck.service';
import { IBiddingPck } from '../bidding-pck.model';
import { IBiddingPckType } from 'app/entities/bidding-pck-type/bidding-pck-type.model';
import { BiddingPckTypeService } from 'app/entities/bidding-pck-type/service/bidding-pck-type.service';
import { IProject } from 'app/entities/project/project.model';
import { ProjectService } from 'app/entities/project/service/project.service';

import { BiddingPckUpdateComponent } from './bidding-pck-update.component';

describe('BiddingPck Management Update Component', () => {
  let comp: BiddingPckUpdateComponent;
  let fixture: ComponentFixture<BiddingPckUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let biddingPckFormService: BiddingPckFormService;
  let biddingPckService: BiddingPckService;
  let biddingPckTypeService: BiddingPckTypeService;
  let projectService: ProjectService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [BiddingPckUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(BiddingPckUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingPckUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    biddingPckFormService = TestBed.inject(BiddingPckFormService);
    biddingPckService = TestBed.inject(BiddingPckService);
    biddingPckTypeService = TestBed.inject(BiddingPckTypeService);
    projectService = TestBed.inject(ProjectService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should call BiddingPckType query and add missing value', () => {
      const biddingPck: IBiddingPck = { id: 456 };
      const biddingPckType: IBiddingPckType = { id: 70902 };
      biddingPck.biddingPckType = biddingPckType;

      const biddingPckTypeCollection: IBiddingPckType[] = [{ id: 58080 }];
      jest.spyOn(biddingPckTypeService, 'query').mockReturnValue(of(new HttpResponse({ body: biddingPckTypeCollection })));
      const additionalBiddingPckTypes = [biddingPckType];
      const expectedCollection: IBiddingPckType[] = [...additionalBiddingPckTypes, ...biddingPckTypeCollection];
      jest.spyOn(biddingPckTypeService, 'addBiddingPckTypeToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingPck });
      comp.ngOnInit();

      expect(biddingPckTypeService.query).toHaveBeenCalled();
      expect(biddingPckTypeService.addBiddingPckTypeToCollectionIfMissing).toHaveBeenCalledWith(
        biddingPckTypeCollection,
        ...additionalBiddingPckTypes.map(expect.objectContaining)
      );
      expect(comp.biddingPckTypesSharedCollection).toEqual(expectedCollection);
    });

    it('Should call Project query and add missing value', () => {
      const biddingPck: IBiddingPck = { id: 456 };
      const project: IProject = { id: 2722 };
      biddingPck.project = project;

      const projectCollection: IProject[] = [{ id: 70933 }];
      jest.spyOn(projectService, 'query').mockReturnValue(of(new HttpResponse({ body: projectCollection })));
      const additionalProjects = [project];
      const expectedCollection: IProject[] = [...additionalProjects, ...projectCollection];
      jest.spyOn(projectService, 'addProjectToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingPck });
      comp.ngOnInit();

      expect(projectService.query).toHaveBeenCalled();
      expect(projectService.addProjectToCollectionIfMissing).toHaveBeenCalledWith(
        projectCollection,
        ...additionalProjects.map(expect.objectContaining)
      );
      expect(comp.projectsSharedCollection).toEqual(expectedCollection);
    });

    it('Should update editForm', () => {
      const biddingPck: IBiddingPck = { id: 456 };
      const biddingPckType: IBiddingPckType = { id: 3337 };
      biddingPck.biddingPckType = biddingPckType;
      const project: IProject = { id: 97319 };
      biddingPck.project = project;

      activatedRoute.data = of({ biddingPck });
      comp.ngOnInit();

      expect(comp.biddingPckTypesSharedCollection).toContain(biddingPckType);
      expect(comp.projectsSharedCollection).toContain(project);
      expect(comp.biddingPck).toEqual(biddingPck);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPck>>();
      const biddingPck = { id: 123 };
      jest.spyOn(biddingPckFormService, 'getBiddingPck').mockReturnValue(biddingPck);
      jest.spyOn(biddingPckService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPck });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingPck }));
      saveSubject.complete();

      // THEN
      expect(biddingPckFormService.getBiddingPck).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(biddingPckService.update).toHaveBeenCalledWith(expect.objectContaining(biddingPck));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPck>>();
      const biddingPck = { id: 123 };
      jest.spyOn(biddingPckFormService, 'getBiddingPck').mockReturnValue({ id: null });
      jest.spyOn(biddingPckService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPck: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingPck }));
      saveSubject.complete();

      // THEN
      expect(biddingPckFormService.getBiddingPck).toHaveBeenCalled();
      expect(biddingPckService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPck>>();
      const biddingPck = { id: 123 };
      jest.spyOn(biddingPckService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPck });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(biddingPckService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });

  describe('Compare relationships', () => {
    describe('compareBiddingPckType', () => {
      it('Should forward to biddingPckTypeService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(biddingPckTypeService, 'compareBiddingPckType');
        comp.compareBiddingPckType(entity, entity2);
        expect(biddingPckTypeService.compareBiddingPckType).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareProject', () => {
      it('Should forward to projectService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(projectService, 'compareProject');
        comp.compareProject(entity, entity2);
        expect(projectService.compareProject).toHaveBeenCalledWith(entity, entity2);
      });
    });
  });
});
