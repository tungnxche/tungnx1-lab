import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import dayjs from 'dayjs/esm';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IBiddingPck, NewBiddingPck } from '../bidding-pck.model';

export type PartialUpdateBiddingPck = Partial<IBiddingPck> & Pick<IBiddingPck, 'id'>;

type RestOf<T extends IBiddingPck | NewBiddingPck> = Omit<
  T,
  'publishedDate' | 'submissionEndDate' | 'evalReportDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'
> & {
  publishedDate?: string | null;
  submissionEndDate?: string | null;
  evalReportDate?: string | null;
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

export type RestBiddingPcks = {
  list: RestBiddingPck[];
  sum: number;
};

export type RestBiddingPck = RestOf<IBiddingPck>;

export type NewRestBiddingPck = RestOf<NewBiddingPck>;

export type PartialUpdateRestBiddingPck = RestOf<PartialUpdateBiddingPck>;

export type EntityResponseType = HttpResponse<IBiddingPck>;
export type EntityArrayResponseType = HttpResponse<IBiddingPck[]>;

@Injectable({ providedIn: 'root' })
export class BiddingPckService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/bidding-pcks');
  protected urlGetSum = this.applicationConfigService.getEndpointFor('api/bidding-pcks-by-prj');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(biddingPck: NewBiddingPck): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingPck);
    return this.http
      .post<RestBiddingPck>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(biddingPck: IBiddingPck): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingPck);
    return this.http
      .put<RestBiddingPck>(`${this.resourceUrl}/${this.getBiddingPckIdentifier(biddingPck)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(biddingPck: PartialUpdateBiddingPck): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingPck);
    return this.http
      .patch<RestBiddingPck>(`${this.resourceUrl}/${this.getBiddingPckIdentifier(biddingPck)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestBiddingPck>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestBiddingPck[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  querySum(req?: any): Observable<HttpResponse<number>> {
    const options = createRequestOption(req);
    return this.http
      .get<RestBiddingPcks>(this.urlGetSum, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseSumArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getBiddingPckIdentifier(biddingPck: Pick<IBiddingPck, 'id'>): number {
    return biddingPck.id;
  }

  compareBiddingPck(o1: Pick<IBiddingPck, 'id'> | null, o2: Pick<IBiddingPck, 'id'> | null): boolean {
    return o1 && o2 ? this.getBiddingPckIdentifier(o1) === this.getBiddingPckIdentifier(o2) : o1 === o2;
  }

  addBiddingPckToCollectionIfMissing<Type extends Pick<IBiddingPck, 'id'>>(
    biddingPckCollection: Type[],
    ...biddingPcksToCheck: (Type | null | undefined)[]
  ): Type[] {
    const biddingPcks: Type[] = biddingPcksToCheck.filter(isPresent);
    if (biddingPcks.length > 0) {
      const biddingPckCollectionIdentifiers = biddingPckCollection.map(biddingPckItem => this.getBiddingPckIdentifier(biddingPckItem)!);
      const biddingPcksToAdd = biddingPcks.filter(biddingPckItem => {
        const biddingPckIdentifier = this.getBiddingPckIdentifier(biddingPckItem);
        if (biddingPckCollectionIdentifiers.includes(biddingPckIdentifier)) {
          return false;
        }
        biddingPckCollectionIdentifiers.push(biddingPckIdentifier);
        return true;
      });
      return [...biddingPcksToAdd, ...biddingPckCollection];
    }
    return biddingPckCollection;
  }

  protected convertDateFromClient<T extends IBiddingPck | NewBiddingPck | PartialUpdateBiddingPck>(biddingPck: T): RestOf<T> {
    return {
      ...biddingPck,
      publishedDate: biddingPck.publishedDate?.toJSON() ?? null,
      submissionEndDate: biddingPck.submissionEndDate?.toJSON() ?? null,
      evalReportDate: biddingPck.evalReportDate?.toJSON() ?? null,
      createdOn: biddingPck.createdOn?.toJSON() ?? null,
      modifiedOn: biddingPck.modifiedOn?.toJSON() ?? null,
      deletedOn: biddingPck.deletedOn?.toJSON() ?? null,
    };
  }

  protected convertDateFromServer(restBiddingPck: RestBiddingPck): IBiddingPck {
    return {
      ...restBiddingPck,
      publishedDate: restBiddingPck.publishedDate ? dayjs(restBiddingPck.publishedDate) : undefined,
      submissionEndDate: restBiddingPck.submissionEndDate ? dayjs(restBiddingPck.submissionEndDate) : undefined,
      evalReportDate: restBiddingPck.evalReportDate ? dayjs(restBiddingPck.evalReportDate) : undefined,
      createdOn: restBiddingPck.createdOn ? dayjs(restBiddingPck.createdOn) : undefined,
      modifiedOn: restBiddingPck.modifiedOn ? dayjs(restBiddingPck.modifiedOn) : undefined,
      deletedOn: restBiddingPck.deletedOn ? dayjs(restBiddingPck.deletedOn) : undefined,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestBiddingPck>): HttpResponse<IBiddingPck> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestBiddingPck[]>): HttpResponse<IBiddingPck[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }

  protected convertResponseSumArrayFromServer(res: HttpResponse<RestBiddingPcks>): HttpResponse<number> {
    return res.clone({
      body: res.body && res.body.sum ? res.body.sum : 0,
    });
  }
}
