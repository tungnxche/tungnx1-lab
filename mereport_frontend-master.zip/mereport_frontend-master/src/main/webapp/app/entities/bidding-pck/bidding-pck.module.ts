import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { BiddingPckComponent } from './list/bidding-pck.component';
import { BiddingPckDetailComponent } from './detail/bidding-pck-detail.component';
import { BiddingPckUpdateComponent } from './update/bidding-pck-update.component';
import { BiddingPckDeleteDialogComponent } from './delete/bidding-pck-delete-dialog.component';
import { BiddingPckRoutingModule } from './route/bidding-pck-routing.module';

@NgModule({
  imports: [SharedModule, BiddingPckRoutingModule],
  declarations: [BiddingPckComponent, BiddingPckDetailComponent, BiddingPckUpdateComponent, BiddingPckDeleteDialogComponent],
})
export class BiddingPckModule {}
