import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IBiddingPck, NewBiddingPck } from '../bidding-pck.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IBiddingPck for edit and NewBiddingPckFormGroupInput for create.
 */
type BiddingPckFormGroupInput = IBiddingPck | PartialWithRequiredKeyOf<NewBiddingPck>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IBiddingPck | NewBiddingPck> = Omit<
  T,
  'publishedDate' | 'submissionEndDate' | 'evalReportDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'
> & {
  publishedDate?: string | null;
  submissionEndDate?: string | null;
  evalReportDate?: string | null;
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type BiddingPckFormRawValue = FormValueOf<IBiddingPck>;

type NewBiddingPckFormRawValue = FormValueOf<NewBiddingPck>;

type BiddingPckFormDefaults = Pick<
  NewBiddingPck,
  'id' | 'publishedDate' | 'submissionEndDate' | 'evalReportDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'
>;

type BiddingPckFormGroupContent = {
  id: FormControl<BiddingPckFormRawValue['id'] | NewBiddingPck['id']>;
  name: FormControl<BiddingPckFormRawValue['name']>;
  description: FormControl<BiddingPckFormRawValue['description']>;
  publishedDate: FormControl<BiddingPckFormRawValue['publishedDate']>;
  submissionEndDate: FormControl<BiddingPckFormRawValue['submissionEndDate']>;
  evalReportBy: FormControl<BiddingPckFormRawValue['evalReportBy']>;
  evalReportDate: FormControl<BiddingPckFormRawValue['evalReportDate']>;
  evalReportFile: FormControl<BiddingPckFormRawValue['evalReportFile']>;
  winProposal: FormControl<BiddingPckFormRawValue['winProposal']>;
  totalValue: FormControl<BiddingPckFormRawValue['totalValue']>;
  avgValue: FormControl<BiddingPckFormRawValue['avgValue']>;
  createdBy: FormControl<BiddingPckFormRawValue['createdBy']>;
  createdOn: FormControl<BiddingPckFormRawValue['createdOn']>;
  modifiedBy: FormControl<BiddingPckFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<BiddingPckFormRawValue['modifiedOn']>;
  deletedBy: FormControl<BiddingPckFormRawValue['deletedBy']>;
  deletedOn: FormControl<BiddingPckFormRawValue['deletedOn']>;
  biddingPckType: FormControl<BiddingPckFormRawValue['biddingPckType']>;
  project: FormControl<BiddingPckFormRawValue['project']>;
};

export type BiddingPckFormGroup = FormGroup<BiddingPckFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class BiddingPckFormService {
  createBiddingPckFormGroup(biddingPck: BiddingPckFormGroupInput = { id: null }): BiddingPckFormGroup {
    const biddingPckRawValue = this.convertBiddingPckToBiddingPckRawValue({
      ...this.getFormDefaults(),
      ...biddingPck,
    });
    return new FormGroup<BiddingPckFormGroupContent>({
      id: new FormControl(
        { value: biddingPckRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(biddingPckRawValue.name, {
        validators: [Validators.required],
      }),
      description: new FormControl(biddingPckRawValue.description),
      publishedDate: new FormControl(biddingPckRawValue.publishedDate),
      submissionEndDate: new FormControl(biddingPckRawValue.submissionEndDate),
      evalReportBy: new FormControl(biddingPckRawValue.evalReportBy),
      evalReportDate: new FormControl(biddingPckRawValue.evalReportDate),
      evalReportFile: new FormControl(biddingPckRawValue.evalReportFile),
      winProposal: new FormControl(biddingPckRawValue.winProposal),
      totalValue: new FormControl(biddingPckRawValue.totalValue),
      avgValue: new FormControl(biddingPckRawValue.avgValue),
      createdBy: new FormControl(biddingPckRawValue.createdBy),
      createdOn: new FormControl(biddingPckRawValue.createdOn),
      modifiedBy: new FormControl(biddingPckRawValue.modifiedBy),
      modifiedOn: new FormControl(biddingPckRawValue.modifiedOn),
      deletedBy: new FormControl(biddingPckRawValue.deletedBy),
      deletedOn: new FormControl(biddingPckRawValue.deletedOn),
      biddingPckType: new FormControl(biddingPckRawValue.biddingPckType),
      project: new FormControl(biddingPckRawValue.project),
    });
  }

  getBiddingPck(form: BiddingPckFormGroup): IBiddingPck | NewBiddingPck {
    return this.convertBiddingPckRawValueToBiddingPck(form.getRawValue() as BiddingPckFormRawValue | NewBiddingPckFormRawValue);
  }

  resetForm(form: BiddingPckFormGroup, biddingPck: BiddingPckFormGroupInput): void {
    const biddingPckRawValue = this.convertBiddingPckToBiddingPckRawValue({ ...this.getFormDefaults(), ...biddingPck });
    form.reset(
      {
        ...biddingPckRawValue,
        id: { value: biddingPckRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): BiddingPckFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      publishedDate: currentTime,
      submissionEndDate: currentTime,
      evalReportDate: currentTime,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertBiddingPckRawValueToBiddingPck(
    rawBiddingPck: BiddingPckFormRawValue | NewBiddingPckFormRawValue
  ): IBiddingPck | NewBiddingPck {
    return {
      ...rawBiddingPck,
      publishedDate: dayjs(rawBiddingPck.publishedDate, DATE_TIME_FORMAT),
      submissionEndDate: dayjs(rawBiddingPck.submissionEndDate, DATE_TIME_FORMAT),
      evalReportDate: dayjs(rawBiddingPck.evalReportDate, DATE_TIME_FORMAT),
      createdOn: dayjs(rawBiddingPck.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawBiddingPck.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawBiddingPck.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertBiddingPckToBiddingPckRawValue(
    biddingPck: IBiddingPck | (Partial<NewBiddingPck> & BiddingPckFormDefaults)
  ): BiddingPckFormRawValue | PartialWithRequiredKeyOf<NewBiddingPckFormRawValue> {
    return {
      ...biddingPck,
      publishedDate: biddingPck.publishedDate ? biddingPck.publishedDate.format(DATE_TIME_FORMAT) : undefined,
      submissionEndDate: biddingPck.submissionEndDate ? biddingPck.submissionEndDate.format(DATE_TIME_FORMAT) : undefined,
      evalReportDate: biddingPck.evalReportDate ? biddingPck.evalReportDate.format(DATE_TIME_FORMAT) : undefined,
      createdOn: biddingPck.createdOn ? biddingPck.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: biddingPck.modifiedOn ? biddingPck.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: biddingPck.deletedOn ? biddingPck.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
