import dayjs from 'dayjs/esm';

import { IBiddingPck, NewBiddingPck } from './bidding-pck.model';

export const sampleWithRequiredData: IBiddingPck = {
  id: 80066,
  name: 'Mouse',
};

export const sampleWithPartialData: IBiddingPck = {
  id: 12747,
  name: 'Tasty back-end exuding',
  description: 'iterate',
  submissionEndDate: dayjs('2022-09-28T14:55'),
  evalReportBy: 'deposit channels Sausages',
  evalReportFile: 'Car olive e-services',
  winProposal: 71439,
  totalValue: 77582,
  avgValue: 20614,
  modifiedBy: 94746,
  deletedBy: 56591,
  deletedOn: dayjs('2022-09-29T01:30'),
};

export const sampleWithFullData: IBiddingPck = {
  id: 22430,
  name: 'implement',
  description: 'Granite',
  publishedDate: dayjs('2022-09-28T20:30'),
  submissionEndDate: dayjs('2022-09-29T02:05'),
  evalReportBy: 'Open-source',
  evalReportDate: dayjs('2022-09-29T05:22'),
  evalReportFile: 'Market website 24/7',
  winProposal: 58807,
  totalValue: 8607,
  avgValue: 39499,
  createdBy: 38561,
  createdOn: dayjs('2022-09-28T13:12'),
  modifiedBy: 92225,
  modifiedOn: dayjs('2022-09-28T10:04'),
  deletedBy: 33572,
  deletedOn: dayjs('2022-09-28T18:18'),
};

export const sampleWithNewData: NewBiddingPck = {
  name: 'Credit',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
