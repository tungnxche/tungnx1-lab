import dayjs from 'dayjs/esm';
import { IBiddingPckType } from 'app/entities/bidding-pck-type/bidding-pck-type.model';
import { IProject } from 'app/entities/project/project.model';
import { IBiddingProposal } from '../bidding-proposal/bidding-proposal.model';

export interface IBiddingPck {
  id: number;
  name?: string | null;
  description?: string | null;
  publishedDate?: dayjs.Dayjs | null;
  submissionEndDate?: dayjs.Dayjs | null;
  evalReportBy?: string | null;
  evalReportDate?: dayjs.Dayjs | null;
  evalReportFile?: string | null;
  winProposal?: number | null;
  winProposalName?: string;
  totalValue?: number | null;
  avgValue?: number | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
  biddingPckType?: Pick<IBiddingPckType, 'id' | 'name'> | null;
  biddingProposals?: Pick<IBiddingProposal, 'id' | 'name'>[] | null;
  project?: Pick<IProject, 'id'> | null;
}

export type NewBiddingPck = Omit<IBiddingPck, 'id'> & { id: null };
