import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IBiddingPck } from '../bidding-pck.model';
import { BiddingPckService } from '../service/bidding-pck.service';

@Injectable({ providedIn: 'root' })
export class BiddingPckRoutingResolveService implements Resolve<IBiddingPck | null> {
  constructor(protected service: BiddingPckService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IBiddingPck | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((biddingPck: HttpResponse<IBiddingPck>) => {
          if (biddingPck.body) {
            return of(biddingPck.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
