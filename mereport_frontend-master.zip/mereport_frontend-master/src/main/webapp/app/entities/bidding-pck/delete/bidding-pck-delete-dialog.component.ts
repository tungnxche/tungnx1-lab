import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IBiddingPck } from '../bidding-pck.model';
import { BiddingPckService } from '../service/bidding-pck.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './bidding-pck-delete-dialog.component.html',
})
export class BiddingPckDeleteDialogComponent {
  biddingPck?: IBiddingPck;

  constructor(protected biddingPckService: BiddingPckService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.biddingPckService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
