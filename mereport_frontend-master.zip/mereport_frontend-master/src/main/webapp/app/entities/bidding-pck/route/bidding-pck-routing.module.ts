import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { BiddingPckComponent } from '../list/bidding-pck.component';
import { BiddingPckDetailComponent } from '../detail/bidding-pck-detail.component';
import { BiddingPckUpdateComponent } from '../update/bidding-pck-update.component';
import { BiddingPckRoutingResolveService } from './bidding-pck-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const biddingPckRoute: Routes = [
  {
    path: '',
    component: BiddingPckComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: BiddingPckDetailComponent,
    resolve: {
      biddingPck: BiddingPckRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BiddingPckUpdateComponent,
    resolve: {
      biddingPck: BiddingPckRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: BiddingPckUpdateComponent,
    resolve: {
      biddingPck: BiddingPckRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(biddingPckRoute)],
  exports: [RouterModule],
})
export class BiddingPckRoutingModule {}
