import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { BiddingPckFormService, BiddingPckFormGroup } from './bidding-pck-form.service';
import { IBiddingPck } from '../bidding-pck.model';
import { BiddingPckService } from '../service/bidding-pck.service';
import { IBiddingPckType } from 'app/entities/bidding-pck-type/bidding-pck-type.model';
import { BiddingPckTypeService } from 'app/entities/bidding-pck-type/service/bidding-pck-type.service';
import { IProject } from 'app/entities/project/project.model';
import { ProjectService } from 'app/entities/project/service/project.service';

@Component({
  selector: 'jhi-bidding-pck-update',
  templateUrl: './bidding-pck-update.component.html',
})
export class BiddingPckUpdateComponent implements OnInit {
  isSaving = false;
  biddingPck: IBiddingPck | null = null;

  biddingPckTypesSharedCollection: IBiddingPckType[] = [];
  projectsSharedCollection: IProject[] = [];

  editForm: BiddingPckFormGroup = this.biddingPckFormService.createBiddingPckFormGroup();

  constructor(
    protected biddingPckService: BiddingPckService,
    protected biddingPckFormService: BiddingPckFormService,
    protected biddingPckTypeService: BiddingPckTypeService,
    protected projectService: ProjectService,
    protected activatedRoute: ActivatedRoute
  ) {}

  compareBiddingPckType = (o1: IBiddingPckType | null, o2: IBiddingPckType | null): boolean =>
    this.biddingPckTypeService.compareBiddingPckType(o1, o2);

  compareProject = (o1: IProject | null, o2: IProject | null): boolean => this.projectService.compareProject(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingPck }) => {
      this.biddingPck = biddingPck;
      if (biddingPck) {
        this.updateForm(biddingPck);
      }

      this.loadRelationshipsOptions();
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const biddingPck = this.biddingPckFormService.getBiddingPck(this.editForm);
    if (biddingPck.id !== null) {
      this.subscribeToSaveResponse(this.biddingPckService.update(biddingPck));
    } else {
      this.subscribeToSaveResponse(this.biddingPckService.create(biddingPck));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBiddingPck>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(biddingPck: IBiddingPck): void {
    this.biddingPck = biddingPck;
    this.biddingPckFormService.resetForm(this.editForm, biddingPck);

    this.biddingPckTypesSharedCollection = this.biddingPckTypeService.addBiddingPckTypeToCollectionIfMissing<IBiddingPckType>(
      this.biddingPckTypesSharedCollection,
      biddingPck.biddingPckType
    );
    this.projectsSharedCollection = this.projectService.addProjectToCollectionIfMissing<IProject>(
      this.projectsSharedCollection,
      biddingPck.project
    );
  }

  protected loadRelationshipsOptions(): void {
    this.biddingPckTypeService
      .query()
      .pipe(map((res: HttpResponse<IBiddingPckType[]>) => res.body ?? []))
      .pipe(
        map((biddingPckTypes: IBiddingPckType[]) =>
          this.biddingPckTypeService.addBiddingPckTypeToCollectionIfMissing<IBiddingPckType>(
            biddingPckTypes,
            this.biddingPck?.biddingPckType
          )
        )
      )
      .subscribe((biddingPckTypes: IBiddingPckType[]) => (this.biddingPckTypesSharedCollection = biddingPckTypes));

    this.projectService
      .query()
      .pipe(map((res: HttpResponse<IProject[]>) => res.body ?? []))
      .pipe(
        map((projects: IProject[]) => this.projectService.addProjectToCollectionIfMissing<IProject>(projects, this.biddingPck?.project))
      )
      .subscribe((projects: IProject[]) => (this.projectsSharedCollection = projects));
  }
}
