import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';

import { BiddingStatusService } from '../service/bidding-status.service';

import { BiddingStatusComponent } from './bidding-status.component';

describe('BiddingStatus Management Component', () => {
  let comp: BiddingStatusComponent;
  let fixture: ComponentFixture<BiddingStatusComponent>;
  let service: BiddingStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([{ path: 'bidding-status', component: BiddingStatusComponent }]), HttpClientTestingModule],
      declarations: [BiddingStatusComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({
              defaultSort: 'id,asc',
            }),
            queryParamMap: of(
              jest.requireActual('@angular/router').convertToParamMap({
                page: '1',
                size: '1',
                sort: 'id,desc',
              })
            ),
            snapshot: { queryParams: {} },
          },
        },
      ],
    })
      .overrideTemplate(BiddingStatusComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingStatusComponent);
    comp = fixture.componentInstance;
    service = TestBed.inject(BiddingStatusService);

    const headers = new HttpHeaders();
    jest.spyOn(service, 'query').mockReturnValue(
      of(
        new HttpResponse({
          body: [{ id: 123 }],
          headers,
        })
      )
    );
  });

  it('Should call load all on init', () => {
    // WHEN
    comp.ngOnInit();

    // THEN
    expect(service.query).toHaveBeenCalled();
    expect(comp.biddingStatuses?.[0]).toEqual(expect.objectContaining({ id: 123 }));
  });

  describe('trackId', () => {
    it('Should forward to biddingStatusService', () => {
      const entity = { id: 123 };
      jest.spyOn(service, 'getBiddingStatusIdentifier');
      const id = comp.trackId(0, entity);
      expect(service.getBiddingStatusIdentifier).toHaveBeenCalledWith(entity);
      expect(id).toBe(entity.id);
    });
  });
});
