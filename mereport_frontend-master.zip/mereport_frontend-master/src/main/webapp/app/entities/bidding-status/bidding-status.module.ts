import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { BiddingStatusComponent } from './list/bidding-status.component';
import { BiddingStatusDetailComponent } from './detail/bidding-status-detail.component';
import { BiddingStatusUpdateComponent } from './update/bidding-status-update.component';
import { BiddingStatusDeleteDialogComponent } from './delete/bidding-status-delete-dialog.component';
import { BiddingStatusRoutingModule } from './route/bidding-status-routing.module';

@NgModule({
  imports: [SharedModule, BiddingStatusRoutingModule],
  declarations: [BiddingStatusComponent, BiddingStatusDetailComponent, BiddingStatusUpdateComponent, BiddingStatusDeleteDialogComponent],
})
export class BiddingStatusModule {}
