import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IBiddingStatus } from '../bidding-status.model';
import { BiddingStatusService } from '../service/bidding-status.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './bidding-status-delete-dialog.component.html',
})
export class BiddingStatusDeleteDialogComponent {
  biddingStatus?: IBiddingStatus;

  constructor(protected biddingStatusService: BiddingStatusService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.biddingStatusService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
