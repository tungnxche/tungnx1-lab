export interface IBiddingStatus {
  id: number;
  name?: string | null;
}

export type NewBiddingStatus = Omit<IBiddingStatus, 'id'> & { id: null };
