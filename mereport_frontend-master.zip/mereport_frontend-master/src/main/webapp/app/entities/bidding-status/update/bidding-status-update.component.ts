import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { BiddingStatusFormService, BiddingStatusFormGroup } from './bidding-status-form.service';
import { IBiddingStatus } from '../bidding-status.model';
import { BiddingStatusService } from '../service/bidding-status.service';

@Component({
  selector: 'jhi-bidding-status-update',
  templateUrl: './bidding-status-update.component.html',
})
export class BiddingStatusUpdateComponent implements OnInit {
  isSaving = false;
  biddingStatus: IBiddingStatus | null = null;

  editForm: BiddingStatusFormGroup = this.biddingStatusFormService.createBiddingStatusFormGroup();

  constructor(
    protected biddingStatusService: BiddingStatusService,
    protected biddingStatusFormService: BiddingStatusFormService,
    protected activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingStatus }) => {
      this.biddingStatus = biddingStatus;
      if (biddingStatus) {
        this.updateForm(biddingStatus);
      }
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const biddingStatus = this.biddingStatusFormService.getBiddingStatus(this.editForm);
    if (biddingStatus.id !== null) {
      this.subscribeToSaveResponse(this.biddingStatusService.update(biddingStatus));
    } else {
      this.subscribeToSaveResponse(this.biddingStatusService.create(biddingStatus));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBiddingStatus>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(biddingStatus: IBiddingStatus): void {
    this.biddingStatus = biddingStatus;
    this.biddingStatusFormService.resetForm(this.editForm, biddingStatus);
  }
}
