import { IBiddingStatus, NewBiddingStatus } from './bidding-status.model';

export const sampleWithRequiredData: IBiddingStatus = {
  id: 68188,
  name: 'invoice deposit standardization',
};

export const sampleWithPartialData: IBiddingStatus = {
  id: 79461,
  name: 'Implementation bluetooth',
};

export const sampleWithFullData: IBiddingStatus = {
  id: 79708,
  name: 'didactic hacking visionary',
};

export const sampleWithNewData: NewBiddingStatus = {
  name: 'Investor Shoal',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
