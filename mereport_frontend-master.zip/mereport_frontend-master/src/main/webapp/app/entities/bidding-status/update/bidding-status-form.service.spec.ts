import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../bidding-status.test-samples';

import { BiddingStatusFormService } from './bidding-status-form.service';

describe('BiddingStatus Form Service', () => {
  let service: BiddingStatusFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiddingStatusFormService);
  });

  describe('Service methods', () => {
    describe('createBiddingStatusFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createBiddingStatusFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });

      it('passing IBiddingStatus should create a new form with FormGroup', () => {
        const formGroup = service.createBiddingStatusFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });
    });

    describe('getBiddingStatus', () => {
      it('should return NewBiddingStatus for default BiddingStatus initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createBiddingStatusFormGroup(sampleWithNewData);

        const biddingStatus = service.getBiddingStatus(formGroup) as any;

        expect(biddingStatus).toMatchObject(sampleWithNewData);
      });

      it('should return NewBiddingStatus for empty BiddingStatus initial value', () => {
        const formGroup = service.createBiddingStatusFormGroup();

        const biddingStatus = service.getBiddingStatus(formGroup) as any;

        expect(biddingStatus).toMatchObject({});
      });

      it('should return IBiddingStatus', () => {
        const formGroup = service.createBiddingStatusFormGroup(sampleWithRequiredData);

        const biddingStatus = service.getBiddingStatus(formGroup) as any;

        expect(biddingStatus).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IBiddingStatus should not enable id FormControl', () => {
        const formGroup = service.createBiddingStatusFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewBiddingStatus should disable id FormControl', () => {
        const formGroup = service.createBiddingStatusFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
