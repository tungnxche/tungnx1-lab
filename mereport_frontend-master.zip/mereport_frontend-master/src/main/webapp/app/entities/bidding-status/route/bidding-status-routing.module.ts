import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { BiddingStatusComponent } from '../list/bidding-status.component';
import { BiddingStatusDetailComponent } from '../detail/bidding-status-detail.component';
import { BiddingStatusUpdateComponent } from '../update/bidding-status-update.component';
import { BiddingStatusRoutingResolveService } from './bidding-status-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const biddingStatusRoute: Routes = [
  {
    path: '',
    component: BiddingStatusComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: BiddingStatusDetailComponent,
    resolve: {
      biddingStatus: BiddingStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BiddingStatusUpdateComponent,
    resolve: {
      biddingStatus: BiddingStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: BiddingStatusUpdateComponent,
    resolve: {
      biddingStatus: BiddingStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(biddingStatusRoute)],
  exports: [RouterModule],
})
export class BiddingStatusRoutingModule {}
