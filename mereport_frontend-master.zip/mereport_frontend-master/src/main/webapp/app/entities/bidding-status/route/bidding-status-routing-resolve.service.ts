import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IBiddingStatus } from '../bidding-status.model';
import { BiddingStatusService } from '../service/bidding-status.service';

@Injectable({ providedIn: 'root' })
export class BiddingStatusRoutingResolveService implements Resolve<IBiddingStatus | null> {
  constructor(protected service: BiddingStatusService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IBiddingStatus | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((biddingStatus: HttpResponse<IBiddingStatus>) => {
          if (biddingStatus.body) {
            return of(biddingStatus.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
