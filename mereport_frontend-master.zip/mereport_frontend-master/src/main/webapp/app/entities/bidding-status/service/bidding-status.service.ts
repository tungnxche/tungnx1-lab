import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IBiddingStatus, NewBiddingStatus } from '../bidding-status.model';

export type PartialUpdateBiddingStatus = Partial<IBiddingStatus> & Pick<IBiddingStatus, 'id'>;

export type EntityResponseType = HttpResponse<IBiddingStatus>;
export type EntityArrayResponseType = HttpResponse<IBiddingStatus[]>;

@Injectable({ providedIn: 'root' })
export class BiddingStatusService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/bidding-statuses');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(biddingStatus: NewBiddingStatus): Observable<EntityResponseType> {
    return this.http.post<IBiddingStatus>(this.resourceUrl, biddingStatus, { observe: 'response' });
  }

  update(biddingStatus: IBiddingStatus): Observable<EntityResponseType> {
    return this.http.put<IBiddingStatus>(`${this.resourceUrl}/${this.getBiddingStatusIdentifier(biddingStatus)}`, biddingStatus, {
      observe: 'response',
    });
  }

  partialUpdate(biddingStatus: PartialUpdateBiddingStatus): Observable<EntityResponseType> {
    return this.http.patch<IBiddingStatus>(`${this.resourceUrl}/${this.getBiddingStatusIdentifier(biddingStatus)}`, biddingStatus, {
      observe: 'response',
    });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IBiddingStatus>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IBiddingStatus[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getBiddingStatusIdentifier(biddingStatus: Pick<IBiddingStatus, 'id'>): number {
    return biddingStatus.id;
  }

  compareBiddingStatus(o1: Pick<IBiddingStatus, 'id'> | null, o2: Pick<IBiddingStatus, 'id'> | null): boolean {
    return o1 && o2 ? this.getBiddingStatusIdentifier(o1) === this.getBiddingStatusIdentifier(o2) : o1 === o2;
  }

  addBiddingStatusToCollectionIfMissing<Type extends Pick<IBiddingStatus, 'id'>>(
    biddingStatusCollection: Type[],
    ...biddingStatusesToCheck: (Type | null | undefined)[]
  ): Type[] {
    const biddingStatuses: Type[] = biddingStatusesToCheck.filter(isPresent);
    if (biddingStatuses.length > 0) {
      const biddingStatusCollectionIdentifiers = biddingStatusCollection.map(
        biddingStatusItem => this.getBiddingStatusIdentifier(biddingStatusItem)!
      );
      const biddingStatusesToAdd = biddingStatuses.filter(biddingStatusItem => {
        const biddingStatusIdentifier = this.getBiddingStatusIdentifier(biddingStatusItem);
        if (biddingStatusCollectionIdentifiers.includes(biddingStatusIdentifier)) {
          return false;
        }
        biddingStatusCollectionIdentifiers.push(biddingStatusIdentifier);
        return true;
      });
      return [...biddingStatusesToAdd, ...biddingStatusCollection];
    }
    return biddingStatusCollection;
  }
}
