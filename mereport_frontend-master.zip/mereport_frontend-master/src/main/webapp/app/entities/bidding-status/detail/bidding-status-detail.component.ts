import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IBiddingStatus } from '../bidding-status.model';

@Component({
  selector: 'jhi-bidding-status-detail',
  templateUrl: './bidding-status-detail.component.html',
})
export class BiddingStatusDetailComponent implements OnInit {
  biddingStatus: IBiddingStatus | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingStatus }) => {
      this.biddingStatus = biddingStatus;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
