import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { BiddingStatusDetailComponent } from './bidding-status-detail.component';

describe('BiddingStatus Management Detail Component', () => {
  let comp: BiddingStatusDetailComponent;
  let fixture: ComponentFixture<BiddingStatusDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BiddingStatusDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ biddingStatus: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(BiddingStatusDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(BiddingStatusDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load biddingStatus on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.biddingStatus).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
