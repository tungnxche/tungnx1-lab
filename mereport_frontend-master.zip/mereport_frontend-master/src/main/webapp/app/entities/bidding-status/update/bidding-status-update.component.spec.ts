import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { BiddingStatusFormService } from './bidding-status-form.service';
import { BiddingStatusService } from '../service/bidding-status.service';
import { IBiddingStatus } from '../bidding-status.model';

import { BiddingStatusUpdateComponent } from './bidding-status-update.component';

describe('BiddingStatus Management Update Component', () => {
  let comp: BiddingStatusUpdateComponent;
  let fixture: ComponentFixture<BiddingStatusUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let biddingStatusFormService: BiddingStatusFormService;
  let biddingStatusService: BiddingStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [BiddingStatusUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(BiddingStatusUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingStatusUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    biddingStatusFormService = TestBed.inject(BiddingStatusFormService);
    biddingStatusService = TestBed.inject(BiddingStatusService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should update editForm', () => {
      const biddingStatus: IBiddingStatus = { id: 456 };

      activatedRoute.data = of({ biddingStatus });
      comp.ngOnInit();

      expect(comp.biddingStatus).toEqual(biddingStatus);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingStatus>>();
      const biddingStatus = { id: 123 };
      jest.spyOn(biddingStatusFormService, 'getBiddingStatus').mockReturnValue(biddingStatus);
      jest.spyOn(biddingStatusService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingStatus });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingStatus }));
      saveSubject.complete();

      // THEN
      expect(biddingStatusFormService.getBiddingStatus).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(biddingStatusService.update).toHaveBeenCalledWith(expect.objectContaining(biddingStatus));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingStatus>>();
      const biddingStatus = { id: 123 };
      jest.spyOn(biddingStatusFormService, 'getBiddingStatus').mockReturnValue({ id: null });
      jest.spyOn(biddingStatusService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingStatus: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingStatus }));
      saveSubject.complete();

      // THEN
      expect(biddingStatusFormService.getBiddingStatus).toHaveBeenCalled();
      expect(biddingStatusService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingStatus>>();
      const biddingStatus = { id: 123 };
      jest.spyOn(biddingStatusService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingStatus });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(biddingStatusService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });
});
