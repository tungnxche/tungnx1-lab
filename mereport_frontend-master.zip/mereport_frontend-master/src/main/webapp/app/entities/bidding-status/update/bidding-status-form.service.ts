import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { IBiddingStatus, NewBiddingStatus } from '../bidding-status.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IBiddingStatus for edit and NewBiddingStatusFormGroupInput for create.
 */
type BiddingStatusFormGroupInput = IBiddingStatus | PartialWithRequiredKeyOf<NewBiddingStatus>;

type BiddingStatusFormDefaults = Pick<NewBiddingStatus, 'id'>;

type BiddingStatusFormGroupContent = {
  id: FormControl<IBiddingStatus['id'] | NewBiddingStatus['id']>;
  name: FormControl<IBiddingStatus['name']>;
};

export type BiddingStatusFormGroup = FormGroup<BiddingStatusFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class BiddingStatusFormService {
  createBiddingStatusFormGroup(biddingStatus: BiddingStatusFormGroupInput = { id: null }): BiddingStatusFormGroup {
    const biddingStatusRawValue = {
      ...this.getFormDefaults(),
      ...biddingStatus,
    };
    return new FormGroup<BiddingStatusFormGroupContent>({
      id: new FormControl(
        { value: biddingStatusRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(biddingStatusRawValue.name, {
        validators: [Validators.required],
      }),
    });
  }

  getBiddingStatus(form: BiddingStatusFormGroup): IBiddingStatus | NewBiddingStatus {
    return form.getRawValue() as IBiddingStatus | NewBiddingStatus;
  }

  resetForm(form: BiddingStatusFormGroup, biddingStatus: BiddingStatusFormGroupInput): void {
    const biddingStatusRawValue = { ...this.getFormDefaults(), ...biddingStatus };
    form.reset(
      {
        ...biddingStatusRawValue,
        id: { value: biddingStatusRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): BiddingStatusFormDefaults {
    return {
      id: null,
    };
  }
}
