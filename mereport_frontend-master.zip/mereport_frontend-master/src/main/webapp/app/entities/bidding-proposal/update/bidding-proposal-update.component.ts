import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { BiddingProposalFormService, BiddingProposalFormGroup } from './bidding-proposal-form.service';
import { IBiddingProposal } from '../bidding-proposal.model';
import { BiddingProposalService } from '../service/bidding-proposal.service';
import { IContractor } from 'app/entities/contractor/contractor.model';
import { ContractorService } from 'app/entities/contractor/service/contractor.service';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { BiddingPckService } from 'app/entities/bidding-pck/service/bidding-pck.service';
import { IProject } from 'app/entities/project/project.model';
import { ProjectService } from 'app/entities/project/service/project.service';
import { IProposalType } from 'app/entities/proposal-type/proposal-type.model';
import { ProposalTypeService } from 'app/entities/proposal-type/service/proposal-type.service';
import { IApprovalStatus } from 'app/entities/approval-status/approval-status.model';
import { ApprovalStatusService } from 'app/entities/approval-status/service/approval-status.service';
import { IBiddingStatus } from 'app/entities/bidding-status/bidding-status.model';
import { BiddingStatusService } from 'app/entities/bidding-status/service/bidding-status.service';

@Component({
  selector: 'jhi-bidding-proposal-update',
  templateUrl: './bidding-proposal-update.component.html',
})
export class BiddingProposalUpdateComponent implements OnInit {
  isSaving = false;
  biddingProposal: IBiddingProposal | null = null;

  contractorsSharedCollection: IContractor[] = [];
  biddingPcksSharedCollection: IBiddingPck[] = [];
  projectsSharedCollection: IProject[] = [];
  proposalTypesSharedCollection: IProposalType[] = [];
  approvalStatusesSharedCollection: IApprovalStatus[] = [];
  biddingStatusesSharedCollection: IBiddingStatus[] = [];

  editForm: BiddingProposalFormGroup = this.biddingProposalFormService.createBiddingProposalFormGroup();

  constructor(
    protected biddingProposalService: BiddingProposalService,
    protected biddingProposalFormService: BiddingProposalFormService,
    protected contractorService: ContractorService,
    protected biddingPckService: BiddingPckService,
    protected projectService: ProjectService,
    protected proposalTypeService: ProposalTypeService,
    protected approvalStatusService: ApprovalStatusService,
    protected biddingStatusService: BiddingStatusService,
    protected activatedRoute: ActivatedRoute
  ) {}

  compareContractor = (o1: IContractor | null, o2: IContractor | null): boolean => this.contractorService.compareContractor(o1, o2);

  compareBiddingPck = (o1: IBiddingPck | null, o2: IBiddingPck | null): boolean => this.biddingPckService.compareBiddingPck(o1, o2);

  compareProject = (o1: IProject | null, o2: IProject | null): boolean => this.projectService.compareProject(o1, o2);

  compareProposalType = (o1: IProposalType | null, o2: IProposalType | null): boolean =>
    this.proposalTypeService.compareProposalType(o1, o2);

  compareApprovalStatus = (o1: IApprovalStatus | null, o2: IApprovalStatus | null): boolean =>
    this.approvalStatusService.compareApprovalStatus(o1, o2);

  compareBiddingStatus = (o1: IBiddingStatus | null, o2: IBiddingStatus | null): boolean =>
    this.biddingStatusService.compareBiddingStatus(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingProposal }) => {
      this.biddingProposal = biddingProposal;
      if (biddingProposal) {
        this.updateForm(biddingProposal);
      }

      this.loadRelationshipsOptions();
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const biddingProposal = this.biddingProposalFormService.getBiddingProposal(this.editForm);
    if (biddingProposal.id !== null) {
      this.subscribeToSaveResponse(this.biddingProposalService.update(biddingProposal));
    } else {
      this.subscribeToSaveResponse(this.biddingProposalService.create(biddingProposal));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBiddingProposal>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(biddingProposal: IBiddingProposal): void {
    this.biddingProposal = biddingProposal;
    this.biddingProposalFormService.resetForm(this.editForm, biddingProposal);

    this.contractorsSharedCollection = this.contractorService.addContractorToCollectionIfMissing<IContractor>(
      this.contractorsSharedCollection,
      biddingProposal.contractor
    );
    this.biddingPcksSharedCollection = this.biddingPckService.addBiddingPckToCollectionIfMissing<IBiddingPck>(
      this.biddingPcksSharedCollection,
      biddingProposal.biddingPck
    );
    this.projectsSharedCollection = this.projectService.addProjectToCollectionIfMissing<IProject>(
      this.projectsSharedCollection,
      biddingProposal.project
    );
    this.proposalTypesSharedCollection = this.proposalTypeService.addProposalTypeToCollectionIfMissing<IProposalType>(
      this.proposalTypesSharedCollection,
      biddingProposal.type
    );
    this.approvalStatusesSharedCollection = this.approvalStatusService.addApprovalStatusToCollectionIfMissing<IApprovalStatus>(
      this.approvalStatusesSharedCollection,
      biddingProposal.approvalStatus
    );
    this.biddingStatusesSharedCollection = this.biddingStatusService.addBiddingStatusToCollectionIfMissing<IBiddingStatus>(
      this.biddingStatusesSharedCollection,
      biddingProposal.biddingStatus
    );
  }

  protected loadRelationshipsOptions(): void {
    this.contractorService
      .query()
      .pipe(map((res: HttpResponse<IContractor[]>) => res.body ?? []))
      .pipe(
        map((contractors: IContractor[]) =>
          this.contractorService.addContractorToCollectionIfMissing<IContractor>(contractors, this.biddingProposal?.contractor)
        )
      )
      .subscribe((contractors: IContractor[]) => (this.contractorsSharedCollection = contractors));

    this.biddingPckService
      .query()
      .pipe(map((res: HttpResponse<IBiddingPck[]>) => res.body ?? []))
      .pipe(
        map((biddingPcks: IBiddingPck[]) =>
          this.biddingPckService.addBiddingPckToCollectionIfMissing<IBiddingPck>(biddingPcks, this.biddingProposal?.biddingPck)
        )
      )
      .subscribe((biddingPcks: IBiddingPck[]) => (this.biddingPcksSharedCollection = biddingPcks));

    this.projectService
      .query()
      .pipe(map((res: HttpResponse<IProject[]>) => res.body ?? []))
      .pipe(
        map((projects: IProject[]) =>
          this.projectService.addProjectToCollectionIfMissing<IProject>(projects, this.biddingProposal?.project)
        )
      )
      .subscribe((projects: IProject[]) => (this.projectsSharedCollection = projects));

    this.proposalTypeService
      .query()
      .pipe(map((res: HttpResponse<IProposalType[]>) => res.body ?? []))
      .pipe(
        map((proposalTypes: IProposalType[]) =>
          this.proposalTypeService.addProposalTypeToCollectionIfMissing<IProposalType>(proposalTypes, this.biddingProposal?.type)
        )
      )
      .subscribe((proposalTypes: IProposalType[]) => (this.proposalTypesSharedCollection = proposalTypes));

    this.approvalStatusService
      .query()
      .pipe(map((res: HttpResponse<IApprovalStatus[]>) => res.body ?? []))
      .pipe(
        map((approvalStatuses: IApprovalStatus[]) =>
          this.approvalStatusService.addApprovalStatusToCollectionIfMissing<IApprovalStatus>(
            approvalStatuses,
            this.biddingProposal?.approvalStatus
          )
        )
      )
      .subscribe((approvalStatuses: IApprovalStatus[]) => (this.approvalStatusesSharedCollection = approvalStatuses));

    this.biddingStatusService
      .query()
      .pipe(map((res: HttpResponse<IBiddingStatus[]>) => res.body ?? []))
      .pipe(
        map((biddingStatuses: IBiddingStatus[]) =>
          this.biddingStatusService.addBiddingStatusToCollectionIfMissing<IBiddingStatus>(
            biddingStatuses,
            this.biddingProposal?.biddingStatus
          )
        )
      )
      .subscribe((biddingStatuses: IBiddingStatus[]) => (this.biddingStatusesSharedCollection = biddingStatuses));
  }
}
