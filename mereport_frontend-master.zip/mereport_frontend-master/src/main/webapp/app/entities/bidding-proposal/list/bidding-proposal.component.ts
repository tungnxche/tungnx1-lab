import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ActivatedRoute, Data, ParamMap, Router } from '@angular/router';
import {
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  merge,
  Observable,
  OperatorFunction,
  Subject,
  switchMap,
  tap,
} from 'rxjs';
import { NgbModal, NgbTypeahead, NgbTypeaheadSelectItemEvent } from '@ng-bootstrap/ng-bootstrap';

import { IBiddingProposal } from '../bidding-proposal.model';

import { ITEMS_PER_PAGE, ITEM_SEARCH, PAGE_HEADER, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { ASC, DESC, SORT, ITEM_DELETED_EVENT, DEFAULT_SORT_DATA, ALERT_TRANSLATION_KEY, ALERT_TYPE } from 'app/config/navigation.constants';
import { EntityArrayResponseType, BiddingProposalService } from '../service/bidding-proposal.service';
import { BiddingProposalDeleteDialogComponent } from '../delete/bidding-proposal-delete-dialog.component';
import { AlertService } from 'app/core/util/alert.service';
import { NgForm } from '@angular/forms';
import { IProject } from 'app/entities/project/project.model';
import { ProjectService } from 'app/entities/project/service/project.service';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { BiddingPckService } from 'app/entities/bidding-pck/service/bidding-pck.service';
import { ApprovalStatusService } from 'app/entities/approval-status/service/approval-status.service';
import { IApprovalStatus } from 'app/entities/approval-status/approval-status.model';

@Component({
  selector: 'jhi-bidding-proposal',
  templateUrl: './bidding-proposal.component.html',
})
export class BiddingProposalComponent implements OnInit {
  biddingProposals?: IBiddingProposal[];
  isLoading = false;

  predicate = 'id';
  ascending = true;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  projects: IProject[] = [];
  projectSelected: any = null;
  @ViewChild('instanceProject', { static: true }) instanceProject!: NgbTypeahead;
  focusProject$ = new Subject<IProject>();
  clickProject$ = new Subject<IProject>();

  biddingPcks: IBiddingPck[] = [];
  biddingPckSelected: any = null;
  @ViewChild('instanceBiddingPck', { static: true }) instanceBiddingPck!: NgbTypeahead;
  focusBiddingPck$ = new Subject<IBiddingPck>();
  clickBiddingPck$ = new Subject<IBiddingPck>();

  constructor(
    protected biddingProposalService: BiddingProposalService,
    protected activatedRoute: ActivatedRoute,
    public router: Router,
    protected modalService: NgbModal,
    protected alertService: AlertService,
    protected projectService: ProjectService,
    protected biddingPckService: BiddingPckService
  ) {}

  trackId = (_index: number, item: IBiddingProposal): number => this.biddingProposalService.getBiddingProposalIdentifier(item);

  ngOnInit(): void {
    this.load();
    this.loadProjects();
    this.loadBiddingPcks();
  }

  formatter = (x: { name: string }): string => (x.name ? x.name : '');

  searchAll(searchForm: NgForm): void {
    console.log('searchForm', searchForm);
  }

  searchProject: OperatorFunction<string, readonly IProject[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.clickProject$.pipe(filter(() => !this.instanceProject.isPopupOpen()));
    const inputFocus$ = this.focusProject$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === '' ? this.projects : this.projects.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))).slice(
          0,
          10
        )
      )
    );
  };

  selectedProject(data: NgbTypeaheadSelectItemEvent): void {
    this.projectSelected = data.item;
  }

  checkSelectedProject(ref: any): void {
    if (ref.value && this.projectSelected) {
      if (this.projectSelected.name !== ref.value) {
        ref.value = '';
      }
    }
  }

  searchBiddingPck: OperatorFunction<string, readonly IBiddingPck[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.clickBiddingPck$.pipe(filter(() => !this.instanceBiddingPck.isPopupOpen()));
    const inputFocus$ = this.focusBiddingPck$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === ''
          ? this.biddingPcks
          : this.biddingPcks.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))
        ).slice(0, 10)
      )
    );
  };

  selectedBiddingPck(data: NgbTypeaheadSelectItemEvent): void {
    this.biddingPckSelected = data.item;
  }

  checkSelectedBiddingPck(ref: any): void {
    if (ref.value && this.biddingPckSelected) {
      if (this.biddingPckSelected.name !== ref.value) {
        ref.value = '';
      }
    }
  }

  delete(biddingProposal: IBiddingProposal): void {
    const modalRef = this.modalService.open(BiddingProposalDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.biddingProposal = biddingProposal;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed
      .pipe(
        filter(reason => reason === ITEM_DELETED_EVENT),
        switchMap(() => this.loadFromBackendWithRouteInformations())
      )
      .subscribe({
        next: (res: EntityArrayResponseType) => {
          this.onResponseSuccess(res);
        },
      });
  }

  load(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  navigateToWithComponentValues(): void {
    this.handleNavigation(this.page, this.predicate, this.ascending);
  }

  navigateToPage(page = this.page): void {
    this.handleNavigation(page, this.predicate, this.ascending);
  }

  protected loadProjects(): void {
    this.projectService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<IProject[]>) => res.body ?? []))
      .subscribe((projects: IProject[]) => (this.projects = projects));
  }

  protected loadBiddingPcks(): void {
    this.biddingPckService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<IBiddingPck[]>) => res.body ?? []))
      .subscribe((biddingPcks: IBiddingPck[]) => (this.biddingPcks = biddingPcks));
  }

  protected triggerAlertDeleted(alert: any): void {
    this.alertService.addAlert(alert);
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return combineLatest([this.activatedRoute.queryParamMap, this.activatedRoute.data]).pipe(
      tap(([params, data]) => this.fillComponentAttributeFromRoute(params, data)),
      switchMap(() => this.queryBackend(this.page, this.predicate, this.ascending))
    );
  }

  protected checkExistAlert(params: ParamMap): void {
    if (params.get(ALERT_TYPE) && params.get(ALERT_TRANSLATION_KEY)) {
      this.triggerAlertDeleted({
        type: params.get(ALERT_TYPE),
        translationKey: params.get(ALERT_TRANSLATION_KEY),
      });
    }
  }

  protected fillComponentAttributeFromRoute(params: ParamMap, data: Data): void {
    const page = params.get(PAGE_HEADER);
    this.page = +(page ?? 1);
    const sort = (params.get(SORT) ?? data[DEFAULT_SORT_DATA]).split(',');
    this.predicate = sort[0];
    this.ascending = sort[1] === ASC;
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingProposals = dataFromBody;
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingProposal[] | null): IBiddingProposal[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }

  protected queryBackend(page?: number, predicate?: string, ascending?: boolean): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingProposalService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected handleNavigation(page = this.page, predicate?: string, ascending?: boolean): void {
    const queryParamsObj = {
      page,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };

    this.router.navigate(['./'], {
      relativeTo: this.activatedRoute,
      queryParams: queryParamsObj,
    });
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }
}
