import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { BiddingProposalComponent } from './list/bidding-proposal.component';
import { BiddingProposalDetailComponent } from './detail/bidding-proposal-detail.component';
import { BiddingProposalUpdateComponent } from './update/bidding-proposal-update.component';
import { BiddingProposalDeleteDialogComponent } from './delete/bidding-proposal-delete-dialog.component';
import { BiddingProposalRoutingModule } from './route/bidding-proposal-routing.module';

@NgModule({
  imports: [SharedModule, BiddingProposalRoutingModule],
  declarations: [
    BiddingProposalComponent,
    BiddingProposalDetailComponent,
    BiddingProposalUpdateComponent,
    BiddingProposalDeleteDialogComponent,
  ],
})
export class BiddingProposalModule {}
