import dayjs from 'dayjs/esm';
import { IContractor } from 'app/entities/contractor/contractor.model';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { IProject } from 'app/entities/project/project.model';
import { IProposalType } from 'app/entities/proposal-type/proposal-type.model';
import { IApprovalStatus } from 'app/entities/approval-status/approval-status.model';
import { IBiddingStatus } from 'app/entities/bidding-status/bidding-status.model';

export interface IBiddingProposal {
  id: number;
  name?: string;
  applicant?: string | null;
  applicantDate?: dayjs.Dayjs | null;
  tnconsValue?: number | null;
  totalValue?: number | null;
  avgValue?: number | null;
  notes?: string | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
  contractor?: IContractor | null;
  biddingPck?: IBiddingPck | null;
  project?: IProject | null;
  type?: IProposalType | null;
  approvalStatus?: IApprovalStatus | null;
  biddingStatus?: IBiddingStatus | null;
}

export type NewBiddingProposal = Omit<IBiddingProposal, 'id'> & { id: null };
