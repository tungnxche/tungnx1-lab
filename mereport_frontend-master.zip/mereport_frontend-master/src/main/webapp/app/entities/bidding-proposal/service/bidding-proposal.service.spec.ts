import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { IBiddingProposal } from '../bidding-proposal.model';
import { sampleWithRequiredData, sampleWithNewData, sampleWithPartialData, sampleWithFullData } from '../bidding-proposal.test-samples';

import { BiddingProposalService, RestBiddingProposal } from './bidding-proposal.service';

const requireRestSample: RestBiddingProposal = {
  ...sampleWithRequiredData,
  applicantDate: sampleWithRequiredData.applicantDate?.toJSON(),
  createdOn: sampleWithRequiredData.createdOn?.toJSON(),
  modifiedOn: sampleWithRequiredData.modifiedOn?.toJSON(),
  deletedOn: sampleWithRequiredData.deletedOn?.toJSON(),
};

describe('BiddingProposal Service', () => {
  let service: BiddingProposalService;
  let httpMock: HttpTestingController;
  let expectedResult: IBiddingProposal | IBiddingProposal[] | boolean | null;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    expectedResult = null;
    service = TestBed.inject(BiddingProposalService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  describe('Service methods', () => {
    it('should find an element', () => {
      const returnedFromService = { ...requireRestSample };
      const expected = { ...sampleWithRequiredData };

      service.find(123).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'GET' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should create a BiddingProposal', () => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const biddingProposal = { ...sampleWithNewData };
      const returnedFromService = { ...requireRestSample };
      const expected = { ...sampleWithRequiredData };

      service.create(biddingProposal).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'POST' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should update a BiddingProposal', () => {
      const biddingProposal = { ...sampleWithRequiredData };
      const returnedFromService = { ...requireRestSample };
      const expected = { ...sampleWithRequiredData };

      service.update(biddingProposal).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'PUT' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should partial update a BiddingProposal', () => {
      const patchObject = { ...sampleWithPartialData };
      const returnedFromService = { ...requireRestSample };
      const expected = { ...sampleWithRequiredData };

      service.partialUpdate(patchObject).subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'PATCH' });
      req.flush(returnedFromService);
      expect(expectedResult).toMatchObject(expected);
    });

    it('should return a list of BiddingProposal', () => {
      const returnedFromService = { ...requireRestSample };

      const expected = { ...sampleWithRequiredData };

      service.query().subscribe(resp => (expectedResult = resp.body));

      const req = httpMock.expectOne({ method: 'GET' });
      req.flush([returnedFromService]);
      httpMock.verify();
      expect(expectedResult).toMatchObject([expected]);
    });

    it('should delete a BiddingProposal', () => {
      const expected = true;

      service.delete(123).subscribe(resp => (expectedResult = resp.ok));

      const req = httpMock.expectOne({ method: 'DELETE' });
      req.flush({ status: 200 });
      expect(expectedResult).toBe(expected);
    });

    describe('addBiddingProposalToCollectionIfMissing', () => {
      it('should add a BiddingProposal to an empty array', () => {
        const biddingProposal: IBiddingProposal = sampleWithRequiredData;
        expectedResult = service.addBiddingProposalToCollectionIfMissing([], biddingProposal);
        expect(expectedResult).toHaveLength(1);
        expect(expectedResult).toContain(biddingProposal);
      });

      it('should not add a BiddingProposal to an array that contains it', () => {
        const biddingProposal: IBiddingProposal = sampleWithRequiredData;
        const biddingProposalCollection: IBiddingProposal[] = [
          {
            ...biddingProposal,
          },
          sampleWithPartialData,
        ];
        expectedResult = service.addBiddingProposalToCollectionIfMissing(biddingProposalCollection, biddingProposal);
        expect(expectedResult).toHaveLength(2);
      });

      it("should add a BiddingProposal to an array that doesn't contain it", () => {
        const biddingProposal: IBiddingProposal = sampleWithRequiredData;
        const biddingProposalCollection: IBiddingProposal[] = [sampleWithPartialData];
        expectedResult = service.addBiddingProposalToCollectionIfMissing(biddingProposalCollection, biddingProposal);
        expect(expectedResult).toHaveLength(2);
        expect(expectedResult).toContain(biddingProposal);
      });

      it('should add only unique BiddingProposal to an array', () => {
        const biddingProposalArray: IBiddingProposal[] = [sampleWithRequiredData, sampleWithPartialData, sampleWithFullData];
        const biddingProposalCollection: IBiddingProposal[] = [sampleWithRequiredData];
        expectedResult = service.addBiddingProposalToCollectionIfMissing(biddingProposalCollection, ...biddingProposalArray);
        expect(expectedResult).toHaveLength(3);
      });

      it('should accept varargs', () => {
        const biddingProposal: IBiddingProposal = sampleWithRequiredData;
        const biddingProposal2: IBiddingProposal = sampleWithPartialData;
        expectedResult = service.addBiddingProposalToCollectionIfMissing([], biddingProposal, biddingProposal2);
        expect(expectedResult).toHaveLength(2);
        expect(expectedResult).toContain(biddingProposal);
        expect(expectedResult).toContain(biddingProposal2);
      });

      it('should accept null and undefined values', () => {
        const biddingProposal: IBiddingProposal = sampleWithRequiredData;
        expectedResult = service.addBiddingProposalToCollectionIfMissing([], null, biddingProposal, undefined);
        expect(expectedResult).toHaveLength(1);
        expect(expectedResult).toContain(biddingProposal);
      });

      it('should return initial array if no BiddingProposal is added', () => {
        const biddingProposalCollection: IBiddingProposal[] = [sampleWithRequiredData];
        expectedResult = service.addBiddingProposalToCollectionIfMissing(biddingProposalCollection, undefined, null);
        expect(expectedResult).toEqual(biddingProposalCollection);
      });
    });

    describe('compareBiddingProposal', () => {
      it('Should return true if both entities are null', () => {
        const entity1 = null;
        const entity2 = null;

        const compareResult = service.compareBiddingProposal(entity1, entity2);

        expect(compareResult).toEqual(true);
      });

      it('Should return false if one entity is null', () => {
        const entity1 = { id: 123 };
        const entity2 = null;

        const compareResult1 = service.compareBiddingProposal(entity1, entity2);
        const compareResult2 = service.compareBiddingProposal(entity2, entity1);

        expect(compareResult1).toEqual(false);
        expect(compareResult2).toEqual(false);
      });

      it('Should return false if primaryKey differs', () => {
        const entity1 = { id: 123 };
        const entity2 = { id: 456 };

        const compareResult1 = service.compareBiddingProposal(entity1, entity2);
        const compareResult2 = service.compareBiddingProposal(entity2, entity1);

        expect(compareResult1).toEqual(false);
        expect(compareResult2).toEqual(false);
      });

      it('Should return false if primaryKey matches', () => {
        const entity1 = { id: 123 };
        const entity2 = { id: 123 };

        const compareResult1 = service.compareBiddingProposal(entity1, entity2);
        const compareResult2 = service.compareBiddingProposal(entity2, entity1);

        expect(compareResult1).toEqual(true);
        expect(compareResult2).toEqual(true);
      });
    });
  });

  afterEach(() => {
    httpMock.verify();
  });
});
