import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IBiddingProposal, NewBiddingProposal } from '../bidding-proposal.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IBiddingProposal for edit and NewBiddingProposalFormGroupInput for create.
 */
type BiddingProposalFormGroupInput = IBiddingProposal | PartialWithRequiredKeyOf<NewBiddingProposal>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IBiddingProposal | NewBiddingProposal> = Omit<T, 'applicantDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  applicantDate?: string | null;
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type BiddingProposalFormRawValue = FormValueOf<IBiddingProposal>;

type NewBiddingProposalFormRawValue = FormValueOf<NewBiddingProposal>;

type BiddingProposalFormDefaults = Pick<NewBiddingProposal, 'id' | 'applicantDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type BiddingProposalFormGroupContent = {
  id: FormControl<BiddingProposalFormRawValue['id'] | NewBiddingProposal['id']>;
  applicant: FormControl<BiddingProposalFormRawValue['applicant']>;
  applicantDate: FormControl<BiddingProposalFormRawValue['applicantDate']>;
  tnconsValue: FormControl<BiddingProposalFormRawValue['tnconsValue']>;
  totalValue: FormControl<BiddingProposalFormRawValue['totalValue']>;
  avgValue: FormControl<BiddingProposalFormRawValue['avgValue']>;
  notes: FormControl<BiddingProposalFormRawValue['notes']>;
  createdBy: FormControl<BiddingProposalFormRawValue['createdBy']>;
  createdOn: FormControl<BiddingProposalFormRawValue['createdOn']>;
  modifiedBy: FormControl<BiddingProposalFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<BiddingProposalFormRawValue['modifiedOn']>;
  deletedBy: FormControl<BiddingProposalFormRawValue['deletedBy']>;
  deletedOn: FormControl<BiddingProposalFormRawValue['deletedOn']>;
  contractor: FormControl<BiddingProposalFormRawValue['contractor']>;
  biddingPck: FormControl<BiddingProposalFormRawValue['biddingPck']>;
  project: FormControl<BiddingProposalFormRawValue['project']>;
  type: FormControl<BiddingProposalFormRawValue['type']>;
  approvalStatus: FormControl<BiddingProposalFormRawValue['approvalStatus']>;
  biddingStatus: FormControl<BiddingProposalFormRawValue['biddingStatus']>;
};

export type BiddingProposalFormGroup = FormGroup<BiddingProposalFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class BiddingProposalFormService {
  createBiddingProposalFormGroup(biddingProposal: BiddingProposalFormGroupInput = { id: null }): BiddingProposalFormGroup {
    const biddingProposalRawValue = this.convertBiddingProposalToBiddingProposalRawValue({
      ...this.getFormDefaults(),
      ...biddingProposal,
    });
    return new FormGroup<BiddingProposalFormGroupContent>({
      id: new FormControl(
        { value: biddingProposalRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      applicant: new FormControl(biddingProposalRawValue.applicant),
      applicantDate: new FormControl(biddingProposalRawValue.applicantDate),
      tnconsValue: new FormControl(biddingProposalRawValue.tnconsValue),
      totalValue: new FormControl(biddingProposalRawValue.totalValue),
      avgValue: new FormControl(biddingProposalRawValue.avgValue),
      notes: new FormControl(biddingProposalRawValue.notes),
      createdBy: new FormControl(biddingProposalRawValue.createdBy),
      createdOn: new FormControl(biddingProposalRawValue.createdOn),
      modifiedBy: new FormControl(biddingProposalRawValue.modifiedBy),
      modifiedOn: new FormControl(biddingProposalRawValue.modifiedOn),
      deletedBy: new FormControl(biddingProposalRawValue.deletedBy),
      deletedOn: new FormControl(biddingProposalRawValue.deletedOn),
      contractor: new FormControl(biddingProposalRawValue.contractor),
      biddingPck: new FormControl(biddingProposalRawValue.biddingPck),
      project: new FormControl(biddingProposalRawValue.project),
      type: new FormControl(biddingProposalRawValue.type),
      approvalStatus: new FormControl(biddingProposalRawValue.approvalStatus),
      biddingStatus: new FormControl(biddingProposalRawValue.biddingStatus),
    });
  }

  getBiddingProposal(form: BiddingProposalFormGroup): IBiddingProposal | NewBiddingProposal {
    return this.convertBiddingProposalRawValueToBiddingProposal(
      form.getRawValue() as BiddingProposalFormRawValue | NewBiddingProposalFormRawValue
    );
  }

  resetForm(form: BiddingProposalFormGroup, biddingProposal: BiddingProposalFormGroupInput): void {
    const biddingProposalRawValue = this.convertBiddingProposalToBiddingProposalRawValue({ ...this.getFormDefaults(), ...biddingProposal });
    form.reset(
      {
        ...biddingProposalRawValue,
        id: { value: biddingProposalRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): BiddingProposalFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      applicantDate: currentTime,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertBiddingProposalRawValueToBiddingProposal(
    rawBiddingProposal: BiddingProposalFormRawValue | NewBiddingProposalFormRawValue
  ): IBiddingProposal | NewBiddingProposal {
    return {
      ...rawBiddingProposal,
      applicantDate: dayjs(rawBiddingProposal.applicantDate, DATE_TIME_FORMAT),
      createdOn: dayjs(rawBiddingProposal.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawBiddingProposal.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawBiddingProposal.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertBiddingProposalToBiddingProposalRawValue(
    biddingProposal: IBiddingProposal | (Partial<NewBiddingProposal> & BiddingProposalFormDefaults)
  ): BiddingProposalFormRawValue | PartialWithRequiredKeyOf<NewBiddingProposalFormRawValue> {
    return {
      ...biddingProposal,
      applicantDate: biddingProposal.applicantDate ? biddingProposal.applicantDate.format(DATE_TIME_FORMAT) : undefined,
      createdOn: biddingProposal.createdOn ? biddingProposal.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: biddingProposal.modifiedOn ? biddingProposal.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: biddingProposal.deletedOn ? biddingProposal.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
