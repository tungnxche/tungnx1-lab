import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IBiddingProposal } from '../bidding-proposal.model';
import { BiddingProposalService } from '../service/bidding-proposal.service';

@Injectable({ providedIn: 'root' })
export class BiddingProposalRoutingResolveService implements Resolve<IBiddingProposal | null> {
  constructor(protected service: BiddingProposalService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IBiddingProposal | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((biddingProposal: HttpResponse<IBiddingProposal>) => {
          if (biddingProposal.body) {
            return of(biddingProposal.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
