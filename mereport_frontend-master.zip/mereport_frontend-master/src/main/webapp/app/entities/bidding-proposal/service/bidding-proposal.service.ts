import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import dayjs from 'dayjs/esm';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IBiddingProposal, NewBiddingProposal } from '../bidding-proposal.model';

export type PartialUpdateBiddingProposal = Partial<IBiddingProposal> & Pick<IBiddingProposal, 'id'>;

type RestOf<T extends IBiddingProposal | NewBiddingProposal> = Omit<T, 'applicantDate' | 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  applicantDate?: string | null;
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

export type RestBiddingProposal = RestOf<IBiddingProposal>;

export type NewRestBiddingProposal = RestOf<NewBiddingProposal>;

export type PartialUpdateRestBiddingProposal = RestOf<PartialUpdateBiddingProposal>;

export type EntityResponseType = HttpResponse<IBiddingProposal>;
export type EntityArrayResponseType = HttpResponse<IBiddingProposal[]>;

@Injectable({ providedIn: 'root' })
export class BiddingProposalService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/bidding-proposals');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(biddingProposal: NewBiddingProposal): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingProposal);
    return this.http
      .post<RestBiddingProposal>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(biddingProposal: IBiddingProposal): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingProposal);
    return this.http
      .put<RestBiddingProposal>(`${this.resourceUrl}/${this.getBiddingProposalIdentifier(biddingProposal)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(biddingProposal: PartialUpdateBiddingProposal): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingProposal);
    return this.http
      .patch<RestBiddingProposal>(`${this.resourceUrl}/${this.getBiddingProposalIdentifier(biddingProposal)}`, copy, {
        observe: 'response',
      })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestBiddingProposal>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestBiddingProposal[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getBiddingProposalIdentifier(biddingProposal: Pick<IBiddingProposal, 'id'>): number {
    return biddingProposal.id;
  }

  compareBiddingProposal(o1: Pick<IBiddingProposal, 'id'> | null, o2: Pick<IBiddingProposal, 'id'> | null): boolean {
    return o1 && o2 ? this.getBiddingProposalIdentifier(o1) === this.getBiddingProposalIdentifier(o2) : o1 === o2;
  }

  addBiddingProposalToCollectionIfMissing<Type extends Pick<IBiddingProposal, 'id'>>(
    biddingProposalCollection: Type[],
    ...biddingProposalsToCheck: (Type | null | undefined)[]
  ): Type[] {
    const biddingProposals: Type[] = biddingProposalsToCheck.filter(isPresent);
    if (biddingProposals.length > 0) {
      const biddingProposalCollectionIdentifiers = biddingProposalCollection.map(
        biddingProposalItem => this.getBiddingProposalIdentifier(biddingProposalItem)!
      );
      const biddingProposalsToAdd = biddingProposals.filter(biddingProposalItem => {
        const biddingProposalIdentifier = this.getBiddingProposalIdentifier(biddingProposalItem);
        if (biddingProposalCollectionIdentifiers.includes(biddingProposalIdentifier)) {
          return false;
        }
        biddingProposalCollectionIdentifiers.push(biddingProposalIdentifier);
        return true;
      });
      return [...biddingProposalsToAdd, ...biddingProposalCollection];
    }
    return biddingProposalCollection;
  }

  protected convertDateFromClient<T extends IBiddingProposal | NewBiddingProposal | PartialUpdateBiddingProposal>(
    biddingProposal: T
  ): RestOf<T> {
    return {
      ...biddingProposal,
      applicantDate: biddingProposal.applicantDate?.toJSON() ?? null,
      createdOn: biddingProposal.createdOn?.toJSON() ?? null,
      modifiedOn: biddingProposal.modifiedOn?.toJSON() ?? null,
      deletedOn: biddingProposal.deletedOn?.toJSON() ?? null,
    };
  }

  protected convertDateFromServer(restBiddingProposal: RestBiddingProposal): IBiddingProposal {
    return {
      ...restBiddingProposal,
      applicantDate: restBiddingProposal.applicantDate ? dayjs(restBiddingProposal.applicantDate) : undefined,
      createdOn: restBiddingProposal.createdOn ? dayjs(restBiddingProposal.createdOn) : undefined,
      modifiedOn: restBiddingProposal.modifiedOn ? dayjs(restBiddingProposal.modifiedOn) : undefined,
      deletedOn: restBiddingProposal.deletedOn ? dayjs(restBiddingProposal.deletedOn) : undefined,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestBiddingProposal>): HttpResponse<IBiddingProposal> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestBiddingProposal[]>): HttpResponse<IBiddingProposal[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }
}
