import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { BiddingProposalFormService } from './bidding-proposal-form.service';
import { BiddingProposalService } from '../service/bidding-proposal.service';
import { IBiddingProposal } from '../bidding-proposal.model';
import { IContractor } from 'app/entities/contractor/contractor.model';
import { ContractorService } from 'app/entities/contractor/service/contractor.service';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { BiddingPckService } from 'app/entities/bidding-pck/service/bidding-pck.service';
import { IProject } from 'app/entities/project/project.model';
import { ProjectService } from 'app/entities/project/service/project.service';
import { IProposalType } from 'app/entities/proposal-type/proposal-type.model';
import { ProposalTypeService } from 'app/entities/proposal-type/service/proposal-type.service';
import { IApprovalStatus } from 'app/entities/approval-status/approval-status.model';
import { ApprovalStatusService } from 'app/entities/approval-status/service/approval-status.service';
import { IBiddingStatus } from 'app/entities/bidding-status/bidding-status.model';
import { BiddingStatusService } from 'app/entities/bidding-status/service/bidding-status.service';

import { BiddingProposalUpdateComponent } from './bidding-proposal-update.component';

describe('BiddingProposal Management Update Component', () => {
  let comp: BiddingProposalUpdateComponent;
  let fixture: ComponentFixture<BiddingProposalUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let biddingProposalFormService: BiddingProposalFormService;
  let biddingProposalService: BiddingProposalService;
  let contractorService: ContractorService;
  let biddingPckService: BiddingPckService;
  let projectService: ProjectService;
  let proposalTypeService: ProposalTypeService;
  let approvalStatusService: ApprovalStatusService;
  let biddingStatusService: BiddingStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [BiddingProposalUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(BiddingProposalUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingProposalUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    biddingProposalFormService = TestBed.inject(BiddingProposalFormService);
    biddingProposalService = TestBed.inject(BiddingProposalService);
    contractorService = TestBed.inject(ContractorService);
    biddingPckService = TestBed.inject(BiddingPckService);
    projectService = TestBed.inject(ProjectService);
    proposalTypeService = TestBed.inject(ProposalTypeService);
    approvalStatusService = TestBed.inject(ApprovalStatusService);
    biddingStatusService = TestBed.inject(BiddingStatusService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should call Contractor query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const contractor: IContractor = { id: 4344 };
      biddingProposal.contractor = contractor;

      const contractorCollection: IContractor[] = [{ id: 81895 }];
      jest.spyOn(contractorService, 'query').mockReturnValue(of(new HttpResponse({ body: contractorCollection })));
      const additionalContractors = [contractor];
      const expectedCollection: IContractor[] = [...additionalContractors, ...contractorCollection];
      jest.spyOn(contractorService, 'addContractorToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(contractorService.query).toHaveBeenCalled();
      expect(contractorService.addContractorToCollectionIfMissing).toHaveBeenCalledWith(
        contractorCollection,
        ...additionalContractors.map(expect.objectContaining)
      );
      expect(comp.contractorsSharedCollection).toEqual(expectedCollection);
    });

    it('Should call BiddingPck query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const biddingPck: IBiddingPck = { id: 1960 };
      biddingProposal.biddingPck = biddingPck;

      const biddingPckCollection: IBiddingPck[] = [{ id: 51337 }];
      jest.spyOn(biddingPckService, 'query').mockReturnValue(of(new HttpResponse({ body: biddingPckCollection })));
      const additionalBiddingPcks = [biddingPck];
      const expectedCollection: IBiddingPck[] = [...additionalBiddingPcks, ...biddingPckCollection];
      jest.spyOn(biddingPckService, 'addBiddingPckToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(biddingPckService.query).toHaveBeenCalled();
      expect(biddingPckService.addBiddingPckToCollectionIfMissing).toHaveBeenCalledWith(
        biddingPckCollection,
        ...additionalBiddingPcks.map(expect.objectContaining)
      );
      expect(comp.biddingPcksSharedCollection).toEqual(expectedCollection);
    });

    it('Should call Project query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const project: IProject = { id: 87168 };
      biddingProposal.project = project;

      const projectCollection: IProject[] = [{ id: 85433 }];
      jest.spyOn(projectService, 'query').mockReturnValue(of(new HttpResponse({ body: projectCollection })));
      const additionalProjects = [project];
      const expectedCollection: IProject[] = [...additionalProjects, ...projectCollection];
      jest.spyOn(projectService, 'addProjectToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(projectService.query).toHaveBeenCalled();
      expect(projectService.addProjectToCollectionIfMissing).toHaveBeenCalledWith(
        projectCollection,
        ...additionalProjects.map(expect.objectContaining)
      );
      expect(comp.projectsSharedCollection).toEqual(expectedCollection);
    });

    it('Should call ProposalType query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const type: IProposalType = { id: 21309 };
      biddingProposal.type = type;

      const proposalTypeCollection: IProposalType[] = [{ id: 20557 }];
      jest.spyOn(proposalTypeService, 'query').mockReturnValue(of(new HttpResponse({ body: proposalTypeCollection })));
      const additionalProposalTypes = [type];
      const expectedCollection: IProposalType[] = [...additionalProposalTypes, ...proposalTypeCollection];
      jest.spyOn(proposalTypeService, 'addProposalTypeToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(proposalTypeService.query).toHaveBeenCalled();
      expect(proposalTypeService.addProposalTypeToCollectionIfMissing).toHaveBeenCalledWith(
        proposalTypeCollection,
        ...additionalProposalTypes.map(expect.objectContaining)
      );
      expect(comp.proposalTypesSharedCollection).toEqual(expectedCollection);
    });

    it('Should call ApprovalStatus query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const approvalStatus: IApprovalStatus = { id: 56781 };
      biddingProposal.approvalStatus = approvalStatus;

      const approvalStatusCollection: IApprovalStatus[] = [{ id: 86496 }];
      jest.spyOn(approvalStatusService, 'query').mockReturnValue(of(new HttpResponse({ body: approvalStatusCollection })));
      const additionalApprovalStatuses = [approvalStatus];
      const expectedCollection: IApprovalStatus[] = [...additionalApprovalStatuses, ...approvalStatusCollection];
      jest.spyOn(approvalStatusService, 'addApprovalStatusToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(approvalStatusService.query).toHaveBeenCalled();
      expect(approvalStatusService.addApprovalStatusToCollectionIfMissing).toHaveBeenCalledWith(
        approvalStatusCollection,
        ...additionalApprovalStatuses.map(expect.objectContaining)
      );
      expect(comp.approvalStatusesSharedCollection).toEqual(expectedCollection);
    });

    it('Should call BiddingStatus query and add missing value', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const biddingStatus: IBiddingStatus = { id: 68613 };
      biddingProposal.biddingStatus = biddingStatus;

      const biddingStatusCollection: IBiddingStatus[] = [{ id: 60364 }];
      jest.spyOn(biddingStatusService, 'query').mockReturnValue(of(new HttpResponse({ body: biddingStatusCollection })));
      const additionalBiddingStatuses = [biddingStatus];
      const expectedCollection: IBiddingStatus[] = [...additionalBiddingStatuses, ...biddingStatusCollection];
      jest.spyOn(biddingStatusService, 'addBiddingStatusToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(biddingStatusService.query).toHaveBeenCalled();
      expect(biddingStatusService.addBiddingStatusToCollectionIfMissing).toHaveBeenCalledWith(
        biddingStatusCollection,
        ...additionalBiddingStatuses.map(expect.objectContaining)
      );
      expect(comp.biddingStatusesSharedCollection).toEqual(expectedCollection);
    });

    it('Should update editForm', () => {
      const biddingProposal: IBiddingProposal = { id: 456 };
      const contractor: IContractor = { id: 82200 };
      biddingProposal.contractor = contractor;
      const biddingPck: IBiddingPck = { id: 56626 };
      biddingProposal.biddingPck = biddingPck;
      const project: IProject = { id: 44611 };
      biddingProposal.project = project;
      const type: IProposalType = { id: 95119 };
      biddingProposal.type = type;
      const approvalStatus: IApprovalStatus = { id: 86518 };
      biddingProposal.approvalStatus = approvalStatus;
      const biddingStatus: IBiddingStatus = { id: 54416 };
      biddingProposal.biddingStatus = biddingStatus;

      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      expect(comp.contractorsSharedCollection).toContain(contractor);
      expect(comp.biddingPcksSharedCollection).toContain(biddingPck);
      expect(comp.projectsSharedCollection).toContain(project);
      expect(comp.proposalTypesSharedCollection).toContain(type);
      expect(comp.approvalStatusesSharedCollection).toContain(approvalStatus);
      expect(comp.biddingStatusesSharedCollection).toContain(biddingStatus);
      expect(comp.biddingProposal).toEqual(biddingProposal);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingProposal>>();
      const biddingProposal = { id: 123 };
      jest.spyOn(biddingProposalFormService, 'getBiddingProposal').mockReturnValue(biddingProposal);
      jest.spyOn(biddingProposalService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingProposal }));
      saveSubject.complete();

      // THEN
      expect(biddingProposalFormService.getBiddingProposal).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(biddingProposalService.update).toHaveBeenCalledWith(expect.objectContaining(biddingProposal));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingProposal>>();
      const biddingProposal = { id: 123 };
      jest.spyOn(biddingProposalFormService, 'getBiddingProposal').mockReturnValue({ id: null });
      jest.spyOn(biddingProposalService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingProposal: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingProposal }));
      saveSubject.complete();

      // THEN
      expect(biddingProposalFormService.getBiddingProposal).toHaveBeenCalled();
      expect(biddingProposalService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingProposal>>();
      const biddingProposal = { id: 123 };
      jest.spyOn(biddingProposalService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingProposal });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(biddingProposalService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });

  describe('Compare relationships', () => {
    describe('compareContractor', () => {
      it('Should forward to contractorService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(contractorService, 'compareContractor');
        comp.compareContractor(entity, entity2);
        expect(contractorService.compareContractor).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareBiddingPck', () => {
      it('Should forward to biddingPckService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(biddingPckService, 'compareBiddingPck');
        comp.compareBiddingPck(entity, entity2);
        expect(biddingPckService.compareBiddingPck).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareProject', () => {
      it('Should forward to projectService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(projectService, 'compareProject');
        comp.compareProject(entity, entity2);
        expect(projectService.compareProject).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareProposalType', () => {
      it('Should forward to proposalTypeService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(proposalTypeService, 'compareProposalType');
        comp.compareProposalType(entity, entity2);
        expect(proposalTypeService.compareProposalType).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareApprovalStatus', () => {
      it('Should forward to approvalStatusService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(approvalStatusService, 'compareApprovalStatus');
        comp.compareApprovalStatus(entity, entity2);
        expect(approvalStatusService.compareApprovalStatus).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareBiddingStatus', () => {
      it('Should forward to biddingStatusService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(biddingStatusService, 'compareBiddingStatus');
        comp.compareBiddingStatus(entity, entity2);
        expect(biddingStatusService.compareBiddingStatus).toHaveBeenCalledWith(entity, entity2);
      });
    });
  });
});
