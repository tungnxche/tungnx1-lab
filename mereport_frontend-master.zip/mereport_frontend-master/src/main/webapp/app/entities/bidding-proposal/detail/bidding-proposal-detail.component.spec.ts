import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { BiddingProposalDetailComponent } from './bidding-proposal-detail.component';

describe('BiddingProposal Management Detail Component', () => {
  let comp: BiddingProposalDetailComponent;
  let fixture: ComponentFixture<BiddingProposalDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BiddingProposalDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ biddingProposal: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(BiddingProposalDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(BiddingProposalDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load biddingProposal on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.biddingProposal).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
