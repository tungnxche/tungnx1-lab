import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ASC, DESC, ITEM_DELETED_EVENT } from 'app/config/navigation.constants';
import { ITEMS_PER_PAGE, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { Alert, AlertService } from 'app/core/util/alert.service';
import { IBiddingDoc } from 'app/entities/bidding-doc/bidding-doc.model';
import { BiddingDocService, EntityArrayResponseType } from 'app/entities/bidding-doc/service/bidding-doc.service';
import { filter, Observable, switchMap, tap } from 'rxjs';

import { IBiddingProposal } from '../bidding-proposal.model';
import { BiddingProposalDeleteDialogComponent } from '../delete/bidding-proposal-delete-dialog.component';
import dayjs from 'dayjs/esm';

@Component({
  selector: 'jhi-bidding-proposal-detail',
  templateUrl: './bidding-proposal-detail.component.html',
})
export class BiddingProposalDetailComponent implements OnInit {
  biddingProposal!: IBiddingProposal;
  biddingDocs?: IBiddingDoc[] = [];
  isLoading = false;

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected biddingDocService: BiddingDocService,
    protected modalService: NgbModal,
    protected alertService: AlertService,
    protected router: Router
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingProposal }) => {
      this.biddingProposal = biddingProposal;
      if (biddingProposal) {
        this.loadBiddingDocs();
      }
    });
  }

  trackId = (_index: number, item: IBiddingDoc): number => this.biddingDocService.getBiddingDocIdentifier(item);

  previousState(): void {
    window.history.back();
  }

  formatDate(date: any): string {
    return dayjs(date).format('DD/MM/YYYY');
  }

  navigateToPage(page = this.page): void {
    this.page = page;
    this.loadBiddingDocs();
  }

  loadBiddingDocs(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  delete(): void {
    const modalRef = this.modalService.open(BiddingProposalDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.biddingProposal = this.biddingProposal;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed.subscribe(() => {
      const alerts = this.alertService.get();
      this.backToList(alerts);
    });
  }

  backToList(alerts: Alert[]): void {
    if (alerts.length) {
      const alert = { ...alerts[alerts.length - 1] };
      const queryParamsObj = {
        type: alert.type,
        translationKey: alert.translationKey,
      };
      this.router.navigate(['/bidding-proposal'], {
        queryParams: queryParamsObj,
      });
    } else {
      this.router.navigate(['/bidding-proposal']);
    }
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return this.queryBackend(this.biddingProposal.id, this.page, this.predicate, this.ascending);
  }

  protected queryBackend(
    contractorid: number,
    page?: number,
    predicate?: string,
    ascending?: boolean
  ): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      contractorid,
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingDocService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingDocs = [...dataFromBody];
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingDoc[] | null): IBiddingDoc[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }
}
