import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { BiddingProposalComponent } from '../list/bidding-proposal.component';
import { BiddingProposalDetailComponent } from '../detail/bidding-proposal-detail.component';
import { BiddingProposalUpdateComponent } from '../update/bidding-proposal-update.component';
import { BiddingProposalRoutingResolveService } from './bidding-proposal-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const biddingProposalRoute: Routes = [
  {
    path: '',
    component: BiddingProposalComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: BiddingProposalDetailComponent,
    resolve: {
      biddingProposal: BiddingProposalRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BiddingProposalUpdateComponent,
    resolve: {
      biddingProposal: BiddingProposalRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: BiddingProposalUpdateComponent,
    resolve: {
      biddingProposal: BiddingProposalRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(biddingProposalRoute)],
  exports: [RouterModule],
})
export class BiddingProposalRoutingModule {}
