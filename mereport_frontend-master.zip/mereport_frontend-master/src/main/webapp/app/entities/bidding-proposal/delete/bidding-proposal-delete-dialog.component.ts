import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IBiddingProposal } from '../bidding-proposal.model';
import { BiddingProposalService } from '../service/bidding-proposal.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './bidding-proposal-delete-dialog.component.html',
})
export class BiddingProposalDeleteDialogComponent {
  biddingProposal?: IBiddingProposal;

  constructor(protected biddingProposalService: BiddingProposalService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.biddingProposalService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
