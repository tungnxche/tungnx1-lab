import dayjs from 'dayjs/esm';

import { IBiddingProposal, NewBiddingProposal } from './bidding-proposal.model';

export const sampleWithRequiredData: IBiddingProposal = {
  id: 12342,
};

export const sampleWithPartialData: IBiddingProposal = {
  id: 64345,
  applicantDate: dayjs('2022-09-28T08:32'),
  tnconsValue: 97597,
  totalValue: 866,
  modifiedBy: 50473,
  deletedBy: 76427,
  deletedOn: dayjs('2022-09-28T20:03'),
};

export const sampleWithFullData: IBiddingProposal = {
  id: 4862,
  applicant: 'demand-driven deposit',
  applicantDate: dayjs('2022-09-28T14:35'),
  tnconsValue: 61514,
  totalValue: 34917,
  avgValue: 33818,
  notes: 'user-facing efficient gold',
  createdBy: 37608,
  createdOn: dayjs('2022-09-28T15:12'),
  modifiedBy: 38395,
  modifiedOn: dayjs('2022-09-29T04:28'),
  deletedBy: 93737,
  deletedOn: dayjs('2022-09-29T02:06'),
};

export const sampleWithNewData: NewBiddingProposal = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
