import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../bidding-proposal.test-samples';

import { BiddingProposalFormService } from './bidding-proposal-form.service';

describe('BiddingProposal Form Service', () => {
  let service: BiddingProposalFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiddingProposalFormService);
  });

  describe('Service methods', () => {
    describe('createBiddingProposalFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createBiddingProposalFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            applicant: expect.any(Object),
            applicantDate: expect.any(Object),
            tnconsValue: expect.any(Object),
            totalValue: expect.any(Object),
            avgValue: expect.any(Object),
            notes: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            contractor: expect.any(Object),
            biddingPck: expect.any(Object),
            project: expect.any(Object),
            type: expect.any(Object),
            approvalStatus: expect.any(Object),
            biddingStatus: expect.any(Object),
          })
        );
      });

      it('passing IBiddingProposal should create a new form with FormGroup', () => {
        const formGroup = service.createBiddingProposalFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            applicant: expect.any(Object),
            applicantDate: expect.any(Object),
            tnconsValue: expect.any(Object),
            totalValue: expect.any(Object),
            avgValue: expect.any(Object),
            notes: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            contractor: expect.any(Object),
            biddingPck: expect.any(Object),
            project: expect.any(Object),
            type: expect.any(Object),
            approvalStatus: expect.any(Object),
            biddingStatus: expect.any(Object),
          })
        );
      });
    });

    describe('getBiddingProposal', () => {
      it('should return NewBiddingProposal for default BiddingProposal initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createBiddingProposalFormGroup(sampleWithNewData);

        const biddingProposal = service.getBiddingProposal(formGroup) as any;

        expect(biddingProposal).toMatchObject(sampleWithNewData);
      });

      it('should return NewBiddingProposal for empty BiddingProposal initial value', () => {
        const formGroup = service.createBiddingProposalFormGroup();

        const biddingProposal = service.getBiddingProposal(formGroup) as any;

        expect(biddingProposal).toMatchObject({});
      });

      it('should return IBiddingProposal', () => {
        const formGroup = service.createBiddingProposalFormGroup(sampleWithRequiredData);

        const biddingProposal = service.getBiddingProposal(formGroup) as any;

        expect(biddingProposal).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IBiddingProposal should not enable id FormControl', () => {
        const formGroup = service.createBiddingProposalFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewBiddingProposal should disable id FormControl', () => {
        const formGroup = service.createBiddingProposalFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
