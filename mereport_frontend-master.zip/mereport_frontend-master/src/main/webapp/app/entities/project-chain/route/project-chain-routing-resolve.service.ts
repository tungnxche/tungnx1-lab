import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IProjectChain } from '../project-chain.model';
import { ProjectChainService } from '../service/project-chain.service';

@Injectable({ providedIn: 'root' })
export class ProjectChainRoutingResolveService implements Resolve<IProjectChain | null> {
  constructor(protected service: ProjectChainService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IProjectChain | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((projectChain: HttpResponse<IProjectChain>) => {
          if (projectChain.body) {
            return of(projectChain.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
