import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { ProjectChainFormService, ProjectChainFormGroup } from './project-chain-form.service';
import { IProjectChain } from '../project-chain.model';
import { ProjectChainService } from '../service/project-chain.service';

@Component({
  selector: 'jhi-project-chain-update',
  templateUrl: './project-chain-update.component.html',
})
export class ProjectChainUpdateComponent implements OnInit {
  isSaving = false;
  projectChain: IProjectChain | null = null;

  editForm: ProjectChainFormGroup = this.projectChainFormService.createProjectChainFormGroup();

  constructor(
    protected projectChainService: ProjectChainService,
    protected projectChainFormService: ProjectChainFormService,
    protected activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ projectChain }) => {
      this.projectChain = projectChain;
      if (projectChain) {
        this.updateForm(projectChain);
      }
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const projectChain = this.projectChainFormService.getProjectChain(this.editForm);
    if (projectChain.id !== null) {
      this.subscribeToSaveResponse(this.projectChainService.update(projectChain));
    } else {
      this.subscribeToSaveResponse(this.projectChainService.create(projectChain));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProjectChain>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(projectChain: IProjectChain): void {
    this.projectChain = projectChain;
    this.projectChainFormService.resetForm(this.editForm, projectChain);
  }
}
