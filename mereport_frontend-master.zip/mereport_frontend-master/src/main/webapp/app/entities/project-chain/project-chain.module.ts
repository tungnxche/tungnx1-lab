import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { ProjectChainComponent } from './list/project-chain.component';
import { ProjectChainDetailComponent } from './detail/project-chain-detail.component';
import { ProjectChainUpdateComponent } from './update/project-chain-update.component';
import { ProjectChainDeleteDialogComponent } from './delete/project-chain-delete-dialog.component';
import { ProjectChainRoutingModule } from './route/project-chain-routing.module';

@NgModule({
  imports: [SharedModule, ProjectChainRoutingModule],
  declarations: [ProjectChainComponent, ProjectChainDetailComponent, ProjectChainUpdateComponent, ProjectChainDeleteDialogComponent],
})
export class ProjectChainModule {}
