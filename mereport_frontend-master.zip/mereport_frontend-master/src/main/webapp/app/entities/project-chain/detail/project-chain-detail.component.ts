import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IProjectChain } from '../project-chain.model';

@Component({
  selector: 'jhi-project-chain-detail',
  templateUrl: './project-chain-detail.component.html',
})
export class ProjectChainDetailComponent implements OnInit {
  projectChain: IProjectChain | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ projectChain }) => {
      this.projectChain = projectChain;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
