import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import dayjs from 'dayjs/esm';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IProjectChain, NewProjectChain } from '../project-chain.model';

export type PartialUpdateProjectChain = Partial<IProjectChain> & Pick<IProjectChain, 'id'>;

type RestOf<T extends IProjectChain | NewProjectChain> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

export type RestProjectChain = RestOf<IProjectChain>;

export type NewRestProjectChain = RestOf<NewProjectChain>;

export type PartialUpdateRestProjectChain = RestOf<PartialUpdateProjectChain>;

export type EntityResponseType = HttpResponse<IProjectChain>;
export type EntityArrayResponseType = HttpResponse<IProjectChain[]>;

@Injectable({ providedIn: 'root' })
export class ProjectChainService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/project-chains');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(projectChain: NewProjectChain): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(projectChain);
    return this.http
      .post<RestProjectChain>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(projectChain: IProjectChain): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(projectChain);
    return this.http
      .put<RestProjectChain>(`${this.resourceUrl}/${this.getProjectChainIdentifier(projectChain)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(projectChain: PartialUpdateProjectChain): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(projectChain);
    return this.http
      .patch<RestProjectChain>(`${this.resourceUrl}/${this.getProjectChainIdentifier(projectChain)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestProjectChain>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestProjectChain[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getProjectChainIdentifier(projectChain: Pick<IProjectChain, 'id'>): number {
    return projectChain.id;
  }

  compareProjectChain(o1: Pick<IProjectChain, 'id'> | null, o2: Pick<IProjectChain, 'id'> | null): boolean {
    return o1 && o2 ? this.getProjectChainIdentifier(o1) === this.getProjectChainIdentifier(o2) : o1 === o2;
  }

  addProjectChainToCollectionIfMissing<Type extends Pick<IProjectChain, 'id'>>(
    projectChainCollection: Type[],
    ...projectChainsToCheck: (Type | null | undefined)[]
  ): Type[] {
    const projectChains: Type[] = projectChainsToCheck.filter(isPresent);
    if (projectChains.length > 0) {
      const projectChainCollectionIdentifiers = projectChainCollection.map(
        projectChainItem => this.getProjectChainIdentifier(projectChainItem)!
      );
      const projectChainsToAdd = projectChains.filter(projectChainItem => {
        const projectChainIdentifier = this.getProjectChainIdentifier(projectChainItem);
        if (projectChainCollectionIdentifiers.includes(projectChainIdentifier)) {
          return false;
        }
        projectChainCollectionIdentifiers.push(projectChainIdentifier);
        return true;
      });
      return [...projectChainsToAdd, ...projectChainCollection];
    }
    return projectChainCollection;
  }

  protected convertDateFromClient<T extends IProjectChain | NewProjectChain | PartialUpdateProjectChain>(projectChain: T): RestOf<T> {
    return {
      ...projectChain,
      createdOn: projectChain.createdOn?.toJSON() ?? null,
      modifiedOn: projectChain.modifiedOn?.toJSON() ?? null,
      deletedOn: projectChain.deletedOn?.toJSON() ?? null,
    };
  }

  protected convertDateFromServer(restProjectChain: RestProjectChain): IProjectChain {
    return {
      ...restProjectChain,
      createdOn: restProjectChain.createdOn ? dayjs(restProjectChain.createdOn) : undefined,
      modifiedOn: restProjectChain.modifiedOn ? dayjs(restProjectChain.modifiedOn) : undefined,
      deletedOn: restProjectChain.deletedOn ? dayjs(restProjectChain.deletedOn) : undefined,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestProjectChain>): HttpResponse<IProjectChain> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestProjectChain[]>): HttpResponse<IProjectChain[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }
}
