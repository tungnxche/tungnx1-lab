import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { ProjectChainDetailComponent } from './project-chain-detail.component';

describe('ProjectChain Management Detail Component', () => {
  let comp: ProjectChainDetailComponent;
  let fixture: ComponentFixture<ProjectChainDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProjectChainDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ projectChain: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(ProjectChainDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(ProjectChainDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load projectChain on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.projectChain).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
