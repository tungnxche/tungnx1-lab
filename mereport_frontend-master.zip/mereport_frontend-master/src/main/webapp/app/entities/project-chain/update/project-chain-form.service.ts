import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IProjectChain, NewProjectChain } from '../project-chain.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IProjectChain for edit and NewProjectChainFormGroupInput for create.
 */
type ProjectChainFormGroupInput = IProjectChain | PartialWithRequiredKeyOf<NewProjectChain>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IProjectChain | NewProjectChain> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type ProjectChainFormRawValue = FormValueOf<IProjectChain>;

type NewProjectChainFormRawValue = FormValueOf<NewProjectChain>;

type ProjectChainFormDefaults = Pick<NewProjectChain, 'id' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type ProjectChainFormGroupContent = {
  id: FormControl<ProjectChainFormRawValue['id'] | NewProjectChain['id']>;
  name: FormControl<ProjectChainFormRawValue['name']>;
  createdBy: FormControl<ProjectChainFormRawValue['createdBy']>;
  createdOn: FormControl<ProjectChainFormRawValue['createdOn']>;
  modifiedBy: FormControl<ProjectChainFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<ProjectChainFormRawValue['modifiedOn']>;
  deletedBy: FormControl<ProjectChainFormRawValue['deletedBy']>;
  deletedOn: FormControl<ProjectChainFormRawValue['deletedOn']>;
};

export type ProjectChainFormGroup = FormGroup<ProjectChainFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class ProjectChainFormService {
  createProjectChainFormGroup(projectChain: ProjectChainFormGroupInput = { id: null }): ProjectChainFormGroup {
    const projectChainRawValue = this.convertProjectChainToProjectChainRawValue({
      ...this.getFormDefaults(),
      ...projectChain,
    });
    return new FormGroup<ProjectChainFormGroupContent>({
      id: new FormControl(
        { value: projectChainRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(projectChainRawValue.name, {
        validators: [Validators.required],
      }),
      createdBy: new FormControl(projectChainRawValue.createdBy),
      createdOn: new FormControl(projectChainRawValue.createdOn),
      modifiedBy: new FormControl(projectChainRawValue.modifiedBy),
      modifiedOn: new FormControl(projectChainRawValue.modifiedOn),
      deletedBy: new FormControl(projectChainRawValue.deletedBy),
      deletedOn: new FormControl(projectChainRawValue.deletedOn),
    });
  }

  getProjectChain(form: ProjectChainFormGroup): IProjectChain | NewProjectChain {
    return this.convertProjectChainRawValueToProjectChain(form.getRawValue() as ProjectChainFormRawValue | NewProjectChainFormRawValue);
  }

  resetForm(form: ProjectChainFormGroup, projectChain: ProjectChainFormGroupInput): void {
    const projectChainRawValue = this.convertProjectChainToProjectChainRawValue({ ...this.getFormDefaults(), ...projectChain });
    form.reset(
      {
        ...projectChainRawValue,
        id: { value: projectChainRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): ProjectChainFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertProjectChainRawValueToProjectChain(
    rawProjectChain: ProjectChainFormRawValue | NewProjectChainFormRawValue
  ): IProjectChain | NewProjectChain {
    return {
      ...rawProjectChain,
      createdOn: dayjs(rawProjectChain.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawProjectChain.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawProjectChain.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertProjectChainToProjectChainRawValue(
    projectChain: IProjectChain | (Partial<NewProjectChain> & ProjectChainFormDefaults)
  ): ProjectChainFormRawValue | PartialWithRequiredKeyOf<NewProjectChainFormRawValue> {
    return {
      ...projectChain,
      createdOn: projectChain.createdOn ? projectChain.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: projectChain.modifiedOn ? projectChain.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: projectChain.deletedOn ? projectChain.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
