import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IProjectChain } from '../project-chain.model';
import { ProjectChainService } from '../service/project-chain.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './project-chain-delete-dialog.component.html',
})
export class ProjectChainDeleteDialogComponent {
  projectChain?: IProjectChain;

  constructor(protected projectChainService: ProjectChainService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.projectChainService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
