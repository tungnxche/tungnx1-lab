import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ProjectChainComponent } from '../list/project-chain.component';
import { ProjectChainDetailComponent } from '../detail/project-chain-detail.component';
import { ProjectChainUpdateComponent } from '../update/project-chain-update.component';
import { ProjectChainRoutingResolveService } from './project-chain-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const projectChainRoute: Routes = [
  {
    path: '',
    component: ProjectChainComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: ProjectChainDetailComponent,
    resolve: {
      projectChain: ProjectChainRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: ProjectChainUpdateComponent,
    resolve: {
      projectChain: ProjectChainRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: ProjectChainUpdateComponent,
    resolve: {
      projectChain: ProjectChainRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(projectChainRoute)],
  exports: [RouterModule],
})
export class ProjectChainRoutingModule {}
