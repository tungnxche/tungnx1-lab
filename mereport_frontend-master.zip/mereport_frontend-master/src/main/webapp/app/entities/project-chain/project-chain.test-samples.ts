import dayjs from 'dayjs/esm';

import { IProjectChain, NewProjectChain } from './project-chain.model';

export const sampleWithRequiredData: IProjectChain = {
  id: 57365,
  name: 'Cuba',
};

export const sampleWithPartialData: IProjectChain = {
  id: 5418,
  name: 'Account methodologies Wooden',
  createdBy: 2132,
};

export const sampleWithFullData: IProjectChain = {
  id: 33986,
  name: 'Awesome niches',
  createdBy: 66426,
  createdOn: dayjs('2022-09-28T20:27'),
  modifiedBy: 52472,
  modifiedOn: dayjs('2022-09-28T14:17'),
  deletedBy: 27516,
  deletedOn: dayjs('2022-09-28T18:43'),
};

export const sampleWithNewData: NewProjectChain = {
  name: 'Solutions Savings',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
