import dayjs from 'dayjs/esm';

export interface IProjectChain {
  id: number;
  name?: string | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
}

export type NewProjectChain = Omit<IProjectChain, 'id'> & { id: null };
