import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../project-chain.test-samples';

import { ProjectChainFormService } from './project-chain-form.service';

describe('ProjectChain Form Service', () => {
  let service: ProjectChainFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProjectChainFormService);
  });

  describe('Service methods', () => {
    describe('createProjectChainFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createProjectChainFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
          })
        );
      });

      it('passing IProjectChain should create a new form with FormGroup', () => {
        const formGroup = service.createProjectChainFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
          })
        );
      });
    });

    describe('getProjectChain', () => {
      it('should return NewProjectChain for default ProjectChain initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createProjectChainFormGroup(sampleWithNewData);

        const projectChain = service.getProjectChain(formGroup) as any;

        expect(projectChain).toMatchObject(sampleWithNewData);
      });

      it('should return NewProjectChain for empty ProjectChain initial value', () => {
        const formGroup = service.createProjectChainFormGroup();

        const projectChain = service.getProjectChain(formGroup) as any;

        expect(projectChain).toMatchObject({});
      });

      it('should return IProjectChain', () => {
        const formGroup = service.createProjectChainFormGroup(sampleWithRequiredData);

        const projectChain = service.getProjectChain(formGroup) as any;

        expect(projectChain).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IProjectChain should not enable id FormControl', () => {
        const formGroup = service.createProjectChainFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewProjectChain should disable id FormControl', () => {
        const formGroup = service.createProjectChainFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
