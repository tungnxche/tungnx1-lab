import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'location',
        data: { pageTitle: 'meReportApp.location.home.title' },
        loadChildren: () => import('./location/location.module').then(m => m.LocationModule),
      },
      {
        path: 'project-chain',
        data: { pageTitle: 'meReportApp.projectChain.home.title' },
        loadChildren: () => import('./project-chain/project-chain.module').then(m => m.ProjectChainModule),
      },
      {
        path: 'project',
        data: { pageTitle: 'meReportApp.project.home.title' },
        loadChildren: () => import('./project/project.module').then(m => m.ProjectModule),
      },
      {
        path: 'bidding-pck-type',
        data: { pageTitle: 'meReportApp.biddingPckType.home.title' },
        loadChildren: () => import('./bidding-pck-type/bidding-pck-type.module').then(m => m.BiddingPckTypeModule),
      },
      {
        path: 'bidding-pck',
        data: { pageTitle: 'meReportApp.biddingPck.home.title' },
        loadChildren: () => import('./bidding-pck/bidding-pck.module').then(m => m.BiddingPckModule),
      },
      {
        path: 'contractor',
        data: { pageTitle: 'meReportApp.contractor.home.title' },
        loadChildren: () => import('./contractor/contractor.module').then(m => m.ContractorModule),
      },
      {
        path: 'bidding-proposal',
        data: { pageTitle: 'meReportApp.biddingProposal.home.title' },
        loadChildren: () => import('./bidding-proposal/bidding-proposal.module').then(m => m.BiddingProposalModule),
      },
      {
        path: 'bidding-doc',
        data: { pageTitle: 'meReportApp.biddingDoc.home.title' },
        loadChildren: () => import('./bidding-doc/bidding-doc.module').then(m => m.BiddingDocModule),
      },
      {
        path: 'proposal-type',
        data: { pageTitle: 'meReportApp.proposalType.home.title' },
        loadChildren: () => import('./proposal-type/proposal-type.module').then(m => m.ProposalTypeModule),
      },
      {
        path: 'approval-status',
        data: { pageTitle: 'meReportApp.approvalStatus.home.title' },
        loadChildren: () => import('./approval-status/approval-status.module').then(m => m.ApprovalStatusModule),
      },
      {
        path: 'bidding-status',
        data: { pageTitle: 'meReportApp.biddingStatus.home.title' },
        loadChildren: () => import('./bidding-status/bidding-status.module').then(m => m.BiddingStatusModule),
      },
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ]),
  ],
})
export class EntityRoutingModule {}
