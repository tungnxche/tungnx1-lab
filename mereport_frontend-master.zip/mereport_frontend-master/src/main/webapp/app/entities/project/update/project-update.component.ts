import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { merge, Observable, OperatorFunction, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, finalize, map, tap } from 'rxjs/operators';

import { ProjectFormService, ProjectFormGroup } from './project-form.service';
import { IProject } from '../project.model';
import { EntityArrayResponseType, ProjectService } from '../service/project.service';
import { IProjectChain } from 'app/entities/project-chain/project-chain.model';
import { ProjectChainService } from 'app/entities/project-chain/service/project-chain.service';
import { ILocation } from 'app/entities/location/location.model';
import { LocationService } from 'app/entities/location/service/location.service';
import { ITEMS_PER_PAGE, ITEM_SEARCH, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { BiddingPckService } from 'app/entities/bidding-pck/service/bidding-pck.service';
import dayjs from 'dayjs/esm';
import { ASC, DESC } from 'app/config/navigation.constants';
import { NgbTypeahead, NgbTypeaheadSelectItemEvent } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'jhi-project-update',
  templateUrl: './project-update.component.html',
})
export class ProjectUpdateComponent implements OnInit {
  isSaving = false;
  project!: IProject;
  isLoading = false;
  sum = 0;
  biddingPcks?: IBiddingPck[];

  projectChainSelected: any = null;
  projectLocationSelected: any = null;

  projectChainsSharedCollection: IProjectChain[] = [];
  locationsSharedCollection: ILocation[] = [];

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  editForm: ProjectFormGroup = this.projectFormService.createProjectFormGroup();

  @ViewChild('instanceChain', { static: true }) instanceChain!: NgbTypeahead;
  @ViewChild('instanceLocation', { static: true }) instanceLocation!: NgbTypeahead;

  focusChain$ = new Subject<IProjectChain>();
  clickChain$ = new Subject<IProjectChain>();

  focusLocation$ = new Subject<ILocation>();
  clickLocation$ = new Subject<ILocation>();

  constructor(
    protected projectService: ProjectService,
    protected projectFormService: ProjectFormService,
    protected projectChainService: ProjectChainService,
    protected locationService: LocationService,
    protected activatedRoute: ActivatedRoute,
    protected biddingPckService: BiddingPckService
  ) {}

  trackId = (_index: number, item: IBiddingPck): number => this.biddingPckService.getBiddingPckIdentifier(item);

  compareProjectChain = (o1: IProjectChain | null, o2: IProjectChain | null): boolean =>
    this.projectChainService.compareProjectChain(o1, o2);

  compareLocation = (o1: ILocation | null, o2: ILocation | null): boolean => this.locationService.compareLocation(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ project }) => {
      this.project = project;
      if (project) {
        this.updateForm(project);
        this.loadBiddingPcks();
        this.loadSumBiddingPcks();
      }

      this.loadRelationshipsOptions();
    });
  }

  searchChain: OperatorFunction<string, readonly IProjectChain[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.clickChain$.pipe(filter(() => !this.instanceChain.isPopupOpen()));
    const inputFocus$ = this.focusChain$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === ''
          ? this.projectChainsSharedCollection
          : this.projectChainsSharedCollection.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))
        ).slice(0, 10)
      )
    );
  };

  selectedProjectChain(data: NgbTypeaheadSelectItemEvent): void {
    this.projectChainSelected = data.item;
  }

  formatterChain = (x: IProjectChain): string => (x.name ? x.name : '');

  checkProjectChain(refChain: any): void {
    if (refChain.value && this.projectChainSelected) {
      if (this.projectChainSelected.name !== refChain.value) {
        refChain.value = '';
      }
    }
  }

  searchLocation: OperatorFunction<string, readonly ILocation[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.clickLocation$.pipe(filter(() => !this.instanceLocation.isPopupOpen()));
    const inputFocus$ = this.focusLocation$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === ''
          ? this.locationsSharedCollection
          : this.locationsSharedCollection.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))
        ).slice(0, 10)
      )
    );
  };

  selectedProjectLocation(data: NgbTypeaheadSelectItemEvent): void {
    this.projectLocationSelected = data.item;
  }

  formatterLocation = (x: ILocation): string => (x.name ? x.name : '');

  checkProjectLocation(refLocation: any): void {
    if (refLocation.value && this.projectLocationSelected) {
      if (this.projectLocationSelected.name !== refLocation.value) {
        refLocation.value = '';
      }
    }
  }

  navigateToPage(page = this.page): void {
    this.page = page;
    this.loadBiddingPcks();
  }

  loadBiddingPcks(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  loadSumBiddingPcks(): void {
    this.loadSumFromBackendWithRouteInformations().subscribe({
      next: res => {
        this.sum = res.body ? res.body : 0;
      },
    });
  }

  previousState(): void {
    window.history.back();
  }

  formatDate(date: any): string {
    return dayjs(date).format('DD/MM/YYYY');
  }

  save(): void {
    this.isSaving = true;
    const project = this.projectFormService.getProject(this.editForm);
    if (project.id !== null) {
      this.subscribeToSaveResponse(this.projectService.update(project));
    } else {
      this.subscribeToSaveResponse(this.projectService.create(project));
    }
  }

  protected mapNameWinProposal(id: any, biddingPck: IBiddingPck): string {
    if (id && biddingPck.biddingProposals && biddingPck.biddingProposals.length) {
      const proposal = biddingPck.biddingProposals.find(item => item.id === id);
      return proposal ? proposal.name ?? '' : '';
    }

    return '';
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return this.queryBackend(this.project.id, this.page, this.predicate, this.ascending);
  }

  protected loadSumFromBackendWithRouteInformations(): Observable<HttpResponse<number>> {
    return this.queryBackendSum(this.project.id);
  }

  protected queryBackendSum(projectid: number): Observable<HttpResponse<number>> {
    this.isLoading = true;
    const queryObject = {
      projectid,
    };
    return this.biddingPckService.querySum(queryObject);
  }

  protected queryBackend(projectid: number, page?: number, predicate?: string, ascending?: boolean): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      projectid,
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingPckService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProject>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(project: IProject): void {
    this.project = project;
    this.projectFormService.resetForm(this.editForm, project);

    this.projectChainsSharedCollection = this.projectChainService.addProjectChainToCollectionIfMissing<IProjectChain>(
      this.projectChainsSharedCollection,
      project.projectChain
    );
    this.locationsSharedCollection = this.locationService.addLocationToCollectionIfMissing<ILocation>(
      this.locationsSharedCollection,
      project.location
    );
  }

  protected loadRelationshipsOptions(): void {
    this.projectChainService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<IProjectChain[]>) => res.body ?? []))
      .subscribe((projectChains: IProjectChain[]) => (this.projectChainsSharedCollection = projectChains));

    this.locationService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<ILocation[]>) => res.body ?? []))
      .subscribe((locations: ILocation[]) => (this.locationsSharedCollection = locations));
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingPcks = [...dataFromBody];
    this.biddingPcks.forEach(bidding => {
      bidding.winProposalName = this.mapNameWinProposal(bidding.winProposal, bidding);
    });
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingPck[] | null): IBiddingPck[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }
}
