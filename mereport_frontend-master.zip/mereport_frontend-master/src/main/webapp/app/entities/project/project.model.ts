import dayjs from 'dayjs/esm';
import { IProjectChain } from 'app/entities/project-chain/project-chain.model';
import { ILocation } from 'app/entities/location/location.model';

export interface IProject {
  id: number;
  name?: string | null;
  budget?: number | null;
  projectScale?: number | null;
  investor?: string | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
  projectChain?: Pick<IProjectChain, 'id' | 'name'> | null;
  location?: Pick<ILocation, 'id' | 'name'> | null;
}

export type NewProject = Omit<IProject, 'id'> & { id: null };
