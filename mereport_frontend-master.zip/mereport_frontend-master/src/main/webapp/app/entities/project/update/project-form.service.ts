import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IProject, NewProject } from '../project.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IProject for edit and NewProjectFormGroupInput for create.
 */
type ProjectFormGroupInput = IProject | PartialWithRequiredKeyOf<NewProject>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IProject | NewProject> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type ProjectFormRawValue = FormValueOf<IProject>;

type NewProjectFormRawValue = FormValueOf<NewProject>;

type ProjectFormDefaults = Pick<NewProject, 'id' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type ProjectFormGroupContent = {
  id: FormControl<ProjectFormRawValue['id'] | NewProject['id']>;
  name: FormControl<ProjectFormRawValue['name']>;
  budget: FormControl<ProjectFormRawValue['budget']>;
  projectScale: FormControl<ProjectFormRawValue['projectScale']>;
  investor: FormControl<ProjectFormRawValue['investor']>;
  createdBy: FormControl<ProjectFormRawValue['createdBy']>;
  createdOn: FormControl<ProjectFormRawValue['createdOn']>;
  modifiedBy: FormControl<ProjectFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<ProjectFormRawValue['modifiedOn']>;
  deletedBy: FormControl<ProjectFormRawValue['deletedBy']>;
  deletedOn: FormControl<ProjectFormRawValue['deletedOn']>;
  projectChain: FormControl<ProjectFormRawValue['projectChain']>;
  location: FormControl<ProjectFormRawValue['location']>;
};

export type ProjectFormGroup = FormGroup<ProjectFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class ProjectFormService {
  createProjectFormGroup(project: ProjectFormGroupInput = { id: null }): ProjectFormGroup {
    const projectRawValue = this.convertProjectToProjectRawValue({
      ...this.getFormDefaults(),
      ...project,
    });
    return new FormGroup<ProjectFormGroupContent>({
      id: new FormControl(
        { value: projectRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(projectRawValue.name, {
        validators: [Validators.required],
      }),
      budget: new FormControl(projectRawValue.budget),
      projectScale: new FormControl(projectRawValue.projectScale),
      investor: new FormControl(projectRawValue.investor),
      createdBy: new FormControl(projectRawValue.createdBy),
      createdOn: new FormControl(projectRawValue.createdOn),
      modifiedBy: new FormControl(projectRawValue.modifiedBy),
      modifiedOn: new FormControl(projectRawValue.modifiedOn),
      deletedBy: new FormControl(projectRawValue.deletedBy),
      deletedOn: new FormControl(projectRawValue.deletedOn),
      projectChain: new FormControl(projectRawValue.projectChain),
      location: new FormControl(projectRawValue.location),
    });
  }

  getProject(form: ProjectFormGroup): IProject | NewProject {
    return this.convertProjectRawValueToProject(form.getRawValue() as ProjectFormRawValue | NewProjectFormRawValue);
  }

  resetForm(form: ProjectFormGroup, project: ProjectFormGroupInput): void {
    const projectRawValue = this.convertProjectToProjectRawValue({ ...this.getFormDefaults(), ...project });
    form.reset(
      {
        ...projectRawValue,
        id: { value: projectRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): ProjectFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertProjectRawValueToProject(rawProject: ProjectFormRawValue | NewProjectFormRawValue): IProject | NewProject {
    return {
      ...rawProject,
      createdOn: dayjs(rawProject.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawProject.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawProject.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertProjectToProjectRawValue(
    project: IProject | (Partial<NewProject> & ProjectFormDefaults)
  ): ProjectFormRawValue | PartialWithRequiredKeyOf<NewProjectFormRawValue> {
    return {
      ...project,
      createdOn: project.createdOn ? project.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: project.modifiedOn ? project.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: project.deletedOn ? project.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
