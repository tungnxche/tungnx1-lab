import dayjs from 'dayjs/esm';

import { IProject, NewProject } from './project.model';

export const sampleWithRequiredData: IProject = {
  id: 55962,
  name: 'COM dedicated Agent',
};

export const sampleWithPartialData: IProject = {
  id: 61186,
  name: 'Implemented dot-com Avon',
  budget: 6247,
  investor: 'Response Investor Loan',
  createdBy: 49757,
  modifiedBy: 8966,
  modifiedOn: dayjs('2022-09-28T06:59'),
  deletedBy: 89675,
  deletedOn: dayjs('2022-09-28T23:29'),
};

export const sampleWithFullData: IProject = {
  id: 82108,
  name: 'users invoice',
  budget: 81146,
  projectScale: 40533,
  investor: 'microchip Bike',
  createdBy: 52835,
  createdOn: dayjs('2022-09-28T08:53'),
  modifiedBy: 42804,
  modifiedOn: dayjs('2022-09-28T10:23'),
  deletedBy: 2133,
  deletedOn: dayjs('2022-09-28T23:58'),
};

export const sampleWithNewData: NewProject = {
  name: 'deposit',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
