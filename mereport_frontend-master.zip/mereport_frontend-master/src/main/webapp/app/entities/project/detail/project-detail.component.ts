import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ASC, DESC } from 'app/config/navigation.constants';
import { ITEMS_PER_PAGE, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { Alert, AlertService } from 'app/core/util/alert.service';
import { IBiddingPck } from 'app/entities/bidding-pck/bidding-pck.model';
import { BiddingPckService, EntityArrayResponseType } from 'app/entities/bidding-pck/service/bidding-pck.service';
import { Observable, tap } from 'rxjs';
import { ProjectDeleteDialogComponent } from '../delete/project-delete-dialog.component';
import dayjs from 'dayjs/esm';
import { IProject } from '../project.model';

@Component({
  selector: 'jhi-project-detail',
  templateUrl: './project-detail.component.html',
})
export class ProjectDetailComponent implements OnInit {
  project!: IProject;
  biddingPcks?: IBiddingPck[];
  isLoading = false;
  sum = 0;

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected biddingPckService: BiddingPckService,
    public router: Router,
    protected modalService: NgbModal,
    protected alertService: AlertService
  ) {}

  trackId = (_index: number, item: IBiddingPck): number => this.biddingPckService.getBiddingPckIdentifier(item);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ project }) => {
      this.project = project;
      if (project) {
        this.loadBiddingPcks();
        this.loadSumBiddingPcks();
      }
    });
  }

  loadBiddingPcks(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  loadSumBiddingPcks(): void {
    this.loadSumFromBackendWithRouteInformations().subscribe({
      next: res => {
        this.sum = res.body ? res.body : 0;
      },
    });
  }

  navigateToPage(page = this.page): void {
    this.page = page;
    this.loadBiddingPcks();
  }

  previousState(): void {
    window.history.back();
  }

  backToList(alerts: Alert[]): void {
    if (alerts.length) {
      const alert = { ...alerts[alerts.length - 1] };
      const queryParamsObj = {
        type: alert.type,
        translationKey: alert.translationKey,
      };
      this.router.navigate(['/project'], {
        queryParams: queryParamsObj,
      });
    } else {
      this.router.navigate(['/project']);
    }
  }

  delete(): void {
    const modalRef = this.modalService.open(ProjectDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.project = this.project;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed.subscribe(() => {
      const alerts = this.alertService.get();
      this.backToList(alerts);
    });
  }

  formatDate(date: any): string {
    return dayjs(date).format('DD/MM/YYYY');
  }

  protected mapNameWinProposal(id: any, biddingPck: IBiddingPck): string {
    if (id && biddingPck.biddingProposals && biddingPck.biddingProposals.length) {
      const proposal = biddingPck.biddingProposals.find(item => item.id === id);
      return proposal ? proposal.name ?? '' : '';
    }

    return '';
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return this.queryBackend(this.project.id, this.page, this.predicate, this.ascending);
  }

  protected loadSumFromBackendWithRouteInformations(): Observable<HttpResponse<number>> {
    return this.queryBackendSum(this.project.id);
  }

  protected queryBackendSum(projectid: number): Observable<HttpResponse<number>> {
    this.isLoading = true;
    const queryObject = {
      projectid,
    };
    return this.biddingPckService.querySum(queryObject);
  }

  protected queryBackend(projectid: number, page?: number, predicate?: string, ascending?: boolean): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      projectid,
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingPckService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingPcks = [...dataFromBody];
    this.biddingPcks.forEach(bidding => {
      bidding.winProposalName = this.mapNameWinProposal(bidding.winProposal, bidding);
    });
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingPck[] | null): IBiddingPck[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }
}
