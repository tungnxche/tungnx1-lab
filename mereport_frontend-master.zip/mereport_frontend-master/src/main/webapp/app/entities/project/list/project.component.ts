import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ActivatedRoute, Data, ParamMap, Router } from '@angular/router';
import {
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  merge,
  Observable,
  OperatorFunction,
  Subject,
  switchMap,
  tap,
} from 'rxjs';
import { NgbModal, NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';

import { IProject } from '../project.model';

import { ITEMS_PER_PAGE, ITEM_SEARCH, PAGE_HEADER, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { ASC, DESC, SORT, ITEM_DELETED_EVENT, DEFAULT_SORT_DATA, ALERT_TRANSLATION_KEY, ALERT_TYPE } from 'app/config/navigation.constants';
import { EntityArrayResponseType, ProjectService } from '../service/project.service';
import { ProjectDeleteDialogComponent } from '../delete/project-delete-dialog.component';
import { AlertService } from 'app/core/util/alert.service';
import { NgForm } from '@angular/forms';
import { IProjectChain } from 'app/entities/project-chain/project-chain.model';
import { ProjectChainService } from 'app/entities/project-chain/service/project-chain.service';

@Component({
  selector: 'jhi-project',
  templateUrl: './project.component.html',
})
export class ProjectComponent implements OnInit {
  projects?: IProject[];
  isLoading = false;
  searchProjectChain: boolean | null = null;

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  selectedChain: any = null;
  projectChains: IProjectChain[] = [];
  @ViewChild('instanceChain', { static: true }) instanceChain!: NgbTypeahead;
  focusChain$ = new Subject<IProjectChain>();
  clickChain$ = new Subject<IProjectChain>();

  constructor(
    protected projectService: ProjectService,
    protected activatedRoute: ActivatedRoute,
    public router: Router,
    protected modalService: NgbModal,
    protected alertService: AlertService,
    protected projectChainService: ProjectChainService
  ) {}

  trackId = (_index: number, item: IProject): number => this.projectService.getProjectIdentifier(item);

  ngOnInit(): void {
    this.load();
    this.loadProjectChains();
  }

  search(searchForm: NgForm): void {
    console.log('search', searchForm.value);
  }

  searchChain: OperatorFunction<string, readonly IProjectChain[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.clickChain$.pipe(filter(() => !this.instanceChain.isPopupOpen()));
    const inputFocus$ = this.focusChain$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === ''
          ? this.projectChains
          : this.projectChains.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))
        ).slice(0, 10)
      )
    );
  };

  checkSelectedChain(data: any): void {
    this.selectedChain = data.item;
  }

  formatter = (x: IProjectChain): string => (x.name ? x.name : '');

  checkSelected(ref: any): void {
    if (ref.value && this.selectedChain) {
      if (this.selectedChain.name !== ref.value) {
        ref.value = '';
      }
    }
  }

  delete(project: IProject): void {
    const modalRef = this.modalService.open(ProjectDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.project = project;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed
      .pipe(
        filter(reason => reason === ITEM_DELETED_EVENT),
        switchMap(() => this.loadFromBackendWithRouteInformations())
      )
      .subscribe({
        next: (res: EntityArrayResponseType) => {
          this.onResponseSuccess(res);
        },
      });
  }

  load(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  navigateToWithComponentValues(): void {
    this.handleNavigation(this.page, this.predicate, this.ascending);
  }

  navigateToPage(page = this.page): void {
    this.handleNavigation(page, this.predicate, this.ascending);
  }

  protected loadProjectChains(): void {
    this.projectChainService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<IProjectChain[]>) => res.body ?? []))
      .subscribe((projectChains: IProjectChain[]) => (this.projectChains = projectChains));
  }

  protected triggerAlertDeleted(alert: any): void {
    this.alertService.addAlert(alert);
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return combineLatest([this.activatedRoute.queryParamMap, this.activatedRoute.data]).pipe(
      tap(([params, data]) => this.fillComponentAttributeFromRoute(params, data)),
      tap(([params]) => this.checkExistAlert(params)),
      switchMap(() => this.queryBackend(this.page, this.predicate, this.ascending))
    );
  }

  protected checkExistAlert(params: ParamMap): void {
    if (params.get(ALERT_TYPE) && params.get(ALERT_TRANSLATION_KEY)) {
      this.triggerAlertDeleted({
        type: params.get(ALERT_TYPE),
        translationKey: params.get(ALERT_TRANSLATION_KEY),
      });
    }
  }

  protected fillComponentAttributeFromRoute(params: ParamMap, data: Data): void {
    const page = params.get(PAGE_HEADER);
    this.page = +(page ?? 1);
    const sort = (params.get(SORT) ?? data[DEFAULT_SORT_DATA]).split(',');
    this.predicate = sort[0];
    this.ascending = sort[1] === ASC;
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.projects = dataFromBody;
  }

  protected fillComponentAttributesFromResponseBody(data: IProject[] | null): IProject[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }

  protected queryBackend(page?: number, predicate?: string, ascending?: boolean): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.projectService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected handleNavigation(page = this.page, predicate?: string, ascending?: boolean): void {
    const queryParamsObj = {
      page,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };

    this.router.navigate(['./'], {
      relativeTo: this.activatedRoute,
      queryParams: queryParamsObj,
    });
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }
}
