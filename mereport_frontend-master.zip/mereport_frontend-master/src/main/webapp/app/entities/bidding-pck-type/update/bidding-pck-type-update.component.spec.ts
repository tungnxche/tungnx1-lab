import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { BiddingPckTypeFormService } from './bidding-pck-type-form.service';
import { BiddingPckTypeService } from '../service/bidding-pck-type.service';
import { IBiddingPckType } from '../bidding-pck-type.model';

import { BiddingPckTypeUpdateComponent } from './bidding-pck-type-update.component';

describe('BiddingPckType Management Update Component', () => {
  let comp: BiddingPckTypeUpdateComponent;
  let fixture: ComponentFixture<BiddingPckTypeUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let biddingPckTypeFormService: BiddingPckTypeFormService;
  let biddingPckTypeService: BiddingPckTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [BiddingPckTypeUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(BiddingPckTypeUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingPckTypeUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    biddingPckTypeFormService = TestBed.inject(BiddingPckTypeFormService);
    biddingPckTypeService = TestBed.inject(BiddingPckTypeService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should update editForm', () => {
      const biddingPckType: IBiddingPckType = { id: 456 };

      activatedRoute.data = of({ biddingPckType });
      comp.ngOnInit();

      expect(comp.biddingPckType).toEqual(biddingPckType);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPckType>>();
      const biddingPckType = { id: 123 };
      jest.spyOn(biddingPckTypeFormService, 'getBiddingPckType').mockReturnValue(biddingPckType);
      jest.spyOn(biddingPckTypeService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPckType });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingPckType }));
      saveSubject.complete();

      // THEN
      expect(biddingPckTypeFormService.getBiddingPckType).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(biddingPckTypeService.update).toHaveBeenCalledWith(expect.objectContaining(biddingPckType));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPckType>>();
      const biddingPckType = { id: 123 };
      jest.spyOn(biddingPckTypeFormService, 'getBiddingPckType').mockReturnValue({ id: null });
      jest.spyOn(biddingPckTypeService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPckType: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingPckType }));
      saveSubject.complete();

      // THEN
      expect(biddingPckTypeFormService.getBiddingPckType).toHaveBeenCalled();
      expect(biddingPckTypeService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingPckType>>();
      const biddingPckType = { id: 123 };
      jest.spyOn(biddingPckTypeService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingPckType });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(biddingPckTypeService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });
});
