import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { BiddingPckTypeFormService, BiddingPckTypeFormGroup } from './bidding-pck-type-form.service';
import { IBiddingPckType } from '../bidding-pck-type.model';
import { BiddingPckTypeService } from '../service/bidding-pck-type.service';

@Component({
  selector: 'jhi-bidding-pck-type-update',
  templateUrl: './bidding-pck-type-update.component.html',
})
export class BiddingPckTypeUpdateComponent implements OnInit {
  isSaving = false;
  biddingPckType: IBiddingPckType | null = null;

  editForm: BiddingPckTypeFormGroup = this.biddingPckTypeFormService.createBiddingPckTypeFormGroup();

  constructor(
    protected biddingPckTypeService: BiddingPckTypeService,
    protected biddingPckTypeFormService: BiddingPckTypeFormService,
    protected activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingPckType }) => {
      this.biddingPckType = biddingPckType;
      if (biddingPckType) {
        this.updateForm(biddingPckType);
      }
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const biddingPckType = this.biddingPckTypeFormService.getBiddingPckType(this.editForm);
    if (biddingPckType.id !== null) {
      this.subscribeToSaveResponse(this.biddingPckTypeService.update(biddingPckType));
    } else {
      this.subscribeToSaveResponse(this.biddingPckTypeService.create(biddingPckType));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBiddingPckType>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(biddingPckType: IBiddingPckType): void {
    this.biddingPckType = biddingPckType;
    this.biddingPckTypeFormService.resetForm(this.editForm, biddingPckType);
  }
}
