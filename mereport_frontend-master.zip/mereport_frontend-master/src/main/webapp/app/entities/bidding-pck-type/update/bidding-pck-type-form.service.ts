import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { IBiddingPckType, NewBiddingPckType } from '../bidding-pck-type.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IBiddingPckType for edit and NewBiddingPckTypeFormGroupInput for create.
 */
type BiddingPckTypeFormGroupInput = IBiddingPckType | PartialWithRequiredKeyOf<NewBiddingPckType>;

type BiddingPckTypeFormDefaults = Pick<NewBiddingPckType, 'id'>;

type BiddingPckTypeFormGroupContent = {
  id: FormControl<IBiddingPckType['id'] | NewBiddingPckType['id']>;
  name: FormControl<IBiddingPckType['name']>;
};

export type BiddingPckTypeFormGroup = FormGroup<BiddingPckTypeFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class BiddingPckTypeFormService {
  createBiddingPckTypeFormGroup(biddingPckType: BiddingPckTypeFormGroupInput = { id: null }): BiddingPckTypeFormGroup {
    const biddingPckTypeRawValue = {
      ...this.getFormDefaults(),
      ...biddingPckType,
    };
    return new FormGroup<BiddingPckTypeFormGroupContent>({
      id: new FormControl(
        { value: biddingPckTypeRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(biddingPckTypeRawValue.name, {
        validators: [Validators.required],
      }),
    });
  }

  getBiddingPckType(form: BiddingPckTypeFormGroup): IBiddingPckType | NewBiddingPckType {
    return form.getRawValue() as IBiddingPckType | NewBiddingPckType;
  }

  resetForm(form: BiddingPckTypeFormGroup, biddingPckType: BiddingPckTypeFormGroupInput): void {
    const biddingPckTypeRawValue = { ...this.getFormDefaults(), ...biddingPckType };
    form.reset(
      {
        ...biddingPckTypeRawValue,
        id: { value: biddingPckTypeRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): BiddingPckTypeFormDefaults {
    return {
      id: null,
    };
  }
}
