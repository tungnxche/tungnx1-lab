import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IBiddingPckType, NewBiddingPckType } from '../bidding-pck-type.model';

export type PartialUpdateBiddingPckType = Partial<IBiddingPckType> & Pick<IBiddingPckType, 'id'>;

export type EntityResponseType = HttpResponse<IBiddingPckType>;
export type EntityArrayResponseType = HttpResponse<IBiddingPckType[]>;

@Injectable({ providedIn: 'root' })
export class BiddingPckTypeService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/bidding-pck-types');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(biddingPckType: NewBiddingPckType): Observable<EntityResponseType> {
    return this.http.post<IBiddingPckType>(this.resourceUrl, biddingPckType, { observe: 'response' });
  }

  update(biddingPckType: IBiddingPckType): Observable<EntityResponseType> {
    return this.http.put<IBiddingPckType>(`${this.resourceUrl}/${this.getBiddingPckTypeIdentifier(biddingPckType)}`, biddingPckType, {
      observe: 'response',
    });
  }

  partialUpdate(biddingPckType: PartialUpdateBiddingPckType): Observable<EntityResponseType> {
    return this.http.patch<IBiddingPckType>(`${this.resourceUrl}/${this.getBiddingPckTypeIdentifier(biddingPckType)}`, biddingPckType, {
      observe: 'response',
    });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IBiddingPckType>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IBiddingPckType[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getBiddingPckTypeIdentifier(biddingPckType: Pick<IBiddingPckType, 'id'>): number {
    return biddingPckType.id;
  }

  compareBiddingPckType(o1: Pick<IBiddingPckType, 'id'> | null, o2: Pick<IBiddingPckType, 'id'> | null): boolean {
    return o1 && o2 ? this.getBiddingPckTypeIdentifier(o1) === this.getBiddingPckTypeIdentifier(o2) : o1 === o2;
  }

  addBiddingPckTypeToCollectionIfMissing<Type extends Pick<IBiddingPckType, 'id'>>(
    biddingPckTypeCollection: Type[],
    ...biddingPckTypesToCheck: (Type | null | undefined)[]
  ): Type[] {
    const biddingPckTypes: Type[] = biddingPckTypesToCheck.filter(isPresent);
    if (biddingPckTypes.length > 0) {
      const biddingPckTypeCollectionIdentifiers = biddingPckTypeCollection.map(
        biddingPckTypeItem => this.getBiddingPckTypeIdentifier(biddingPckTypeItem)!
      );
      const biddingPckTypesToAdd = biddingPckTypes.filter(biddingPckTypeItem => {
        const biddingPckTypeIdentifier = this.getBiddingPckTypeIdentifier(biddingPckTypeItem);
        if (biddingPckTypeCollectionIdentifiers.includes(biddingPckTypeIdentifier)) {
          return false;
        }
        biddingPckTypeCollectionIdentifiers.push(biddingPckTypeIdentifier);
        return true;
      });
      return [...biddingPckTypesToAdd, ...biddingPckTypeCollection];
    }
    return biddingPckTypeCollection;
  }
}
