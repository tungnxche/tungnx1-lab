import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { BiddingPckTypeComponent } from './list/bidding-pck-type.component';
import { BiddingPckTypeDetailComponent } from './detail/bidding-pck-type-detail.component';
import { BiddingPckTypeUpdateComponent } from './update/bidding-pck-type-update.component';
import { BiddingPckTypeDeleteDialogComponent } from './delete/bidding-pck-type-delete-dialog.component';
import { BiddingPckTypeRoutingModule } from './route/bidding-pck-type-routing.module';

@NgModule({
  imports: [SharedModule, BiddingPckTypeRoutingModule],
  declarations: [
    BiddingPckTypeComponent,
    BiddingPckTypeDetailComponent,
    BiddingPckTypeUpdateComponent,
    BiddingPckTypeDeleteDialogComponent,
  ],
})
export class BiddingPckTypeModule {}
