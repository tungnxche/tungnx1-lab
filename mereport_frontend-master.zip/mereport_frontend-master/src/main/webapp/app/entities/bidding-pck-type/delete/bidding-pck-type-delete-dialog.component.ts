import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { IBiddingPckType } from '../bidding-pck-type.model';
import { BiddingPckTypeService } from '../service/bidding-pck-type.service';
import { ITEM_DELETED_EVENT } from 'app/config/navigation.constants';

@Component({
  templateUrl: './bidding-pck-type-delete-dialog.component.html',
})
export class BiddingPckTypeDeleteDialogComponent {
  biddingPckType?: IBiddingPckType;

  constructor(protected biddingPckTypeService: BiddingPckTypeService, protected activeModal: NgbActiveModal) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.biddingPckTypeService.delete(id).subscribe(() => {
      this.activeModal.close(ITEM_DELETED_EVENT);
    });
  }
}
