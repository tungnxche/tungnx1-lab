import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { BiddingPckTypeComponent } from '../list/bidding-pck-type.component';
import { BiddingPckTypeDetailComponent } from '../detail/bidding-pck-type-detail.component';
import { BiddingPckTypeUpdateComponent } from '../update/bidding-pck-type-update.component';
import { BiddingPckTypeRoutingResolveService } from './bidding-pck-type-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const biddingPckTypeRoute: Routes = [
  {
    path: '',
    component: BiddingPckTypeComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: BiddingPckTypeDetailComponent,
    resolve: {
      biddingPckType: BiddingPckTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BiddingPckTypeUpdateComponent,
    resolve: {
      biddingPckType: BiddingPckTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: BiddingPckTypeUpdateComponent,
    resolve: {
      biddingPckType: BiddingPckTypeRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(biddingPckTypeRoute)],
  exports: [RouterModule],
})
export class BiddingPckTypeRoutingModule {}
