import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IBiddingPckType } from '../bidding-pck-type.model';
import { BiddingPckTypeService } from '../service/bidding-pck-type.service';

@Injectable({ providedIn: 'root' })
export class BiddingPckTypeRoutingResolveService implements Resolve<IBiddingPckType | null> {
  constructor(protected service: BiddingPckTypeService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IBiddingPckType | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((biddingPckType: HttpResponse<IBiddingPckType>) => {
          if (biddingPckType.body) {
            return of(biddingPckType.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
