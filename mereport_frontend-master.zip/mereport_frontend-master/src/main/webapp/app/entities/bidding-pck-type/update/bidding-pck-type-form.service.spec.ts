import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../bidding-pck-type.test-samples';

import { BiddingPckTypeFormService } from './bidding-pck-type-form.service';

describe('BiddingPckType Form Service', () => {
  let service: BiddingPckTypeFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiddingPckTypeFormService);
  });

  describe('Service methods', () => {
    describe('createBiddingPckTypeFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createBiddingPckTypeFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });

      it('passing IBiddingPckType should create a new form with FormGroup', () => {
        const formGroup = service.createBiddingPckTypeFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });
    });

    describe('getBiddingPckType', () => {
      it('should return NewBiddingPckType for default BiddingPckType initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createBiddingPckTypeFormGroup(sampleWithNewData);

        const biddingPckType = service.getBiddingPckType(formGroup) as any;

        expect(biddingPckType).toMatchObject(sampleWithNewData);
      });

      it('should return NewBiddingPckType for empty BiddingPckType initial value', () => {
        const formGroup = service.createBiddingPckTypeFormGroup();

        const biddingPckType = service.getBiddingPckType(formGroup) as any;

        expect(biddingPckType).toMatchObject({});
      });

      it('should return IBiddingPckType', () => {
        const formGroup = service.createBiddingPckTypeFormGroup(sampleWithRequiredData);

        const biddingPckType = service.getBiddingPckType(formGroup) as any;

        expect(biddingPckType).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IBiddingPckType should not enable id FormControl', () => {
        const formGroup = service.createBiddingPckTypeFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewBiddingPckType should disable id FormControl', () => {
        const formGroup = service.createBiddingPckTypeFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
