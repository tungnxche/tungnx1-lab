import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { BiddingPckTypeDetailComponent } from './bidding-pck-type-detail.component';

describe('BiddingPckType Management Detail Component', () => {
  let comp: BiddingPckTypeDetailComponent;
  let fixture: ComponentFixture<BiddingPckTypeDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BiddingPckTypeDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ biddingPckType: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(BiddingPckTypeDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(BiddingPckTypeDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load biddingPckType on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.biddingPckType).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
