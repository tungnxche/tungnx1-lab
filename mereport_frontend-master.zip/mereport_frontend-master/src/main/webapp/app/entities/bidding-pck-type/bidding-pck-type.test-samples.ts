import { IBiddingPckType, NewBiddingPckType } from './bidding-pck-type.model';

export const sampleWithRequiredData: IBiddingPckType = {
  id: 21888,
  name: 'bypass Gorgeous',
};

export const sampleWithPartialData: IBiddingPckType = {
  id: 10079,
  name: 'Incredible',
};

export const sampleWithFullData: IBiddingPckType = {
  id: 58500,
  name: 'Kentucky Ouguiya pixel',
};

export const sampleWithNewData: NewBiddingPckType = {
  name: 'Incredible',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
