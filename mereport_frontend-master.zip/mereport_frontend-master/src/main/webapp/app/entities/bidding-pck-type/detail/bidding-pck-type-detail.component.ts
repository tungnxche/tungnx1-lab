import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IBiddingPckType } from '../bidding-pck-type.model';

@Component({
  selector: 'jhi-bidding-pck-type-detail',
  templateUrl: './bidding-pck-type-detail.component.html',
})
export class BiddingPckTypeDetailComponent implements OnInit {
  biddingPckType: IBiddingPckType | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingPckType }) => {
      this.biddingPckType = biddingPckType;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
