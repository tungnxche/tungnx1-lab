export interface IBiddingPckType {
  id: number;
  name?: string | null;
}

export type NewBiddingPckType = Omit<IBiddingPckType, 'id'> & { id: null };
