import { NavbarItem } from "app/layouts/navbar/navbar.model";

export const EntityNavbarItems:NavbarItem[] = [
    new NavbarItem('project-chain', 'projectChain'),
    new NavbarItem('project', 'project'),
    new NavbarItem('bidding-pck-type', 'biddingPckType'),
    new NavbarItem('bidding-pck', 'biddingPck'),
    new NavbarItem('contractor', 'contractor'),
    new NavbarItem('bidding-proposal', 'biddingProposal'),
    new NavbarItem('bidding-doc', 'biddingDoc'),
    new NavbarItem('location', 'location'),
    new NavbarItem('proposal-type', 'proposalType'),
    new NavbarItem('approval-status', 'approvalStatus'),
    new NavbarItem('bidding-status', 'biddingStatus'),
];
