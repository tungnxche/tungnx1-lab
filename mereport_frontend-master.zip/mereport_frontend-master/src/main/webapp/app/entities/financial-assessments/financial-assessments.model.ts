export interface IFinancialAssessment {
  id: number;
  name?: string | null;
}

export type NewFinancialAssessment = Omit<IFinancialAssessment, 'id'> & { id: null };
