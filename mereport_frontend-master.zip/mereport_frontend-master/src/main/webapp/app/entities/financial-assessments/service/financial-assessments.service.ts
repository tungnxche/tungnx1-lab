import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IFinancialAssessment, NewFinancialAssessment } from '../financial-assessments.model';

export type PartialUpdateFinancialAssessment = Partial<IFinancialAssessment> & Pick<IFinancialAssessment, 'id'>;

type RestOf<T extends IFinancialAssessment | NewFinancialAssessment> = T;

export type RestFinancialAssessment = RestOf<IFinancialAssessment>;

export type NewRestFinancialAssessment = RestOf<NewFinancialAssessment>;

export type PartialUpdateRestFinancialAssessment = RestOf<PartialUpdateFinancialAssessment>;

export type EntityResponseType = HttpResponse<IFinancialAssessment>;
export type EntityArrayResponseType = HttpResponse<IFinancialAssessment[]>;

@Injectable({ providedIn: 'root' })
export class FinancialAssessmentService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/financial-assessments');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(financialAssessment: NewFinancialAssessment): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(financialAssessment);
    return this.http
      .post<RestFinancialAssessment>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(financialAssessment: IFinancialAssessment): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(financialAssessment);
    return this.http
      .put<RestFinancialAssessment>(`${this.resourceUrl}/${this.getFinancialAssessmentIdentifier(financialAssessment)}`, copy, {
        observe: 'response',
      })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(financialAssessment: PartialUpdateFinancialAssessment): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(financialAssessment);
    return this.http
      .patch<RestFinancialAssessment>(`${this.resourceUrl}/${this.getFinancialAssessmentIdentifier(financialAssessment)}`, copy, {
        observe: 'response',
      })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestFinancialAssessment>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestFinancialAssessment[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getFinancialAssessmentIdentifier(financialAssessment: Pick<IFinancialAssessment, 'id'>): number {
    return financialAssessment.id;
  }

  compareFinancialAssessment(o1: Pick<IFinancialAssessment, 'id'> | null, o2: Pick<IFinancialAssessment, 'id'> | null): boolean {
    return o1 && o2 ? this.getFinancialAssessmentIdentifier(o1) === this.getFinancialAssessmentIdentifier(o2) : o1 === o2;
  }

  addFinancialAssessmentToCollectionIfMissing<Type extends Pick<IFinancialAssessment, 'id'>>(
    financialAssessmentCollection: Type[],
    ...financialAssessmentsToCheck: (Type | null | undefined)[]
  ): Type[] {
    const financialAssessments: Type[] = financialAssessmentsToCheck.filter(isPresent);
    if (financialAssessments.length > 0) {
      const financialAssessmentCollectionIdentifiers = financialAssessmentCollection.map(
        financialAssessmentItem => this.getFinancialAssessmentIdentifier(financialAssessmentItem)!
      );
      const financialAssessmentsToAdd = financialAssessments.filter(financialAssessmentItem => {
        const financialAssessmentIdentifier = this.getFinancialAssessmentIdentifier(financialAssessmentItem);
        if (financialAssessmentCollectionIdentifiers.includes(financialAssessmentIdentifier)) {
          return false;
        }
        financialAssessmentCollectionIdentifiers.push(financialAssessmentIdentifier);
        return true;
      });
      return [...financialAssessmentsToAdd, ...financialAssessmentCollection];
    }
    return financialAssessmentCollection;
  }

  protected convertDateFromClient<T extends IFinancialAssessment | NewFinancialAssessment | PartialUpdateFinancialAssessment>(
    financialAssessment: T
  ): RestOf<T> {
    return {
      ...financialAssessment,
    };
  }

  protected convertDateFromServer(restfinancialAssessment: RestFinancialAssessment): IFinancialAssessment {
    return {
      ...restfinancialAssessment,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestFinancialAssessment>): HttpResponse<IFinancialAssessment> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestFinancialAssessment[]>): HttpResponse<IFinancialAssessment[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }
}
