import dayjs from 'dayjs/esm';

export interface ILocation {
  id: number;
  name?: string | null;
  postalCode?: string | null;
  priority?: number | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
}

export type NewLocation = Omit<ILocation, 'id'> & { id: null };
