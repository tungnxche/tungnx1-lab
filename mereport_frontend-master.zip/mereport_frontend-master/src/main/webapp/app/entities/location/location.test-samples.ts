import dayjs from 'dayjs/esm';

import { ILocation, NewLocation } from './location.model';

export const sampleWithRequiredData: ILocation = {
  id: 91847,
  name: 'parsing',
};

export const sampleWithPartialData: ILocation = {
  id: 32565,
  name: 'indigo Virginia Arkansas',
  postalCode: 'Unbranded Unbranded integrate',
  createdBy: 27801,
  createdOn: dayjs('2022-09-28T15:34'),
  modifiedBy: 4180,
  deletedBy: 31982,
};

export const sampleWithFullData: ILocation = {
  id: 85052,
  name: 'enable network Steel',
  postalCode: 'Business-focused Shoes',
  priority: 67336,
  createdBy: 35881,
  createdOn: dayjs('2022-09-28T21:26'),
  modifiedBy: 45885,
  modifiedOn: dayjs('2022-09-29T02:33'),
  deletedBy: 25707,
  deletedOn: dayjs('2022-09-28T07:48'),
};

export const sampleWithNewData: NewLocation = {
  name: 'Kỳ Data',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
