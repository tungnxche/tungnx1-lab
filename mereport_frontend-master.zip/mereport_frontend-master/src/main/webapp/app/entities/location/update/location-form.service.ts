import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { ILocation, NewLocation } from '../location.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts ILocation for edit and NewLocationFormGroupInput for create.
 */
type LocationFormGroupInput = ILocation | PartialWithRequiredKeyOf<NewLocation>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends ILocation | NewLocation> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type LocationFormRawValue = FormValueOf<ILocation>;

type NewLocationFormRawValue = FormValueOf<NewLocation>;

type LocationFormDefaults = Pick<NewLocation, 'id' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type LocationFormGroupContent = {
  id: FormControl<LocationFormRawValue['id'] | NewLocation['id']>;
  name: FormControl<LocationFormRawValue['name']>;
  postalCode: FormControl<LocationFormRawValue['postalCode']>;
  priority: FormControl<LocationFormRawValue['priority']>;
  createdBy: FormControl<LocationFormRawValue['createdBy']>;
  createdOn: FormControl<LocationFormRawValue['createdOn']>;
  modifiedBy: FormControl<LocationFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<LocationFormRawValue['modifiedOn']>;
  deletedBy: FormControl<LocationFormRawValue['deletedBy']>;
  deletedOn: FormControl<LocationFormRawValue['deletedOn']>;
};

export type LocationFormGroup = FormGroup<LocationFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class LocationFormService {
  createLocationFormGroup(location: LocationFormGroupInput = { id: null }): LocationFormGroup {
    const locationRawValue = this.convertLocationToLocationRawValue({
      ...this.getFormDefaults(),
      ...location,
    });
    return new FormGroup<LocationFormGroupContent>({
      id: new FormControl(
        { value: locationRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(locationRawValue.name, {
        validators: [Validators.required],
      }),
      postalCode: new FormControl(locationRawValue.postalCode),
      priority: new FormControl(locationRawValue.priority),
      createdBy: new FormControl(locationRawValue.createdBy),
      createdOn: new FormControl(locationRawValue.createdOn),
      modifiedBy: new FormControl(locationRawValue.modifiedBy),
      modifiedOn: new FormControl(locationRawValue.modifiedOn),
      deletedBy: new FormControl(locationRawValue.deletedBy),
      deletedOn: new FormControl(locationRawValue.deletedOn),
    });
  }

  getLocation(form: LocationFormGroup): ILocation | NewLocation {
    return this.convertLocationRawValueToLocation(form.getRawValue() as LocationFormRawValue | NewLocationFormRawValue);
  }

  resetForm(form: LocationFormGroup, location: LocationFormGroupInput): void {
    const locationRawValue = this.convertLocationToLocationRawValue({ ...this.getFormDefaults(), ...location });
    form.reset(
      {
        ...locationRawValue,
        id: { value: locationRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): LocationFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertLocationRawValueToLocation(rawLocation: LocationFormRawValue | NewLocationFormRawValue): ILocation | NewLocation {
    return {
      ...rawLocation,
      createdOn: dayjs(rawLocation.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawLocation.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawLocation.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertLocationToLocationRawValue(
    location: ILocation | (Partial<NewLocation> & LocationFormDefaults)
  ): LocationFormRawValue | PartialWithRequiredKeyOf<NewLocationFormRawValue> {
    return {
      ...location,
      createdOn: location.createdOn ? location.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: location.modifiedOn ? location.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: location.deletedOn ? location.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
