import dayjs from 'dayjs/esm';
import { IFinancialAssessment } from '../financial-assessments/financial-assessments.model';

export interface IContractor {
  id: number;
  name?: string | null;
  address?: string | null;
  phone?: string | null;
  internal?: boolean | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
  scope?: number | null;
  financialAssessment?: IFinancialAssessment | null;
}

export type NewContractor = Omit<IContractor, 'id'> & { id: null };
