import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../contractor.test-samples';

import { ContractorFormService } from './contractor-form.service';

describe('Contractor Form Service', () => {
  let service: ContractorFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContractorFormService);
  });

  describe('Service methods', () => {
    describe('createContractorFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createContractorFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            address: expect.any(Object),
            phone: expect.any(Object),
            internal: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
          })
        );
      });

      it('passing IContractor should create a new form with FormGroup', () => {
        const formGroup = service.createContractorFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            address: expect.any(Object),
            phone: expect.any(Object),
            internal: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
          })
        );
      });
    });

    describe('getContractor', () => {
      it('should return NewContractor for default Contractor initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createContractorFormGroup(sampleWithNewData);

        const contractor = service.getContractor(formGroup) as any;

        expect(contractor).toMatchObject(sampleWithNewData);
      });

      it('should return NewContractor for empty Contractor initial value', () => {
        const formGroup = service.createContractorFormGroup();

        const contractor = service.getContractor(formGroup) as any;

        expect(contractor).toMatchObject({});
      });

      it('should return IContractor', () => {
        const formGroup = service.createContractorFormGroup(sampleWithRequiredData);

        const contractor = service.getContractor(formGroup) as any;

        expect(contractor).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IContractor should not enable id FormControl', () => {
        const formGroup = service.createContractorFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewContractor should disable id FormControl', () => {
        const formGroup = service.createContractorFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
