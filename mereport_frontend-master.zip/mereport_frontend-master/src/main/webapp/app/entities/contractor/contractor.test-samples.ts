import dayjs from 'dayjs/esm';

import { IContractor, NewContractor } from './contractor.model';

export const sampleWithRequiredData: IContractor = {
  id: 10389,
  name: 'sensor Nepal',
};

export const sampleWithPartialData: IContractor = {
  id: 84524,
  name: 'Table',
  address: 'Handcrafted',
  createdOn: dayjs('2022-09-28T13:19'),
  deletedOn: dayjs('2022-09-28T15:11'),
};

export const sampleWithFullData: IContractor = {
  id: 71358,
  name: 'Pennsylvania global Soft',
  address: 'compress',
  phone: '027 7405 2919',
  internal: true,
  createdBy: 2871,
  createdOn: dayjs('2022-09-28T19:12'),
  modifiedBy: 82743,
  modifiedOn: dayjs('2022-09-28T12:23'),
  deletedBy: 77074,
  deletedOn: dayjs('2022-09-29T03:57'),
};

export const sampleWithNewData: NewContractor = {
  name: 'Integration payment',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
