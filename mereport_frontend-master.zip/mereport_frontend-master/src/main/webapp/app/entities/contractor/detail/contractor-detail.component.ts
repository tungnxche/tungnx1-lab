import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ASC, DESC } from 'app/config/navigation.constants';
import { ITEMS_PER_PAGE, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { Alert, AlertService } from 'app/core/util/alert.service';
import { IBiddingProposal } from 'app/entities/bidding-proposal/bidding-proposal.model';
import { BiddingProposalService, EntityArrayResponseType } from 'app/entities/bidding-proposal/service/bidding-proposal.service';
import { Observable, tap } from 'rxjs';

import { IContractor } from '../contractor.model';
import { ContractorDeleteDialogComponent } from '../delete/contractor-delete-dialog.component';

@Component({
  selector: 'jhi-contractor-detail',
  templateUrl: './contractor-detail.component.html',
})
export class ContractorDetailComponent implements OnInit {
  contractor!: IContractor;
  options = [true, false];
  biddingProposals?: IBiddingProposal[];
  isLoading = false;

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected router: Router,
    protected modalService: NgbModal,
    protected biddingProposalService: BiddingProposalService,
    protected alertService: AlertService
  ) {}

  trackId = (_index: number, item: IBiddingProposal): number => this.biddingProposalService.getBiddingProposalIdentifier(item);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ contractor }) => {
      this.contractor = contractor;
      if (contractor) {
        this.loadBiddingProposals();
      }
    });
  }

  loadBiddingProposals(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: EntityArrayResponseType) => {
        this.onResponseSuccess(res);
      },
    });
  }

  navigateToPage(page = this.page): void {
    this.page = page;
    this.loadBiddingProposals();
  }

  previousState(): void {
    window.history.back();
  }

  backToList(alerts: Alert[]): void {
    if (alerts.length) {
      const alert = { ...alerts[alerts.length - 1] };
      const queryParamsObj = {
        type: alert.type,
        translationKey: alert.translationKey,
      };
      this.router.navigate(['/contractor'], {
        queryParams: queryParamsObj,
      });
    } else {
      this.router.navigate(['/contractor']);
    }
  }

  delete(): void {
    const modalRef = this.modalService.open(ContractorDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.contractor = this.contractor;
    // unsubscribe not needed because closed completes on modal close
    modalRef.closed.subscribe(() => {
      const alerts = this.alertService.get();
      this.backToList(alerts);
    });
  }

  protected loadFromBackendWithRouteInformations(): Observable<EntityArrayResponseType> {
    return this.queryBackend(this.contractor.id, this.page, this.predicate, this.ascending);
  }

  protected queryBackend(
    contractorid: number,
    page?: number,
    predicate?: string,
    ascending?: boolean
  ): Observable<EntityArrayResponseType> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      contractorid,
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingProposalService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }

  protected onResponseSuccess(response: EntityArrayResponseType): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingProposals = [...dataFromBody];
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingProposal[] | null): IBiddingProposal[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }
}
