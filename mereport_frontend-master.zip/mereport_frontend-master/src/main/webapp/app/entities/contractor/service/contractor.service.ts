import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import dayjs from 'dayjs/esm';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IContractor, NewContractor } from '../contractor.model';

export type PartialUpdateContractor = Partial<IContractor> & Pick<IContractor, 'id'>;

type RestOf<T extends IContractor | NewContractor> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

export type RestContractor = RestOf<IContractor>;

export type NewRestContractor = RestOf<NewContractor>;

export type PartialUpdateRestContractor = RestOf<PartialUpdateContractor>;

export type EntityResponseType = HttpResponse<IContractor>;
export type EntityArrayResponseType = HttpResponse<IContractor[]>;

@Injectable({ providedIn: 'root' })
export class ContractorService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/contractors');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(contractor: NewContractor): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(contractor);
    return this.http
      .post<RestContractor>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(contractor: IContractor): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(contractor);
    return this.http
      .put<RestContractor>(`${this.resourceUrl}/${this.getContractorIdentifier(contractor)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(contractor: PartialUpdateContractor): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(contractor);
    return this.http
      .patch<RestContractor>(`${this.resourceUrl}/${this.getContractorIdentifier(contractor)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestContractor>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestContractor[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getContractorIdentifier(contractor: Pick<IContractor, 'id'>): number {
    return contractor.id;
  }

  compareContractor(o1: Pick<IContractor, 'id'> | null, o2: Pick<IContractor, 'id'> | null): boolean {
    return o1 && o2 ? this.getContractorIdentifier(o1) === this.getContractorIdentifier(o2) : o1 === o2;
  }

  addContractorToCollectionIfMissing<Type extends Pick<IContractor, 'id'>>(
    contractorCollection: Type[],
    ...contractorsToCheck: (Type | null | undefined)[]
  ): Type[] {
    const contractors: Type[] = contractorsToCheck.filter(isPresent);
    if (contractors.length > 0) {
      const contractorCollectionIdentifiers = contractorCollection.map(contractorItem => this.getContractorIdentifier(contractorItem)!);
      const contractorsToAdd = contractors.filter(contractorItem => {
        const contractorIdentifier = this.getContractorIdentifier(contractorItem);
        if (contractorCollectionIdentifiers.includes(contractorIdentifier)) {
          return false;
        }
        contractorCollectionIdentifiers.push(contractorIdentifier);
        return true;
      });
      return [...contractorsToAdd, ...contractorCollection];
    }
    return contractorCollection;
  }

  protected convertDateFromClient<T extends IContractor | NewContractor | PartialUpdateContractor>(contractor: T): RestOf<T> {
    return {
      ...contractor,
      createdOn: contractor.createdOn?.toJSON() ?? null,
      modifiedOn: contractor.modifiedOn?.toJSON() ?? null,
      deletedOn: contractor.deletedOn?.toJSON() ?? null,
    };
  }

  protected convertDateFromServer(restContractor: RestContractor): IContractor {
    return {
      ...restContractor,
      createdOn: restContractor.createdOn ? dayjs(restContractor.createdOn) : undefined,
      modifiedOn: restContractor.modifiedOn ? dayjs(restContractor.modifiedOn) : undefined,
      deletedOn: restContractor.deletedOn ? dayjs(restContractor.deletedOn) : undefined,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestContractor>): HttpResponse<IContractor> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestContractor[]>): HttpResponse<IContractor[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }
}
