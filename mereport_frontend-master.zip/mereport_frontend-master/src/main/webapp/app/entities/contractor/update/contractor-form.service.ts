import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IContractor, NewContractor } from '../contractor.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IContractor for edit and NewContractorFormGroupInput for create.
 */
type ContractorFormGroupInput = IContractor | PartialWithRequiredKeyOf<NewContractor>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IContractor | NewContractor> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type ContractorFormRawValue = FormValueOf<IContractor>;

type NewContractorFormRawValue = FormValueOf<NewContractor>;

type ContractorFormDefaults = Pick<NewContractor, 'id' | 'internal' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type ContractorFormGroupContent = {
  id: FormControl<ContractorFormRawValue['id'] | NewContractor['id']>;
  name: FormControl<ContractorFormRawValue['name']>;
  address: FormControl<ContractorFormRawValue['address']>;
  phone: FormControl<ContractorFormRawValue['phone']>;
  internal: FormControl<ContractorFormRawValue['internal']>;
  createdBy: FormControl<ContractorFormRawValue['createdBy']>;
  createdOn: FormControl<ContractorFormRawValue['createdOn']>;
  modifiedBy: FormControl<ContractorFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<ContractorFormRawValue['modifiedOn']>;
  deletedBy: FormControl<ContractorFormRawValue['deletedBy']>;
  deletedOn: FormControl<ContractorFormRawValue['deletedOn']>;
  scope: FormControl<ContractorFormRawValue['scope']>;
  financialAssessment: FormControl<ContractorFormRawValue['financialAssessment']>;
};

export type ContractorFormGroup = FormGroup<ContractorFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class ContractorFormService {
  createContractorFormGroup(contractor: ContractorFormGroupInput = { id: null }): ContractorFormGroup {
    const contractorRawValue = this.convertContractorToContractorRawValue({
      ...this.getFormDefaults(),
      ...contractor,
    });
    return new FormGroup<ContractorFormGroupContent>({
      id: new FormControl(
        { value: contractorRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(contractorRawValue.name, {
        validators: [Validators.required],
      }),
      address: new FormControl(contractorRawValue.address),
      phone: new FormControl(contractorRawValue.phone),
      internal: new FormControl(contractorRawValue.internal),
      createdBy: new FormControl(contractorRawValue.createdBy),
      createdOn: new FormControl(contractorRawValue.createdOn),
      modifiedBy: new FormControl(contractorRawValue.modifiedBy),
      modifiedOn: new FormControl(contractorRawValue.modifiedOn),
      deletedBy: new FormControl(contractorRawValue.deletedBy),
      deletedOn: new FormControl(contractorRawValue.deletedOn),
      scope: new FormControl(contractorRawValue.scope),
      financialAssessment: new FormControl(contractorRawValue.financialAssessment),
    });
  }

  getContractor(form: ContractorFormGroup): IContractor | NewContractor {
    return this.convertContractorRawValueToContractor(form.getRawValue() as ContractorFormRawValue | NewContractorFormRawValue);
  }

  resetForm(form: ContractorFormGroup, contractor: ContractorFormGroupInput): void {
    console.log('data', contractor);
    const contractorRawValue = this.convertContractorToContractorRawValue({ ...this.getFormDefaults(), ...contractor });
    form.reset(
      {
        ...contractorRawValue,
        id: { value: contractorRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): ContractorFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      internal: true,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertContractorRawValueToContractor(
    rawContractor: ContractorFormRawValue | NewContractorFormRawValue
  ): IContractor | NewContractor {
    return {
      ...rawContractor,
      createdOn: dayjs(rawContractor.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawContractor.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawContractor.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertContractorToContractorRawValue(
    contractor: IContractor | (Partial<NewContractor> & ContractorFormDefaults)
  ): ContractorFormRawValue | PartialWithRequiredKeyOf<NewContractorFormRawValue> {
    return {
      ...contractor,
      createdOn: contractor.createdOn ? contractor.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: contractor.modifiedOn ? contractor.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: contractor.deletedOn ? contractor.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
