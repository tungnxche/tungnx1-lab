import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { merge, Observable, OperatorFunction, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, finalize, map, tap } from 'rxjs/operators';

import { ContractorFormService, ContractorFormGroup } from './contractor-form.service';
import { IContractor } from '../contractor.model';
import { ContractorService } from '../service/contractor.service';
import { ASC, DESC } from 'app/config/navigation.constants';
import { ITEMS_PER_PAGE, ITEM_SEARCH, TOTAL_COUNT_RESPONSE_HEADER } from 'app/config/pagination.constants';
import { IBiddingProposal } from 'app/entities/bidding-proposal/bidding-proposal.model';
import { BiddingProposalService } from 'app/entities/bidding-proposal/service/bidding-proposal.service';
import { FinancialAssessmentService } from 'app/entities/financial-assessments/service/financial-assessments.service';
import { IFinancialAssessment } from 'app/entities/financial-assessments/financial-assessments.model';
import { NgbTypeahead, NgbTypeaheadSelectItemEvent } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'jhi-contractor-update',
  templateUrl: './contractor-update.component.html',
})
export class ContractorUpdateComponent implements OnInit {
  contractor!: IContractor;
  options = [true, false];
  biddingProposals?: IBiddingProposal[];
  financialAssessments: IFinancialAssessment[] = [];
  isLoading = false;

  selected: any = null;

  predicate = 'id';
  ascending = false;

  itemsPerPage = ITEMS_PER_PAGE;
  totalItems = 0;
  page = 1;
  isSaving = false;

  editForm: ContractorFormGroup = this.contractorFormService.createContractorFormGroup();

  @ViewChild('instance', { static: true }) instance!: NgbTypeahead;

  focus$ = new Subject<IFinancialAssessment>();
  click$ = new Subject<IFinancialAssessment>();

  constructor(
    protected contractorService: ContractorService,
    protected contractorFormService: ContractorFormService,
    protected activatedRoute: ActivatedRoute,
    protected biddingProposalService: BiddingProposalService,
    protected financialAssessmentService: FinancialAssessmentService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ contractor }) => {
      this.contractor = contractor;
      if (contractor) {
        this.updateForm(contractor);
        this.loadBiddingProposals();
      }
      this.loadFinancialAssessments();
    });
  }

  search: OperatorFunction<string, readonly IFinancialAssessment[]> = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
    const inputFocus$ = this.focus$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term: any) =>
        (term === ''
          ? this.financialAssessments
          : this.financialAssessments.filter(state => new RegExp(term, 'mi').test(state.name ? state.name : ''))
        ).slice(0, 10)
      )
    );
  };

  selectedReview(data: NgbTypeaheadSelectItemEvent): void {
    this.selected = data.item;
  }

  formatter = (x: IFinancialAssessment): string => (x.name ? x.name : '');

  checkSelected(ref: any): void {
    if (ref.value && this.selected) {
      if (this.selected.name !== ref.value) {
        ref.value = '';
      }
    }
  }

  trackId = (_index: number, item: IBiddingProposal): number => this.biddingProposalService.getBiddingProposalIdentifier(item);

  loadBiddingProposals(): void {
    this.loadFromBackendWithRouteInformations().subscribe({
      next: (res: HttpResponse<IBiddingProposal[]>) => {
        this.onResponseSuccess(res);
      },
    });
  }

  previousState(): void {
    window.history.back();
  }

  navigateToPage(page = this.page): void {
    this.page = page;
    this.loadBiddingProposals();
  }

  save(): void {
    this.isSaving = true;
    const contractor = this.contractorFormService.getContractor(this.editForm);
    if (contractor.id !== null) {
      this.subscribeToSaveResponse(this.contractorService.update(contractor));
    } else {
      this.subscribeToSaveResponse(this.contractorService.create(contractor));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IContractor>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(contractor: IContractor): void {
    this.contractor = contractor;
    const cloneContractor: any = { ...contractor };
    cloneContractor.financialAssessment = cloneContractor.financialAssessment?.id;
    this.contractorFormService.resetForm(this.editForm, cloneContractor);
  }

  protected loadFromBackendWithRouteInformations(): Observable<HttpResponse<IBiddingProposal[]>> {
    return this.queryBackend(this.contractor.id, this.page, this.predicate, this.ascending);
  }

  protected queryBackend(
    contractorid: number,
    page?: number,
    predicate?: string,
    ascending?: boolean
  ): Observable<HttpResponse<IBiddingProposal[]>> {
    this.isLoading = true;
    const pageToLoad: number = page ?? 1;
    const queryObject = {
      contractorid,
      page: pageToLoad - 1,
      size: this.itemsPerPage,
      sort: this.getSortQueryParam(predicate, ascending),
    };
    return this.biddingProposalService.query(queryObject).pipe(tap(() => (this.isLoading = false)));
  }

  protected getSortQueryParam(predicate = this.predicate, ascending = this.ascending): string[] {
    const ascendingQueryParam = ascending ? ASC : DESC;
    if (predicate === '') {
      return [];
    } else {
      return [predicate + ',' + ascendingQueryParam];
    }
  }

  protected onResponseSuccess(response: HttpResponse<IBiddingProposal[]>): void {
    this.fillComponentAttributesFromResponseHeader(response.headers);
    const dataFromBody = this.fillComponentAttributesFromResponseBody(response.body);
    this.biddingProposals = [...dataFromBody];
  }

  protected fillComponentAttributesFromResponseBody(data: IBiddingProposal[] | null): IBiddingProposal[] {
    return data ?? [];
  }

  protected fillComponentAttributesFromResponseHeader(headers: HttpHeaders): void {
    this.totalItems = Number(headers.get(TOTAL_COUNT_RESPONSE_HEADER));
  }

  protected loadFinancialAssessments(): void {
    this.financialAssessmentService
      .query({
        size: ITEM_SEARCH,
      })
      .pipe(map((res: HttpResponse<IFinancialAssessment[]>) => res.body ?? []))
      .subscribe((financialAssessments: IFinancialAssessment[]) => (this.financialAssessments = financialAssessments));
  }
}
