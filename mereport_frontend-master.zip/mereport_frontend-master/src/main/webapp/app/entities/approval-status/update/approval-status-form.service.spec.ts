import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../approval-status.test-samples';

import { ApprovalStatusFormService } from './approval-status-form.service';

describe('ApprovalStatus Form Service', () => {
  let service: ApprovalStatusFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApprovalStatusFormService);
  });

  describe('Service methods', () => {
    describe('createApprovalStatusFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createApprovalStatusFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });

      it('passing IApprovalStatus should create a new form with FormGroup', () => {
        const formGroup = service.createApprovalStatusFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
          })
        );
      });
    });

    describe('getApprovalStatus', () => {
      it('should return NewApprovalStatus for default ApprovalStatus initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createApprovalStatusFormGroup(sampleWithNewData);

        const approvalStatus = service.getApprovalStatus(formGroup) as any;

        expect(approvalStatus).toMatchObject(sampleWithNewData);
      });

      it('should return NewApprovalStatus for empty ApprovalStatus initial value', () => {
        const formGroup = service.createApprovalStatusFormGroup();

        const approvalStatus = service.getApprovalStatus(formGroup) as any;

        expect(approvalStatus).toMatchObject({});
      });

      it('should return IApprovalStatus', () => {
        const formGroup = service.createApprovalStatusFormGroup(sampleWithRequiredData);

        const approvalStatus = service.getApprovalStatus(formGroup) as any;

        expect(approvalStatus).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IApprovalStatus should not enable id FormControl', () => {
        const formGroup = service.createApprovalStatusFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewApprovalStatus should disable id FormControl', () => {
        const formGroup = service.createApprovalStatusFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
