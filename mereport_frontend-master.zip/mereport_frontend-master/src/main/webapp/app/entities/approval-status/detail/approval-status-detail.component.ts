import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IApprovalStatus } from '../approval-status.model';

@Component({
  selector: 'jhi-approval-status-detail',
  templateUrl: './approval-status-detail.component.html',
})
export class ApprovalStatusDetailComponent implements OnInit {
  approvalStatus: IApprovalStatus | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ approvalStatus }) => {
      this.approvalStatus = approvalStatus;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
