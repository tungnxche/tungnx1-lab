import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ApprovalStatusComponent } from '../list/approval-status.component';
import { ApprovalStatusDetailComponent } from '../detail/approval-status-detail.component';
import { ApprovalStatusUpdateComponent } from '../update/approval-status-update.component';
import { ApprovalStatusRoutingResolveService } from './approval-status-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const approvalStatusRoute: Routes = [
  {
    path: '',
    component: ApprovalStatusComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: ApprovalStatusDetailComponent,
    resolve: {
      approvalStatus: ApprovalStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: ApprovalStatusUpdateComponent,
    resolve: {
      approvalStatus: ApprovalStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: ApprovalStatusUpdateComponent,
    resolve: {
      approvalStatus: ApprovalStatusRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(approvalStatusRoute)],
  exports: [RouterModule],
})
export class ApprovalStatusRoutingModule {}
