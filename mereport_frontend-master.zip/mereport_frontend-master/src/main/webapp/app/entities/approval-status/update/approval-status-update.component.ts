import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { ApprovalStatusFormService, ApprovalStatusFormGroup } from './approval-status-form.service';
import { IApprovalStatus } from '../approval-status.model';
import { ApprovalStatusService } from '../service/approval-status.service';

@Component({
  selector: 'jhi-approval-status-update',
  templateUrl: './approval-status-update.component.html',
})
export class ApprovalStatusUpdateComponent implements OnInit {
  isSaving = false;
  approvalStatus: IApprovalStatus | null = null;

  editForm: ApprovalStatusFormGroup = this.approvalStatusFormService.createApprovalStatusFormGroup();

  constructor(
    protected approvalStatusService: ApprovalStatusService,
    protected approvalStatusFormService: ApprovalStatusFormService,
    protected activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ approvalStatus }) => {
      this.approvalStatus = approvalStatus;
      if (approvalStatus) {
        this.updateForm(approvalStatus);
      }
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const approvalStatus = this.approvalStatusFormService.getApprovalStatus(this.editForm);
    if (approvalStatus.id !== null) {
      this.subscribeToSaveResponse(this.approvalStatusService.update(approvalStatus));
    } else {
      this.subscribeToSaveResponse(this.approvalStatusService.create(approvalStatus));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IApprovalStatus>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(approvalStatus: IApprovalStatus): void {
    this.approvalStatus = approvalStatus;
    this.approvalStatusFormService.resetForm(this.editForm, approvalStatus);
  }
}
