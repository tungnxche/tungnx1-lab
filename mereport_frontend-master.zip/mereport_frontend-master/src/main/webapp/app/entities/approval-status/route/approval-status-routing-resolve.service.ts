import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IApprovalStatus } from '../approval-status.model';
import { ApprovalStatusService } from '../service/approval-status.service';

@Injectable({ providedIn: 'root' })
export class ApprovalStatusRoutingResolveService implements Resolve<IApprovalStatus | null> {
  constructor(protected service: ApprovalStatusService, protected router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IApprovalStatus | null | never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        mergeMap((approvalStatus: HttpResponse<IApprovalStatus>) => {
          if (approvalStatus.body) {
            return of(approvalStatus.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(null);
  }
}
