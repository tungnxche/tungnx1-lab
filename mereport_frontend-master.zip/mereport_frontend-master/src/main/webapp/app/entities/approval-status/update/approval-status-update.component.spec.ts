import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { ApprovalStatusFormService } from './approval-status-form.service';
import { ApprovalStatusService } from '../service/approval-status.service';
import { IApprovalStatus } from '../approval-status.model';

import { ApprovalStatusUpdateComponent } from './approval-status-update.component';

describe('ApprovalStatus Management Update Component', () => {
  let comp: ApprovalStatusUpdateComponent;
  let fixture: ComponentFixture<ApprovalStatusUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let approvalStatusFormService: ApprovalStatusFormService;
  let approvalStatusService: ApprovalStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [ApprovalStatusUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(ApprovalStatusUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(ApprovalStatusUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    approvalStatusFormService = TestBed.inject(ApprovalStatusFormService);
    approvalStatusService = TestBed.inject(ApprovalStatusService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should update editForm', () => {
      const approvalStatus: IApprovalStatus = { id: 456 };

      activatedRoute.data = of({ approvalStatus });
      comp.ngOnInit();

      expect(comp.approvalStatus).toEqual(approvalStatus);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IApprovalStatus>>();
      const approvalStatus = { id: 123 };
      jest.spyOn(approvalStatusFormService, 'getApprovalStatus').mockReturnValue(approvalStatus);
      jest.spyOn(approvalStatusService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ approvalStatus });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: approvalStatus }));
      saveSubject.complete();

      // THEN
      expect(approvalStatusFormService.getApprovalStatus).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(approvalStatusService.update).toHaveBeenCalledWith(expect.objectContaining(approvalStatus));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IApprovalStatus>>();
      const approvalStatus = { id: 123 };
      jest.spyOn(approvalStatusFormService, 'getApprovalStatus').mockReturnValue({ id: null });
      jest.spyOn(approvalStatusService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ approvalStatus: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: approvalStatus }));
      saveSubject.complete();

      // THEN
      expect(approvalStatusFormService.getApprovalStatus).toHaveBeenCalled();
      expect(approvalStatusService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IApprovalStatus>>();
      const approvalStatus = { id: 123 };
      jest.spyOn(approvalStatusService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ approvalStatus });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(approvalStatusService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });
});
