import { IApprovalStatus, NewApprovalStatus } from './approval-status.model';

export const sampleWithRequiredData: IApprovalStatus = {
  id: 92319,
  name: 'Buckinghamshire Soft',
};

export const sampleWithPartialData: IApprovalStatus = {
  id: 83841,
  name: 'Facilitator Bénin',
};

export const sampleWithFullData: IApprovalStatus = {
  id: 71790,
  name: 'architectures',
};

export const sampleWithNewData: NewApprovalStatus = {
  name: 'Vincent',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
