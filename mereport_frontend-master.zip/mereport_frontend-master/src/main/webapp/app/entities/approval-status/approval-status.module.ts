import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { ApprovalStatusComponent } from './list/approval-status.component';
import { ApprovalStatusDetailComponent } from './detail/approval-status-detail.component';
import { ApprovalStatusUpdateComponent } from './update/approval-status-update.component';
import { ApprovalStatusDeleteDialogComponent } from './delete/approval-status-delete-dialog.component';
import { ApprovalStatusRoutingModule } from './route/approval-status-routing.module';

@NgModule({
  imports: [SharedModule, ApprovalStatusRoutingModule],
  declarations: [
    ApprovalStatusComponent,
    ApprovalStatusDetailComponent,
    ApprovalStatusUpdateComponent,
    ApprovalStatusDeleteDialogComponent,
  ],
})
export class ApprovalStatusModule {}
