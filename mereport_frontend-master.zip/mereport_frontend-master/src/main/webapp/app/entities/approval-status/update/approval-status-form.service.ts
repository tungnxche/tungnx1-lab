import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { IApprovalStatus, NewApprovalStatus } from '../approval-status.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IApprovalStatus for edit and NewApprovalStatusFormGroupInput for create.
 */
type ApprovalStatusFormGroupInput = IApprovalStatus | PartialWithRequiredKeyOf<NewApprovalStatus>;

type ApprovalStatusFormDefaults = Pick<NewApprovalStatus, 'id'>;

type ApprovalStatusFormGroupContent = {
  id: FormControl<IApprovalStatus['id'] | NewApprovalStatus['id']>;
  name: FormControl<IApprovalStatus['name']>;
};

export type ApprovalStatusFormGroup = FormGroup<ApprovalStatusFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class ApprovalStatusFormService {
  createApprovalStatusFormGroup(approvalStatus: ApprovalStatusFormGroupInput = { id: null }): ApprovalStatusFormGroup {
    const approvalStatusRawValue = {
      ...this.getFormDefaults(),
      ...approvalStatus,
    };
    return new FormGroup<ApprovalStatusFormGroupContent>({
      id: new FormControl(
        { value: approvalStatusRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(approvalStatusRawValue.name, {
        validators: [Validators.required],
      }),
    });
  }

  getApprovalStatus(form: ApprovalStatusFormGroup): IApprovalStatus | NewApprovalStatus {
    return form.getRawValue() as IApprovalStatus | NewApprovalStatus;
  }

  resetForm(form: ApprovalStatusFormGroup, approvalStatus: ApprovalStatusFormGroupInput): void {
    const approvalStatusRawValue = { ...this.getFormDefaults(), ...approvalStatus };
    form.reset(
      {
        ...approvalStatusRawValue,
        id: { value: approvalStatusRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): ApprovalStatusFormDefaults {
    return {
      id: null,
    };
  }
}
