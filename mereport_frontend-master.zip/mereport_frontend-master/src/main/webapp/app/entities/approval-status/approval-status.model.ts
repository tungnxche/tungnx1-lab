export interface IApprovalStatus {
  id: number;
  name?: string | null;
}

export type NewApprovalStatus = Omit<IApprovalStatus, 'id'> & { id: null };
