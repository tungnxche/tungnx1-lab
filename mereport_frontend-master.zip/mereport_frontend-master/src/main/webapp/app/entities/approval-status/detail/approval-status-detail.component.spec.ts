import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { ApprovalStatusDetailComponent } from './approval-status-detail.component';

describe('ApprovalStatus Management Detail Component', () => {
  let comp: ApprovalStatusDetailComponent;
  let fixture: ComponentFixture<ApprovalStatusDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ApprovalStatusDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ approvalStatus: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(ApprovalStatusDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(ApprovalStatusDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load approvalStatus on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.approvalStatus).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
