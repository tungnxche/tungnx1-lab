import { TestBed } from '@angular/core/testing';

import { sampleWithRequiredData, sampleWithNewData } from '../bidding-doc.test-samples';

import { BiddingDocFormService } from './bidding-doc-form.service';

describe('BiddingDoc Form Service', () => {
  let service: BiddingDocFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BiddingDocFormService);
  });

  describe('Service methods', () => {
    describe('createBiddingDocFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createBiddingDocFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            type: expect.any(Object),
            path: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            proposal: expect.any(Object),
          })
        );
      });

      it('passing IBiddingDoc should create a new form with FormGroup', () => {
        const formGroup = service.createBiddingDocFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            type: expect.any(Object),
            path: expect.any(Object),
            createdBy: expect.any(Object),
            createdOn: expect.any(Object),
            modifiedBy: expect.any(Object),
            modifiedOn: expect.any(Object),
            deletedBy: expect.any(Object),
            deletedOn: expect.any(Object),
            proposal: expect.any(Object),
          })
        );
      });
    });

    describe('getBiddingDoc', () => {
      it('should return NewBiddingDoc for default BiddingDoc initial value', () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const formGroup = service.createBiddingDocFormGroup(sampleWithNewData);

        const biddingDoc = service.getBiddingDoc(formGroup) as any;

        expect(biddingDoc).toMatchObject(sampleWithNewData);
      });

      it('should return NewBiddingDoc for empty BiddingDoc initial value', () => {
        const formGroup = service.createBiddingDocFormGroup();

        const biddingDoc = service.getBiddingDoc(formGroup) as any;

        expect(biddingDoc).toMatchObject({});
      });

      it('should return IBiddingDoc', () => {
        const formGroup = service.createBiddingDocFormGroup(sampleWithRequiredData);

        const biddingDoc = service.getBiddingDoc(formGroup) as any;

        expect(biddingDoc).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IBiddingDoc should not enable id FormControl', () => {
        const formGroup = service.createBiddingDocFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewBiddingDoc should disable id FormControl', () => {
        const formGroup = service.createBiddingDocFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
