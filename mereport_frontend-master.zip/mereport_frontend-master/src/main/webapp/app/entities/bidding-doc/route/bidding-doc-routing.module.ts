import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { BiddingDocComponent } from '../list/bidding-doc.component';
import { BiddingDocDetailComponent } from '../detail/bidding-doc-detail.component';
import { BiddingDocUpdateComponent } from '../update/bidding-doc-update.component';
import { BiddingDocRoutingResolveService } from './bidding-doc-routing-resolve.service';
import { ASC } from 'app/config/navigation.constants';

const biddingDocRoute: Routes = [
  {
    path: '',
    component: BiddingDocComponent,
    data: {
      defaultSort: 'id,' + ASC,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: BiddingDocDetailComponent,
    resolve: {
      biddingDoc: BiddingDocRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BiddingDocUpdateComponent,
    resolve: {
      biddingDoc: BiddingDocRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: BiddingDocUpdateComponent,
    resolve: {
      biddingDoc: BiddingDocRoutingResolveService,
    },
    canActivate: [UserRouteAccessService],
  },
];

@NgModule({
  imports: [RouterModule.forChild(biddingDocRoute)],
  exports: [RouterModule],
})
export class BiddingDocRoutingModule {}
