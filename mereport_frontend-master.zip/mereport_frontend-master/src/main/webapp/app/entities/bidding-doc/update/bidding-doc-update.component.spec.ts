import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Subject, from } from 'rxjs';

import { BiddingDocFormService } from './bidding-doc-form.service';
import { BiddingDocService } from '../service/bidding-doc.service';
import { IBiddingDoc } from '../bidding-doc.model';
import { IBiddingProposal } from 'app/entities/bidding-proposal/bidding-proposal.model';
import { BiddingProposalService } from 'app/entities/bidding-proposal/service/bidding-proposal.service';

import { BiddingDocUpdateComponent } from './bidding-doc-update.component';

describe('BiddingDoc Management Update Component', () => {
  let comp: BiddingDocUpdateComponent;
  let fixture: ComponentFixture<BiddingDocUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let biddingDocFormService: BiddingDocFormService;
  let biddingDocService: BiddingDocService;
  let biddingProposalService: BiddingProposalService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [BiddingDocUpdateComponent],
      providers: [
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(BiddingDocUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(BiddingDocUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    biddingDocFormService = TestBed.inject(BiddingDocFormService);
    biddingDocService = TestBed.inject(BiddingDocService);
    biddingProposalService = TestBed.inject(BiddingProposalService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should call BiddingProposal query and add missing value', () => {
      const biddingDoc: IBiddingDoc = { id: 456 };
      const proposal: IBiddingProposal = { id: 48872 };
      biddingDoc.proposal = proposal;

      const biddingProposalCollection: IBiddingProposal[] = [{ id: 17529 }];
      jest.spyOn(biddingProposalService, 'query').mockReturnValue(of(new HttpResponse({ body: biddingProposalCollection })));
      const additionalBiddingProposals = [proposal];
      const expectedCollection: IBiddingProposal[] = [...additionalBiddingProposals, ...biddingProposalCollection];
      jest.spyOn(biddingProposalService, 'addBiddingProposalToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ biddingDoc });
      comp.ngOnInit();

      expect(biddingProposalService.query).toHaveBeenCalled();
      expect(biddingProposalService.addBiddingProposalToCollectionIfMissing).toHaveBeenCalledWith(
        biddingProposalCollection,
        ...additionalBiddingProposals.map(expect.objectContaining)
      );
      expect(comp.biddingProposalsSharedCollection).toEqual(expectedCollection);
    });

    it('Should update editForm', () => {
      const biddingDoc: IBiddingDoc = { id: 456 };
      const proposal: IBiddingProposal = { id: 95204 };
      biddingDoc.proposal = proposal;

      activatedRoute.data = of({ biddingDoc });
      comp.ngOnInit();

      expect(comp.biddingProposalsSharedCollection).toContain(proposal);
      expect(comp.biddingDoc).toEqual(biddingDoc);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingDoc>>();
      const biddingDoc = { id: 123 };
      jest.spyOn(biddingDocFormService, 'getBiddingDoc').mockReturnValue(biddingDoc);
      jest.spyOn(biddingDocService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingDoc });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingDoc }));
      saveSubject.complete();

      // THEN
      expect(biddingDocFormService.getBiddingDoc).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(biddingDocService.update).toHaveBeenCalledWith(expect.objectContaining(biddingDoc));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingDoc>>();
      const biddingDoc = { id: 123 };
      jest.spyOn(biddingDocFormService, 'getBiddingDoc').mockReturnValue({ id: null });
      jest.spyOn(biddingDocService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingDoc: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: biddingDoc }));
      saveSubject.complete();

      // THEN
      expect(biddingDocFormService.getBiddingDoc).toHaveBeenCalled();
      expect(biddingDocService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IBiddingDoc>>();
      const biddingDoc = { id: 123 };
      jest.spyOn(biddingDocService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ biddingDoc });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(biddingDocService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });

  describe('Compare relationships', () => {
    describe('compareBiddingProposal', () => {
      it('Should forward to biddingProposalService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(biddingProposalService, 'compareBiddingProposal');
        comp.compareBiddingProposal(entity, entity2);
        expect(biddingProposalService.compareBiddingProposal).toHaveBeenCalledWith(entity, entity2);
      });
    });
  });
});
