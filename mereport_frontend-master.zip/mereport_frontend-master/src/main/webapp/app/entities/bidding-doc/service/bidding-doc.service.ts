import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import dayjs from 'dayjs/esm';

import { isPresent } from 'app/core/util/operators';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { createRequestOption } from 'app/core/request/request-util';
import { IBiddingDoc, NewBiddingDoc } from '../bidding-doc.model';

export type PartialUpdateBiddingDoc = Partial<IBiddingDoc> & Pick<IBiddingDoc, 'id'>;

type RestOf<T extends IBiddingDoc | NewBiddingDoc> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

export type RestBiddingDoc = RestOf<IBiddingDoc>;

export type NewRestBiddingDoc = RestOf<NewBiddingDoc>;

export type PartialUpdateRestBiddingDoc = RestOf<PartialUpdateBiddingDoc>;

export type EntityResponseType = HttpResponse<IBiddingDoc>;
export type EntityArrayResponseType = HttpResponse<IBiddingDoc[]>;

@Injectable({ providedIn: 'root' })
export class BiddingDocService {
  protected resourceUrl = this.applicationConfigService.getEndpointFor('api/bidding-docs');

  constructor(protected http: HttpClient, protected applicationConfigService: ApplicationConfigService) {}

  create(biddingDoc: NewBiddingDoc): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingDoc);
    return this.http
      .post<RestBiddingDoc>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  update(biddingDoc: IBiddingDoc): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingDoc);
    return this.http
      .put<RestBiddingDoc>(`${this.resourceUrl}/${this.getBiddingDocIdentifier(biddingDoc)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  partialUpdate(biddingDoc: PartialUpdateBiddingDoc): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(biddingDoc);
    return this.http
      .patch<RestBiddingDoc>(`${this.resourceUrl}/${this.getBiddingDocIdentifier(biddingDoc)}`, copy, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<RestBiddingDoc>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map(res => this.convertResponseFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<RestBiddingDoc[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map(res => this.convertResponseArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  getBiddingDocIdentifier(biddingDoc: Pick<IBiddingDoc, 'id'>): number {
    return biddingDoc.id;
  }

  compareBiddingDoc(o1: Pick<IBiddingDoc, 'id'> | null, o2: Pick<IBiddingDoc, 'id'> | null): boolean {
    return o1 && o2 ? this.getBiddingDocIdentifier(o1) === this.getBiddingDocIdentifier(o2) : o1 === o2;
  }

  addBiddingDocToCollectionIfMissing<Type extends Pick<IBiddingDoc, 'id'>>(
    biddingDocCollection: Type[],
    ...biddingDocsToCheck: (Type | null | undefined)[]
  ): Type[] {
    const biddingDocs: Type[] = biddingDocsToCheck.filter(isPresent);
    if (biddingDocs.length > 0) {
      const biddingDocCollectionIdentifiers = biddingDocCollection.map(biddingDocItem => this.getBiddingDocIdentifier(biddingDocItem)!);
      const biddingDocsToAdd = biddingDocs.filter(biddingDocItem => {
        const biddingDocIdentifier = this.getBiddingDocIdentifier(biddingDocItem);
        if (biddingDocCollectionIdentifiers.includes(biddingDocIdentifier)) {
          return false;
        }
        biddingDocCollectionIdentifiers.push(biddingDocIdentifier);
        return true;
      });
      return [...biddingDocsToAdd, ...biddingDocCollection];
    }
    return biddingDocCollection;
  }

  protected convertDateFromClient<T extends IBiddingDoc | NewBiddingDoc | PartialUpdateBiddingDoc>(biddingDoc: T): RestOf<T> {
    return {
      ...biddingDoc,
      createdOn: biddingDoc.createdOn?.toJSON() ?? null,
      modifiedOn: biddingDoc.modifiedOn?.toJSON() ?? null,
      deletedOn: biddingDoc.deletedOn?.toJSON() ?? null,
    };
  }

  protected convertDateFromServer(restBiddingDoc: RestBiddingDoc): IBiddingDoc {
    return {
      ...restBiddingDoc,
      createdOn: restBiddingDoc.createdOn ? dayjs(restBiddingDoc.createdOn) : undefined,
      modifiedOn: restBiddingDoc.modifiedOn ? dayjs(restBiddingDoc.modifiedOn) : undefined,
      deletedOn: restBiddingDoc.deletedOn ? dayjs(restBiddingDoc.deletedOn) : undefined,
    };
  }

  protected convertResponseFromServer(res: HttpResponse<RestBiddingDoc>): HttpResponse<IBiddingDoc> {
    return res.clone({
      body: res.body ? this.convertDateFromServer(res.body) : null,
    });
  }

  protected convertResponseArrayFromServer(res: HttpResponse<RestBiddingDoc[]>): HttpResponse<IBiddingDoc[]> {
    return res.clone({
      body: res.body ? res.body.map(item => this.convertDateFromServer(item)) : null,
    });
  }
}
