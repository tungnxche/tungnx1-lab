import dayjs from 'dayjs/esm';

import { IBiddingDoc, NewBiddingDoc } from './bidding-doc.model';

export const sampleWithRequiredData: IBiddingDoc = {
  id: 40419,
};

export const sampleWithPartialData: IBiddingDoc = {
  id: 41197,
  deletedOn: dayjs('2022-09-29T05:17'),
};

export const sampleWithFullData: IBiddingDoc = {
  id: 3259,
  name: 'encoding payment',
  type: 80572,
  path: 'Utah Investment',
  createdBy: 62045,
  createdOn: dayjs('2022-09-28T21:55'),
  modifiedBy: 76291,
  modifiedOn: dayjs('2022-09-28T23:05'),
  deletedBy: 89133,
  deletedOn: dayjs('2022-09-29T00:25'),
};

export const sampleWithNewData: NewBiddingDoc = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
