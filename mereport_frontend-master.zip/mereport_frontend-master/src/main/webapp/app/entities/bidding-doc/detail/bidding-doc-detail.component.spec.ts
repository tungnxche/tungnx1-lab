import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { BiddingDocDetailComponent } from './bidding-doc-detail.component';

describe('BiddingDoc Management Detail Component', () => {
  let comp: BiddingDocDetailComponent;
  let fixture: ComponentFixture<BiddingDocDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BiddingDocDetailComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { data: of({ biddingDoc: { id: 123 } }) },
        },
      ],
    })
      .overrideTemplate(BiddingDocDetailComponent, '')
      .compileComponents();
    fixture = TestBed.createComponent(BiddingDocDetailComponent);
    comp = fixture.componentInstance;
  });

  describe('OnInit', () => {
    it('Should load biddingDoc on init', () => {
      // WHEN
      comp.ngOnInit();

      // THEN
      expect(comp.biddingDoc).toEqual(expect.objectContaining({ id: 123 }));
    });
  });
});
