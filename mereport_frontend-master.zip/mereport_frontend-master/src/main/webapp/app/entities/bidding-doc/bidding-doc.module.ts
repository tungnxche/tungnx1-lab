import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { BiddingDocComponent } from './list/bidding-doc.component';
import { BiddingDocDetailComponent } from './detail/bidding-doc-detail.component';
import { BiddingDocUpdateComponent } from './update/bidding-doc-update.component';
import { BiddingDocDeleteDialogComponent } from './delete/bidding-doc-delete-dialog.component';
import { BiddingDocRoutingModule } from './route/bidding-doc-routing.module';

@NgModule({
  imports: [SharedModule, BiddingDocRoutingModule],
  declarations: [BiddingDocComponent, BiddingDocDetailComponent, BiddingDocUpdateComponent, BiddingDocDeleteDialogComponent],
})
export class BiddingDocModule {}
