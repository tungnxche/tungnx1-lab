import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IBiddingDoc } from '../bidding-doc.model';

@Component({
  selector: 'jhi-bidding-doc-detail',
  templateUrl: './bidding-doc-detail.component.html',
})
export class BiddingDocDetailComponent implements OnInit {
  biddingDoc: IBiddingDoc | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingDoc }) => {
      this.biddingDoc = biddingDoc;
    });
  }

  previousState(): void {
    window.history.back();
  }
}
