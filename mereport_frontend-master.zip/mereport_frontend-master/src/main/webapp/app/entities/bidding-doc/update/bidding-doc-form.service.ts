import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IBiddingDoc, NewBiddingDoc } from '../bidding-doc.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IBiddingDoc for edit and NewBiddingDocFormGroupInput for create.
 */
type BiddingDocFormGroupInput = IBiddingDoc | PartialWithRequiredKeyOf<NewBiddingDoc>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IBiddingDoc | NewBiddingDoc> = Omit<T, 'createdOn' | 'modifiedOn' | 'deletedOn'> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
  deletedOn?: string | null;
};

type BiddingDocFormRawValue = FormValueOf<IBiddingDoc>;

type NewBiddingDocFormRawValue = FormValueOf<NewBiddingDoc>;

type BiddingDocFormDefaults = Pick<NewBiddingDoc, 'id' | 'createdOn' | 'modifiedOn' | 'deletedOn'>;

type BiddingDocFormGroupContent = {
  id: FormControl<BiddingDocFormRawValue['id'] | NewBiddingDoc['id']>;
  name: FormControl<BiddingDocFormRawValue['name']>;
  type: FormControl<BiddingDocFormRawValue['type']>;
  path: FormControl<BiddingDocFormRawValue['path']>;
  createdBy: FormControl<BiddingDocFormRawValue['createdBy']>;
  createdOn: FormControl<BiddingDocFormRawValue['createdOn']>;
  modifiedBy: FormControl<BiddingDocFormRawValue['modifiedBy']>;
  modifiedOn: FormControl<BiddingDocFormRawValue['modifiedOn']>;
  deletedBy: FormControl<BiddingDocFormRawValue['deletedBy']>;
  deletedOn: FormControl<BiddingDocFormRawValue['deletedOn']>;
  proposal: FormControl<BiddingDocFormRawValue['proposal']>;
};

export type BiddingDocFormGroup = FormGroup<BiddingDocFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class BiddingDocFormService {
  createBiddingDocFormGroup(biddingDoc: BiddingDocFormGroupInput = { id: null }): BiddingDocFormGroup {
    const biddingDocRawValue = this.convertBiddingDocToBiddingDocRawValue({
      ...this.getFormDefaults(),
      ...biddingDoc,
    });
    return new FormGroup<BiddingDocFormGroupContent>({
      id: new FormControl(
        { value: biddingDocRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        }
      ),
      name: new FormControl(biddingDocRawValue.name),
      type: new FormControl(biddingDocRawValue.type),
      path: new FormControl(biddingDocRawValue.path),
      createdBy: new FormControl(biddingDocRawValue.createdBy),
      createdOn: new FormControl(biddingDocRawValue.createdOn),
      modifiedBy: new FormControl(biddingDocRawValue.modifiedBy),
      modifiedOn: new FormControl(biddingDocRawValue.modifiedOn),
      deletedBy: new FormControl(biddingDocRawValue.deletedBy),
      deletedOn: new FormControl(biddingDocRawValue.deletedOn),
      proposal: new FormControl(biddingDocRawValue.proposal),
    });
  }

  getBiddingDoc(form: BiddingDocFormGroup): IBiddingDoc | NewBiddingDoc {
    return this.convertBiddingDocRawValueToBiddingDoc(form.getRawValue() as BiddingDocFormRawValue | NewBiddingDocFormRawValue);
  }

  resetForm(form: BiddingDocFormGroup, biddingDoc: BiddingDocFormGroupInput): void {
    const biddingDocRawValue = this.convertBiddingDocToBiddingDocRawValue({ ...this.getFormDefaults(), ...biddingDoc });
    form.reset(
      {
        ...biddingDocRawValue,
        id: { value: biddingDocRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */
    );
  }

  private getFormDefaults(): BiddingDocFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      createdOn: currentTime,
      modifiedOn: currentTime,
      deletedOn: currentTime,
    };
  }

  private convertBiddingDocRawValueToBiddingDoc(
    rawBiddingDoc: BiddingDocFormRawValue | NewBiddingDocFormRawValue
  ): IBiddingDoc | NewBiddingDoc {
    return {
      ...rawBiddingDoc,
      createdOn: dayjs(rawBiddingDoc.createdOn, DATE_TIME_FORMAT),
      modifiedOn: dayjs(rawBiddingDoc.modifiedOn, DATE_TIME_FORMAT),
      deletedOn: dayjs(rawBiddingDoc.deletedOn, DATE_TIME_FORMAT),
    };
  }

  private convertBiddingDocToBiddingDocRawValue(
    biddingDoc: IBiddingDoc | (Partial<NewBiddingDoc> & BiddingDocFormDefaults)
  ): BiddingDocFormRawValue | PartialWithRequiredKeyOf<NewBiddingDocFormRawValue> {
    return {
      ...biddingDoc,
      createdOn: biddingDoc.createdOn ? biddingDoc.createdOn.format(DATE_TIME_FORMAT) : undefined,
      modifiedOn: biddingDoc.modifiedOn ? biddingDoc.modifiedOn.format(DATE_TIME_FORMAT) : undefined,
      deletedOn: biddingDoc.deletedOn ? biddingDoc.deletedOn.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
