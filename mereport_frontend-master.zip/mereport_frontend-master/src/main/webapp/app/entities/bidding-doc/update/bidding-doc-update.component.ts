import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { BiddingDocFormService, BiddingDocFormGroup } from './bidding-doc-form.service';
import { IBiddingDoc } from '../bidding-doc.model';
import { BiddingDocService } from '../service/bidding-doc.service';
import { IBiddingProposal } from 'app/entities/bidding-proposal/bidding-proposal.model';
import { BiddingProposalService } from 'app/entities/bidding-proposal/service/bidding-proposal.service';

@Component({
  selector: 'jhi-bidding-doc-update',
  templateUrl: './bidding-doc-update.component.html',
})
export class BiddingDocUpdateComponent implements OnInit {
  isSaving = false;
  biddingDoc: IBiddingDoc | null = null;

  biddingProposalsSharedCollection: IBiddingProposal[] = [];

  editForm: BiddingDocFormGroup = this.biddingDocFormService.createBiddingDocFormGroup();

  constructor(
    protected biddingDocService: BiddingDocService,
    protected biddingDocFormService: BiddingDocFormService,
    protected biddingProposalService: BiddingProposalService,
    protected activatedRoute: ActivatedRoute
  ) {}

  compareBiddingProposal = (o1: IBiddingProposal | null, o2: IBiddingProposal | null): boolean =>
    this.biddingProposalService.compareBiddingProposal(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ biddingDoc }) => {
      this.biddingDoc = biddingDoc;
      if (biddingDoc) {
        this.updateForm(biddingDoc);
      }

      this.loadRelationshipsOptions();
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const biddingDoc = this.biddingDocFormService.getBiddingDoc(this.editForm);
    if (biddingDoc.id !== null) {
      this.subscribeToSaveResponse(this.biddingDocService.update(biddingDoc));
    } else {
      this.subscribeToSaveResponse(this.biddingDocService.create(biddingDoc));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBiddingDoc>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(biddingDoc: IBiddingDoc): void {
    this.biddingDoc = biddingDoc;
    this.biddingDocFormService.resetForm(this.editForm, biddingDoc);

    this.biddingProposalsSharedCollection = this.biddingProposalService.addBiddingProposalToCollectionIfMissing<IBiddingProposal>(
      this.biddingProposalsSharedCollection,
      biddingDoc.proposal
    );
  }

  protected loadRelationshipsOptions(): void {
    this.biddingProposalService
      .query()
      .pipe(map((res: HttpResponse<IBiddingProposal[]>) => res.body ?? []))
      .pipe(
        map((biddingProposals: IBiddingProposal[]) =>
          this.biddingProposalService.addBiddingProposalToCollectionIfMissing<IBiddingProposal>(biddingProposals, this.biddingDoc?.proposal)
        )
      )
      .subscribe((biddingProposals: IBiddingProposal[]) => (this.biddingProposalsSharedCollection = biddingProposals));
  }
}
