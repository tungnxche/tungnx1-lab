import dayjs from 'dayjs/esm';
import { IBiddingProposal } from 'app/entities/bidding-proposal/bidding-proposal.model';

export interface IBiddingDoc {
  id: number;
  name?: string | null;
  type?: number | null;
  path?: string | null;
  createdBy?: number | null;
  createdOn?: dayjs.Dayjs | null;
  modifiedBy?: number | null;
  modifiedOn?: dayjs.Dayjs | null;
  deletedBy?: number | null;
  deletedOn?: dayjs.Dayjs | null;
  proposal?: Pick<IBiddingProposal, 'id'> | null;
}

export type NewBiddingDoc = Omit<IBiddingDoc, 'id'> & { id: null };
