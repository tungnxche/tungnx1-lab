import {
  faBell,
  faCalendarAlt,
  faEye,
  faFlag,
  faHeart,
  faSave,
  faTrashAlt,
  faUser,
  faEdit,
  // jhipster-needle-add-icon-import
} from '@fortawesome/free-regular-svg-icons';

export const fontRegularAwesomeIcons = [
  faBell,
  faCalendarAlt,
  faEye,
  faFlag,
  faHeart,
  faSave,
  faTrashAlt,
  faUser,
  faEdit,
  // jhipster-needle-add-icon-import
];
