export const ASC = 'asc';
export const DESC = 'desc';
export const SORT = 'sort';
export const ITEM_DELETED_EVENT = 'deleted';
export const DEFAULT_SORT_DATA = 'defaultSort';
export const ALERT_TYPE = 'type';
export const ALERT_TRANSLATION_KEY = 'translationKey';
export const ALERT_TRANSLATION_PARAMS = 'translationParams';
