import { IconProp } from "@fortawesome/fontawesome-svg-core";

export class NavbarItem {
  public routerLink: string;
  public jhiTranslate: string;
  public icon: IconProp;

  constructor(routerLink: string, jhiTranslate: string, icon:IconProp = 'asterisk') {
    this.routerLink = routerLink;
    this.jhiTranslate = `global.menu.entities.${jhiTranslate}`;
    this.icon = icon;
  }
}
